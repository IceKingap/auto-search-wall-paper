package com.wallpaper.auto.ui.favorites

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.wallpaper.auto.data.db.entity.LocalImage
import com.wallpaper.auto.data.db.entity.OnlineImage
import com.wallpaper.auto.data.repository.AlbumRepository
import com.wallpaper.auto.data.repository.OnlineImageRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class FavoritesViewModel @Inject constructor(
    private val albumRepository: AlbumRepository,
    private val onlineImageRepository: OnlineImageRepository
) : ViewModel() {

    val localFavorites = albumRepository.getFavoriteLocalImages()
    val onlineFavorites = onlineImageRepository.getFavoriteImages()

    val localBlacklist = albumRepository.getBlacklistedImages()
    val onlineBlacklist = onlineImageRepository.getBlacklistedImages()

    fun removeLocalFavorite(image: LocalImage) = viewModelScope.launch {
        albumRepository.setFavorite(image.id, false)
    }

    fun removeOnlineFavorite(image: OnlineImage) = viewModelScope.launch {
        onlineImageRepository.setFavorite(image.id, false)
    }

    fun unblacklistLocal(image: LocalImage) = viewModelScope.launch {
        albumRepository.setBlacklisted(image.id, false)
    }

    fun unblacklistOnline(image: OnlineImage) = viewModelScope.launch {
        onlineImageRepository.setBlacklisted(image.id, false)
    }
}
