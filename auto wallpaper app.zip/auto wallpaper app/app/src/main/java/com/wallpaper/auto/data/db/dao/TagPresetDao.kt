package com.wallpaper.auto.data.db.dao

import androidx.room.*
import com.wallpaper.auto.data.db.entity.TagPreset
import kotlinx.coroutines.flow.Flow

@Dao
interface TagPresetDao {
    @Query("SELECT * FROM tag_presets ORDER BY name ASC")
    fun getAllPresets(): Flow<List<TagPreset>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(preset: TagPreset): Long

    @Update
    suspend fun update(preset: TagPreset)

    @Delete
    suspend fun delete(preset: TagPreset)
}
