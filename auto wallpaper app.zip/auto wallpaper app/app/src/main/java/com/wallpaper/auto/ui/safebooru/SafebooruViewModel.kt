package com.wallpaper.auto.ui.safebooru

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.wallpaper.auto.data.api.BooruPost
import com.wallpaper.auto.data.api.pixiv.PixivAuthManager
import com.wallpaper.auto.data.api.pixiv.PixivFetchMode
import com.wallpaper.auto.data.api.pixiv.PixivMultiPageMode
import com.wallpaper.auto.data.repository.BooruSource
import com.wallpaper.auto.data.repository.OnlineImageRepository
import com.wallpaper.auto.data.repository.SettingsRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class SafebooruViewModel @Inject constructor(
    private val settingsRepository: SettingsRepository,
    private val onlineImageRepository: OnlineImageRepository,
    private val pixivAuthManager: PixivAuthManager
) : ViewModel() {

    private val _activeTags = MutableStateFlow<List<String>>(emptyList())
    val activeTags: StateFlow<List<String>> = _activeTags

    private val _searchQueries = MutableStateFlow<List<String>>(emptyList())
    val searchQueries: StateFlow<List<String>> = _searchQueries

    private val _previewPosts = MutableStateFlow<List<BooruPost>>(emptyList())
    val previewPosts: StateFlow<List<BooruPost>> = _previewPosts

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading

    private val _errorMessage = MutableStateFlow<String?>(null)
    val errorMessage: StateFlow<String?> = _errorMessage

    val downloadedCount: StateFlow<Int> = onlineImageRepository.observeCachedCount()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    private val _downloadMessage = MutableStateFlow<String?>(null)
    val downloadMessage: StateFlow<String?> = _downloadMessage

    private val _booruSource = MutableStateFlow(BooruSource.SAFEBOORU)
    val booruSource: StateFlow<BooruSource> = _booruSource

    // Pixiv state
    private val _pixivLoggedIn = MutableStateFlow(false)
    val pixivLoggedIn: StateFlow<Boolean> = _pixivLoggedIn

    private val _pixivUserName = MutableStateFlow("")
    val pixivUserName: StateFlow<String> = _pixivUserName

    private val _pixivFetchMode = MutableStateFlow(PixivFetchMode.RANKING)
    val pixivFetchMode: StateFlow<PixivFetchMode> = _pixivFetchMode

    private val _pixivRankingMode = MutableStateFlow("day")
    val pixivRankingMode: StateFlow<String> = _pixivRankingMode

    private val _pixivSearchWord = MutableStateFlow("")
    val pixivSearchWord: StateFlow<String> = _pixivSearchWord

    private val _pixivSearchQueries = MutableStateFlow<List<String>>(emptyList())
    val pixivSearchQueries: StateFlow<List<String>> = _pixivSearchQueries

    private val _maxCacheCount = MutableStateFlow(50)
    val maxCacheCount: StateFlow<Int> = _maxCacheCount

    private val _mixedSources = MutableStateFlow<Set<BooruSource>>(emptySet())
    val mixedSources: StateFlow<Set<BooruSource>> = _mixedSources

    private val _isDownloading = MutableStateFlow(false)
    val isDownloading: StateFlow<Boolean> = _isDownloading

    private val _pixivPagingEnabled = MutableStateFlow(false)
    val pixivPagingEnabled: StateFlow<Boolean> = _pixivPagingEnabled

    private val _pixivPagingMaxPages = MutableStateFlow(5)
    val pixivPagingMaxPages: StateFlow<Int> = _pixivPagingMaxPages

    private val _pixivMultiPageMode = MutableStateFlow(PixivMultiPageMode.FIRST_PAGE_ONLY)
    val pixivMultiPageMode: StateFlow<PixivMultiPageMode> = _pixivMultiPageMode

    init {
        viewModelScope.launch {
            _activeTags.value = settingsRepository.getActiveTags()
            _searchQueries.value = settingsRepository.getSearchQueries()
            _maxCacheCount.value = settingsRepository.getMaxCacheCount()
            _booruSource.value = settingsRepository.getBooruSource()
            // Pixiv
            _pixivLoggedIn.value = settingsRepository.isPixivLoggedIn()
            _pixivUserName.value = settingsRepository.getPixivUserName()
            _pixivFetchMode.value = try {
                PixivFetchMode.valueOf(settingsRepository.getPixivFetchMode())
            } catch (_: Exception) { PixivFetchMode.RANKING }
            _pixivRankingMode.value = settingsRepository.getPixivRankingMode()
            _pixivSearchWord.value = settingsRepository.getPixivSearchWord()
            _pixivSearchQueries.value = settingsRepository.getPixivSearchQueries()
            _mixedSources.value = settingsRepository.getMixedSources()
            _pixivPagingEnabled.value = settingsRepository.isPixivPagingEnabled()
            _pixivPagingMaxPages.value = settingsRepository.getPixivPagingMaxPages()
            _pixivMultiPageMode.value = try {
                PixivMultiPageMode.valueOf(settingsRepository.getPixivMultiPageMode())
            } catch (_: Exception) { PixivMultiPageMode.FIRST_PAGE_ONLY }
        }
    }

    /** 画面表示時に設定画面で変更された値を再取得する */
    fun refreshSettings() = viewModelScope.launch {
        _maxCacheCount.value = settingsRepository.getMaxCacheCount()
    }

    fun toggleMixedSource(source: BooruSource) = viewModelScope.launch {
        if (source == BooruSource.MIXED) return@launch
        val current = _mixedSources.value.toMutableSet()
        if (current.contains(source)) current.remove(source) else current.add(source)
        _mixedSources.value = current
        settingsRepository.setMixedSources(current)
    }

    fun setBooruSource(source: BooruSource) = viewModelScope.launch {
        _booruSource.value = source
        settingsRepository.setBooruSource(source)
        _previewPosts.value = emptyList()
    }

    fun toggleTag(tag: String) = viewModelScope.launch {
        val current = _activeTags.value.toMutableList()
        if (current.contains(tag)) current.remove(tag) else current.add(tag)
        _activeTags.value = current
        settingsRepository.setActiveTags(current)
    }

    fun addTag(tag: String) = viewModelScope.launch {
        if (!_activeTags.value.contains(tag)) {
            val updated = _activeTags.value + tag
            _activeTags.value = updated
            settingsRepository.setActiveTags(updated)
        }
    }

    fun removeTag(tag: String) = viewModelScope.launch {
        val updated = _activeTags.value.filter { it != tag }
        _activeTags.value = updated
        settingsRepository.setActiveTags(updated)
    }

    fun saveCurrentAsQuery() = viewModelScope.launch {
        val query = _activeTags.value.joinToString(" ")
        if (query.isBlank()) return@launch
        settingsRepository.addSearchQuery(query)
        _searchQueries.value = settingsRepository.getSearchQueries()
    }

    fun removeSearchQuery(query: String) = viewModelScope.launch {
        settingsRepository.removeSearchQuery(query)
        _searchQueries.value = settingsRepository.getSearchQueries()
    }

    fun fetchPreview() = viewModelScope.launch {
        _isLoading.value = true
        _errorMessage.value = null
        try {
            val posts = onlineImageRepository.fetchPosts(_activeTags.value)
            _previewPosts.value = posts
            if (posts.isEmpty()) {
                _errorMessage.value = "該当する画像が見つかりませんでした"
            }
        } catch (e: Exception) {
            _previewPosts.value = emptyList()
            _errorMessage.value = "検索エラー: ${e.message}"
        } finally {
            _isLoading.value = false
        }
    }

    /**
     * MIXED モード時に特定のソース (Pixiv または Booru系) を指定してプレビューする。
     * Pixiv は内部設定 (search/ranking/recommended) を使うので tags は無視される。
     */
    fun fetchPreviewForSource(source: BooruSource) = viewModelScope.launch {
        _isLoading.value = true
        _errorMessage.value = null
        try {
            val posts = onlineImageRepository.fetchPostsFromSource(source, _activeTags.value)
            _previewPosts.value = posts
            if (posts.isEmpty()) {
                _errorMessage.value = "該当する画像が見つかりませんでした"
            }
        } catch (e: Exception) {
            _previewPosts.value = emptyList()
            _errorMessage.value = "検索エラー: ${e.message}"
        } finally {
            _isLoading.value = false
        }
    }

    fun downloadPost(post: BooruPost) = viewModelScope.launch {
        _isDownloading.value = true
        val result = onlineImageRepository.downloadAndSave(post)
        if (result != null) {
            _downloadMessage.value = "ダウンロード完了"
        } else {
            _downloadMessage.value = "ダウンロード失敗"
        }
        _isDownloading.value = false
    }

    fun downloadAll() = viewModelScope.launch {
        val posts = _previewPosts.value
        if (posts.isEmpty()) return@launch
        _isDownloading.value = true
        _downloadMessage.value = "ダウンロード中... 0/${posts.size}"
        var success = 0
        for ((i, post) in posts.withIndex()) {
            val result = onlineImageRepository.downloadAndSave(post)
            if (result != null) success++
            _downloadMessage.value = "ダウンロード中... ${i + 1}/${posts.size}"
        }
        _downloadMessage.value = "${success}/${posts.size} 件ダウンロード完了"
        _isDownloading.value = false
    }

    fun clearDownloadMessage() {
        _downloadMessage.value = null
    }

    // ── Pixiv ──

    fun loginToPixiv(code: String, codeVerifier: String) = viewModelScope.launch {
        _isLoading.value = true
        val success = pixivAuthManager.exchangeCodeForToken(code, codeVerifier)
        _pixivLoggedIn.value = success
        if (success) {
            _pixivUserName.value = settingsRepository.getPixivUserName()
            _downloadMessage.value = "Pixivログイン成功"
        } else {
            _errorMessage.value = "Pixivログイン失敗"
        }
        _isLoading.value = false
    }

    fun logoutPixiv() = viewModelScope.launch {
        pixivAuthManager.logout()
        _pixivLoggedIn.value = false
        _pixivUserName.value = ""
        _previewPosts.value = emptyList()
    }

    fun setPixivFetchMode(mode: PixivFetchMode) = viewModelScope.launch {
        _pixivFetchMode.value = mode
        settingsRepository.setPixivFetchMode(mode.name)
        _previewPosts.value = emptyList()
    }

    fun setPixivRankingMode(mode: String) = viewModelScope.launch {
        _pixivRankingMode.value = mode
        settingsRepository.setPixivRankingMode(mode)
    }

    fun setPixivSearchWord(word: String) = viewModelScope.launch {
        _pixivSearchWord.value = word
        settingsRepository.setPixivSearchWord(word)
    }

    fun savePixivSearchQuery() = viewModelScope.launch {
        val word = _pixivSearchWord.value.trim()
        if (word.isBlank()) return@launch
        settingsRepository.addPixivSearchQuery(word)
        _pixivSearchQueries.value = settingsRepository.getPixivSearchQueries()
    }

    fun removePixivSearchQuery(query: String) = viewModelScope.launch {
        settingsRepository.removePixivSearchQuery(query)
        _pixivSearchQueries.value = settingsRepository.getPixivSearchQueries()
    }

    fun applyPixivSearchQuery(query: String) {
        _pixivSearchWord.value = query
        viewModelScope.launch { settingsRepository.setPixivSearchWord(query) }
    }

    fun setPixivPagingEnabled(enabled: Boolean) = viewModelScope.launch {
        _pixivPagingEnabled.value = enabled
        settingsRepository.setPixivPagingEnabled(enabled)
    }

    fun setPixivPagingMaxPages(pages: Int) = viewModelScope.launch {
        _pixivPagingMaxPages.value = pages
        settingsRepository.setPixivPagingMaxPages(pages)
    }

    fun setPixivMultiPageMode(mode: PixivMultiPageMode) = viewModelScope.launch {
        _pixivMultiPageMode.value = mode
        settingsRepository.setPixivMultiPageMode(mode.name)
    }
}
