package com.wallpaper.auto.service

import android.app.KeyguardManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.LinearGradient
import android.graphics.RectF
import android.graphics.Shader
import android.os.Build
import android.service.wallpaper.WallpaperService
import android.util.Log
import android.view.MotionEvent
import android.view.SurfaceHolder
import com.wallpaper.auto.data.repository.EdgeColorMode
import com.wallpaper.auto.data.repository.OverlayRect
import com.wallpaper.auto.data.repository.SettingsRepository
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.*
import javax.inject.Inject

@AndroidEntryPoint
class AutoWallpaperService : WallpaperService() {

    @Inject lateinit var imagePreloader: ImagePreloader
    @Inject lateinit var settingsRepository: SettingsRepository

    companion object {
        const val ACTION_SKIP = "com.wallpaper.auto.ACTION_SKIP"
        private const val TAG = "WallpaperEngine"
    }

    override fun onCreateEngine(): Engine = WallpaperEngine()

    inner class WallpaperEngine : Engine() {
        private var currentBitmap: Bitmap? = null
        private var nextBitmap: Bitmap? = null
        private var fadeAlpha: Int = 255
        private var isAnimating = false
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.GRAY
            textSize = 40f
            textAlign = Paint.Align.CENTER
        }
        private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())
        private var displayModeFit = false
        private var initialLoadDone = false
        private var surfaceWidth = 0
        private var surfaceHeight = 0
        private var changeOnHome = false

        // ズームアウトアニメーション
        private var zoomOutEnabled = false
        private var zoomOutDurationMs = 10000L
        private var zoomProgress = 1f  // 0=start(zoomed in), 1=end(target scale)
        private var isZooming = false
        private var zoomJob: Job? = null
        private var fadeJob: Job? = null

        // スティックパン（ジョイスティック方式）
        private var panEnabled = false
        private var panOffsetX = 0f
        private var panOffsetY = 0f
        private var panVelocityX = 0f
        private var panVelocityY = 0f
        private var panJob: Job? = null
        private var touchStartX = 0f
        private var touchStartY = 0f
        private var panInverted = false
        private var panSpeed = 1.0f

        // 余白補完
        private var edgeFillEnabled = false
        private var edgeFadeWidthDp = 40
        private var edgeColorMode = EdgeColorMode.EDGE_AVERAGE
        private var currentBgColor: Int = Color.BLACK
        private var nextBgColor: Int = Color.BLACK

        // 省電力
        private var animationFps = 30
        private val frameDelayMs: Long get() = (1000L / animationFps).coerceAtLeast(8L)
        private var changeOnScreenOff = true
        private var gpuRendering = true
        // lockHardwareCanvas/lockCanvas は同一Surfaceで混在不可。初回で確定しロックする
        private var canvasTypeLocked: Boolean? = null

        // グラデーションキャッシュ（current/next 画像用）
        private val currentEdgeCache = GradientEdgeCache()
        private val nextEdgeCache = GradientEdgeCache()

        // オーバーレイ
        private var statusBarOverlayHeight = 0
        private var lockOverlayRects: List<OverlayRect> = emptyList()
        private val overlayPaint = Paint(Paint.ANTI_ALIAS_FLAG)

        private val screenReceiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context, intent: Intent) {
                when (intent.action) {
                    Intent.ACTION_SCREEN_OFF -> handleScreenOff()
                    Intent.ACTION_SCREEN_ON -> handleScreenOn()
                }
            }
        }

        override fun onCreate(surfaceHolder: SurfaceHolder) {
            super.onCreate(surfaceHolder)
            setTouchEventsEnabled(true)

            // SCREEN_ON/OFF はシステム broadcast 専用。
            // ACTION_SKIP は SharedFlow 経由でのみ流すので filter には含めない。
            val filter = IntentFilter().apply {
                addAction(Intent.ACTION_SCREEN_OFF)
                addAction(Intent.ACTION_SCREEN_ON)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                this@AutoWallpaperService.registerReceiver(
                    screenReceiver, filter, Context.RECEIVER_NOT_EXPORTED
                )
            } else {
                this@AutoWallpaperService.registerReceiver(screenReceiver, filter)
            }

            scope.launch {
                imagePreloader.skipEvent.collect { handleSkip() }
            }
        }

        override fun onSurfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
            super.onSurfaceChanged(holder, format, width, height)
            surfaceWidth = width
            surfaceHeight = height

            if (!initialLoadDone && width > 0 && height > 0) {
                initialLoadDone = true
                scope.launch {
                    refreshSettings()
                    Log.d(TAG, "Initial: fit=$displayModeFit zoom=$zoomOutEnabled dur=$zoomOutDurationMs")
                    val bitmap = withContext(Dispatchers.IO) {
                        imagePreloader.loadCurrentImage(width, height)
                    }
                    currentBitmap = bitmap
                    currentBgColor = bitmap?.let { computeEdgeColor(it) } ?: Color.BLACK
                    drawFrame()
                    startZoomOutIfNeeded()
                }
            } else {
                drawFrame()
            }
        }

        override fun onVisibilityChanged(visible: Boolean) {
            super.onVisibilityChanged(visible)
            if (!visible) {
                cancelZoom()
                panJob?.cancel()
                panJob = null
                // 走行中の preload は画面OFF時に再開するのでここでは止める。
                pendingPreloadJob?.cancel()
                pendingPreloadJob = null
                return
            }
            if (visible) {
                scope.launch {
                    refreshSettings()
                    if (currentBitmap == null && surfaceWidth > 0 && surfaceHeight > 0) {
                        val bitmap = withContext(Dispatchers.IO) {
                            imagePreloader.loadCurrentImage(surfaceWidth, surfaceHeight)
                        }
                        if (bitmap != null) {
                            currentBitmap = bitmap
                            currentBgColor = computeEdgeColor(bitmap)
                        }
                        drawFrame()
                        startZoomOutIfNeeded()
                    } else if (changeOnHome && currentBitmap != null) {
                        // 履歴復元直後はホーム切り替えを1回スキップ
                        if (imagePreloader.consumeSuppressHomeChange()) {
                            cancelZoom()
                            drawFrame()
                            startZoomOutIfNeeded()
                        } else {
                            val w = surfaceWidth.takeIf { it > 0 } ?: return@launch
                            val h = surfaceHeight.takeIf { it > 0 } ?: return@launch
                            val bitmap = withContext(Dispatchers.IO) {
                                imagePreloader.preloadNext(w, h)
                            }
                            if (bitmap != null) {
                                nextBitmap = bitmap
                                nextBgColor = computeEdgeColor(bitmap)
                                startFadeAnimation()
                            }
                        }
                    } else {
                        cancelZoom()
                        drawFrame()
                        startZoomOutIfNeeded()
                    }
                }
            }
        }

        override fun onTouchEvent(event: MotionEvent) {
            if (!panEnabled) return
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    touchStartX = event.x
                    touchStartY = event.y
                    startPanLoop()
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = event.x - touchStartX
                    val dy = event.y - touchStartY
                    val dir = if (panInverted) -1f else 1f
                    panVelocityX = dx * 0.03f * panSpeed * dir
                    panVelocityY = dy * 0.03f * panSpeed * dir
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    panVelocityX = 0f
                    panVelocityY = 0f
                    panJob?.cancel()
                    panJob = null
                }
            }
        }

        override fun onDestroy() {
            try {
                this@AutoWallpaperService.unregisterReceiver(screenReceiver)
            } catch (_: Exception) {}
            scope.cancel()
            currentBitmap?.recycle()
            nextBitmap?.recycle()
            currentBitmap = null
            nextBitmap = null
            super.onDestroy()
        }

        // 画面OFF時に走らせている preload を追跡。画面ONで未完了なら cancel して
        // 最新の preload を走らせ直し、取りこぼしによる "old 画像のまま" 状態を防ぐ。
        private var pendingPreloadJob: Job? = null

        private fun handleScreenOff() {
            pendingPreloadJob?.cancel()
            pendingPreloadJob = scope.launch {
                refreshSettings()
                if (!changeOnScreenOff) return@launch
                // システム側が省電力状態に落ち着くまで少しだけ待機。
                // 途中で画面ONが来た場合は cancel によって抜ける。
                delay(500)
                val w = surfaceWidth.takeIf { it > 0 } ?: return@launch
                val h = surfaceHeight.takeIf { it > 0 } ?: return@launch
                val bitmap = withContext(Dispatchers.IO) {
                    imagePreloader.preloadNext(w, h)
                }
                if (!isActive) {
                    bitmap?.recycle()
                    return@launch
                }
                if (bitmap != null) {
                    nextBitmap?.recycle()
                    nextBitmap = bitmap
                    nextBgColor = computeEdgeColor(bitmap)
                }
            }
        }

        private fun handleScreenOn() {
            if (nextBitmap != null) {
                startFadeAnimation()
                return
            }
            val pending = pendingPreloadJob
            if (pending != null && pending.isActive) {
                // 画面OFF 後の preload がまだ走っている。完了を待ってフェードする。
                scope.launch {
                    pending.join()
                    if (nextBitmap != null) startFadeAnimation()
                    else {
                        cancelZoom()
                        startZoomOutIfNeeded()
                    }
                }
            } else {
                cancelZoom()
                startZoomOutIfNeeded()
            }
        }

        private fun handleSkip() {
            scope.launch {
                val w = surfaceWidth.takeIf { it > 0 } ?: return@launch
                val h = surfaceHeight.takeIf { it > 0 } ?: return@launch
                val bitmap = withContext(Dispatchers.IO) {
                    imagePreloader.preloadNext(w, h)
                }
                if (bitmap != null) {
                    // 進行中のフェードがあれば中断してその時点の状態を確定する
                    finalizeOngoingFade()
                    nextBitmap = bitmap
                    nextBgColor = computeEdgeColor(bitmap)
                    startFadeAnimation()
                }
            }
        }

        /**
         * 進行中のフェードアニメーションがあれば即座にキャンセルし、
         * フェード完了時に行うはずだった状態遷移(currentBitmap = nextBitmap など)を
         * 同期的に実行する。これにより、フェード中の skip でも視覚的なグリッチを起こさない。
         */
        private fun finalizeOngoingFade() {
            if (!isAnimating) return
            fadeJob?.cancel()
            fadeJob = null
            currentBitmap?.recycle()
            currentBitmap = nextBitmap
            nextBitmap = null
            currentBgColor = nextBgColor
            fadeAlpha = 255
            isAnimating = false
            panOffsetX = 0f
            panOffsetY = 0f
        }

        private suspend fun refreshSettings() {
            withContext(Dispatchers.IO) {
                displayModeFit = settingsRepository.getGlobalDisplayMode() == "FIT"
                changeOnHome = settingsRepository.isChangeOnHomeEnabled()
                zoomOutEnabled = settingsRepository.isZoomOutEnabled()
                zoomOutDurationMs = settingsRepository.getZoomOutDuration() * 1000L
                statusBarOverlayHeight = settingsRepository.getStatusBarOverlayHeight()
                lockOverlayRects = settingsRepository.getLockOverlayRects()
                edgeFillEnabled = settingsRepository.isEdgeFillEnabled()
                edgeFadeWidthDp = settingsRepository.getEdgeFadeWidth()
                edgeColorMode = settingsRepository.getEdgeColorMode()
                panEnabled = settingsRepository.isPanEnabled()
                panInverted = settingsRepository.isPanInverted()
                panSpeed = settingsRepository.getPanSpeed()
                animationFps = settingsRepository.getAnimationFps()
                changeOnScreenOff = settingsRepository.isChangeOnScreenOffEnabled()
                gpuRendering = settingsRepository.isGpuRenderingEnabled()
            }
            Log.d(TAG, "Settings refreshed: fit=$displayModeFit zoom=$zoomOutEnabled fps=$animationFps gpu=$gpuRendering")
        }

        // ---------------------------------------------------------------
        // フェードアニメーション
        // ---------------------------------------------------------------

        private fun startFadeAnimation() {
            if (nextBitmap == null || isAnimating) return
            isAnimating = true
            cancelZoom()

            fadeJob?.cancel()
            fadeJob = scope.launch {
                val duration = 800L
                val startTime = System.currentTimeMillis()
                while (isActive) {
                    val elapsed = System.currentTimeMillis() - startTime
                    val fraction = (elapsed.toFloat() / duration).coerceIn(0f, 1f)
                    fadeAlpha = (fraction * 255).toInt()
                    drawFrame()
                    if (fraction >= 1f) break
                    delay(frameDelayMs)
                }
                currentBitmap?.recycle()
                currentBitmap = nextBitmap
                nextBitmap = null
                currentBgColor = nextBgColor
                fadeAlpha = 255
                isAnimating = false
                panOffsetX = 0f
                panOffsetY = 0f
                drawFrame()
                startZoomOutIfNeeded()
            }
        }

        // ---------------------------------------------------------------
        // ズームアウトアニメーション
        // 常に cover(画面いっぱい) → fit(画像全体表示) へズームアウト
        // ズーム後は画像全体表示を維持
        // ---------------------------------------------------------------

        private fun cancelZoom() {
            zoomJob?.cancel()
            zoomJob = null
            isZooming = false
        }

        private fun startZoomOutIfNeeded() {
            Log.d(TAG, "zoomCheck: enabled=$zoomOutEnabled zooming=$isZooming bitmap=${currentBitmap != null}")
            if (!zoomOutEnabled || isZooming) return
            if (currentBitmap == null) return
            isZooming = true
            zoomProgress = 0f
            Log.d(TAG, "Zoom START: duration=${zoomOutDurationMs}ms fit=$displayModeFit")

            zoomJob = scope.launch {
                val startTime = System.currentTimeMillis()
                while (isActive) {
                    val elapsed = System.currentTimeMillis() - startTime
                    val rawFraction = (elapsed.toFloat() / zoomOutDurationMs).coerceIn(0f, 1f)
                    // DecelerateInterpolator(factor=2): 1 - (1-t)^4
                    val inv = 1f - rawFraction
                    zoomProgress = 1f - inv * inv * inv * inv
                    drawFrame()
                    if (rawFraction >= 1f) break
                    delay(frameDelayMs)
                }
                zoomProgress = 1f
                isZooming = false
                drawFrame()
                Log.d(TAG, "Zoom END")
            }
        }

        // ---------------------------------------------------------------
        // スティックパン
        // ---------------------------------------------------------------

        private fun startPanLoop() {
            panJob?.cancel()
            panJob = scope.launch {
                while (isActive) {
                    if (panVelocityX != 0f || panVelocityY != 0f) {
                        panOffsetX += panVelocityX
                        panOffsetY += panVelocityY
                        clampPanOffset()
                        drawFrame()
                    }
                    delay(frameDelayMs)
                }
            }
        }

        private fun clampPanOffset() {
            val bitmap = currentBitmap ?: return
            val scaleX = surfaceWidth.toFloat() / bitmap.width
            val scaleY = surfaceHeight.toFloat() / bitmap.height
            val coverScale = maxOf(scaleX, scaleY)
            val fitScale = minOf(scaleX, scaleY)
            val scale = getCurrentScale(coverScale, fitScale)
            val scaledW = bitmap.width * scale
            val scaledH = bitmap.height * scale

            if (scaledW > surfaceWidth) {
                val maxOff = (scaledW - surfaceWidth) / 2f
                panOffsetX = panOffsetX.coerceIn(-maxOff, maxOff)
            } else {
                val maxOff = (surfaceWidth - scaledW) / 2f
                panOffsetX = panOffsetX.coerceIn(-maxOff, maxOff)
            }
            if (scaledH > surfaceHeight) {
                val maxOff = (scaledH - surfaceHeight) / 2f
                panOffsetY = panOffsetY.coerceIn(-maxOff, maxOff)
            } else {
                val maxOff = (surfaceHeight - scaledH) / 2f
                panOffsetY = panOffsetY.coerceIn(-maxOff, maxOff)
            }
        }

        // ---------------------------------------------------------------
        // 描画
        // ---------------------------------------------------------------

        private fun getCurrentScale(coverScale: Float, fitScale: Float): Float {
            return when {
                // ズーム中: 常に cover(画面いっぱい) → fit(画像全体表示) へ
                isZooming -> coverScale + (fitScale - coverScale) * zoomProgress
                // ズーム有効時はズーム後も画像全体表示を維持
                displayModeFit || zoomOutEnabled -> fitScale
                else -> coverScale
            }
        }

        private fun drawFrame() {
            val holder = surfaceHolder
            var canvas: Canvas? = null
            try {
                // 初回描画で Canvas タイプを確定（同一 Surface では混在不可）
                val useHardware = canvasTypeLocked ?: gpuRendering
                canvas = if (useHardware) {
                    try {
                        holder.lockHardwareCanvas().also { canvasTypeLocked = true }
                    } catch (_: Exception) {
                        holder.lockCanvas().also { canvasTypeLocked = false }
                    }
                } else {
                    holder.lockCanvas().also { canvasTypeLocked = false }
                }
                canvas?.let { draw(it) }
            } catch (e: Exception) {
                Log.w(TAG, "drawFrame error", e)
            } finally {
                canvas?.let {
                    try { holder.unlockCanvasAndPost(it) } catch (_: Exception) {}
                }
            }
        }

        private fun draw(canvas: Canvas) {
            val w = canvas.width
            val h = canvas.height
            canvas.drawColor(Color.BLACK)

            // 余白の背景描画（平均色で塗りつぶし）
            if (edgeFillEnabled) {
                canvas.drawColor(currentBgColor)
            }

            currentBitmap?.let { curr ->
                paint.alpha = 255
                drawBitmapScaled(canvas, curr, paint, w, h, isCurrentImage = true)
                if (edgeFillEnabled) {
                    drawEdgeFade(canvas, curr, w, h, currentBgColor, 255, isCurrentImage = true)
                }
            }

            if (isAnimating) {
                // フェード中: 次の背景色をアルファ付きで重ねる
                if (edgeFillEnabled) {
                    overlayPaint.color = Color.argb(fadeAlpha, Color.red(nextBgColor), Color.green(nextBgColor), Color.blue(nextBgColor))
                    canvas.drawRect(0f, 0f, w.toFloat(), h.toFloat(), overlayPaint)
                }
                nextBitmap?.let { next ->
                    paint.alpha = fadeAlpha
                    drawBitmapScaled(canvas, next, paint, w, h, isCurrentImage = false)
                    if (edgeFillEnabled) {
                        drawEdgeFade(canvas, next, w, h, nextBgColor, fadeAlpha, isCurrentImage = false)
                    }
                }
            }

            // ステータスバーオーバーレイ
            if (statusBarOverlayHeight > 0) {
                val density = resources.displayMetrics.density
                val overlayH = statusBarOverlayHeight * density
                overlayPaint.color = Color.argb(128, 80, 80, 80)
                canvas.drawRect(0f, 0f, w.toFloat(), overlayH, overlayPaint)
            }

            // ロック画面オーバーレイ（角丸）
            if (lockOverlayRects.isNotEmpty()) {
                val km = this@AutoWallpaperService.getSystemService(Context.KEYGUARD_SERVICE) as? KeyguardManager
                if (km?.isKeyguardLocked == true) {
                    val density = resources.displayMetrics.density
                    val cornerRadius = 16f * density
                    for (rect in lockOverlayRects) {
                        overlayPaint.color = Color.argb((rect.alpha * 255).toInt(), 0, 0, 0)
                        canvas.drawRoundRect(
                            rect.left * w,
                            rect.top * h,
                            (rect.left + rect.width) * w,
                            (rect.top + rect.height) * h,
                            cornerRadius, cornerRadius,
                            overlayPaint
                        )
                    }
                }
            }

            if (currentBitmap == null && !isAnimating) {
                canvas.drawText("画像を読み込み中...", w / 2f, h / 2f, textPaint)
            }
        }

        /**
         * 設定に応じた方法で余白の補完色を算出する。
         */
        private fun computeEdgeColor(src: Bitmap): Int {
            return when (edgeColorMode) {
                EdgeColorMode.BLACK -> Color.BLACK
                EdgeColorMode.WHITE -> Color.WHITE
                EdgeColorMode.CORNER_AVERAGE -> computeCornerAverage(src)
                EdgeColorMode.DOMINANT -> computeDominantEdgeColor(src)
                EdgeColorMode.EDGE_AVERAGE -> computeEdgeAverage(src)
            }
        }

        /** 四辺全ピクセルの平均色 */
        private fun computeEdgeAverage(src: Bitmap): Int {
            val w = src.width; val h = src.height
            if (w == 0 || h == 0) return Color.BLACK
            val topRow = IntArray(w); val bottomRow = IntArray(w)
            val leftCol = IntArray(h); val rightCol = IntArray(h)
            src.getPixels(topRow, 0, w, 0, 0, w, 1)
            src.getPixels(bottomRow, 0, w, 0, h - 1, w, 1)
            src.getPixels(leftCol, 0, 1, 0, 0, 1, h)
            src.getPixels(rightCol, 0, 1, w - 1, 0, 1, h)
            var r = 0L; var g = 0L; var b = 0L
            for (p in topRow) { r += Color.red(p); g += Color.green(p); b += Color.blue(p) }
            for (p in bottomRow) { r += Color.red(p); g += Color.green(p); b += Color.blue(p) }
            for (p in leftCol) { r += Color.red(p); g += Color.green(p); b += Color.blue(p) }
            for (p in rightCol) { r += Color.red(p); g += Color.green(p); b += Color.blue(p) }
            val count = (w + w + h + h).toLong()
            return Color.rgb((r / count).toInt(), (g / count).toInt(), (b / count).toInt())
        }

        /** 四隅ピクセルの平均色 */
        private fun computeCornerAverage(src: Bitmap): Int {
            val w = src.width; val h = src.height
            if (w == 0 || h == 0) return Color.BLACK
            val corners = intArrayOf(
                src.getPixel(0, 0), src.getPixel(w - 1, 0),
                src.getPixel(0, h - 1), src.getPixel(w - 1, h - 1)
            )
            var r = 0; var g = 0; var b = 0
            for (p in corners) { r += Color.red(p); g += Color.green(p); b += Color.blue(p) }
            return Color.rgb(r / 4, g / 4, b / 4)
        }

        /** 辺ピクセルの最頻色（RGB各5ビットに量子化してヒストグラム） */
        private fun computeDominantEdgeColor(src: Bitmap): Int {
            val w = src.width; val h = src.height
            if (w == 0 || h == 0) return Color.BLACK
            val topRow = IntArray(w); val bottomRow = IntArray(w)
            val leftCol = IntArray(h); val rightCol = IntArray(h)
            src.getPixels(topRow, 0, w, 0, 0, w, 1)
            src.getPixels(bottomRow, 0, w, 0, h - 1, w, 1)
            src.getPixels(leftCol, 0, 1, 0, 0, 1, h)
            src.getPixels(rightCol, 0, 1, w - 1, 0, 1, h)
            // RGB各5ビット(32段階)=32768 bins
            val hist = IntArray(32768)
            fun add(p: Int) {
                val ri = Color.red(p) shr 3
                val gi = Color.green(p) shr 3
                val bi = Color.blue(p) shr 3
                hist[(ri shl 10) or (gi shl 5) or bi]++
            }
            for (p in topRow) add(p); for (p in bottomRow) add(p)
            for (p in leftCol) add(p); for (p in rightCol) add(p)
            var maxIdx = 0; var maxCount = 0
            for (i in hist.indices) { if (hist[i] > maxCount) { maxCount = hist[i]; maxIdx = i } }
            val ri = (maxIdx shr 10) and 0x1F
            val gi = (maxIdx shr 5) and 0x1F
            val bi = maxIdx and 0x1F
            return Color.rgb((ri shl 3) or (ri shr 2), (gi shl 3) or (gi shr 2), (bi shl 3) or (bi shr 2))
        }

        /**
         * 画像の縁にグラデーションを描画して背景色と滑らかに繋ぐ（キャッシュ版）。
         * LinearGradient シェーダーは画像矩形・色が変わったときだけ再生成し、
         * フェード中のアルファ変化は Paint.alpha で処理する。
         */
        private fun drawEdgeFade(
            canvas: Canvas, bitmap: Bitmap,
            canvasW: Int, canvasH: Int,
            bgColor: Int, alpha: Int,
            isCurrentImage: Boolean
        ) {
            val density = resources.displayMetrics.density
            val fadeW = edgeFadeWidthDp * density
            if (fadeW <= 0f) return

            val scaleX = canvasW.toFloat() / bitmap.width
            val scaleY = canvasH.toFloat() / bitmap.height
            val coverScale = maxOf(scaleX, scaleY)
            val fitScale = minOf(scaleX, scaleY)
            val scale = if (isCurrentImage) getCurrentScale(coverScale, fitScale)
                        else if (displayModeFit) fitScale else coverScale
            val scaledW = bitmap.width * scale
            val scaledH = bitmap.height * scale
            val imgLeft = (canvasW - scaledW) / 2f + if (isCurrentImage) panOffsetX else 0f
            val imgTop = (canvasH - scaledH) / 2f + if (isCurrentImage) panOffsetY else 0f
            val imgRight = imgLeft + scaledW
            val imgBottom = imgTop + scaledH

            val cache = if (isCurrentImage) currentEdgeCache else nextEdgeCache
            cache.draw(canvas, alpha, imgLeft, imgTop, imgRight, imgBottom,
                       fadeW, bgColor, canvasW, canvasH)
        }

        private fun drawBitmapScaled(
            canvas: Canvas, bitmap: Bitmap, paint: Paint,
            width: Int, height: Int, isCurrentImage: Boolean
        ) {
            val scaleX = width.toFloat() / bitmap.width
            val scaleY = height.toFloat() / bitmap.height
            val coverScale = maxOf(scaleX, scaleY)
            val fitScale = minOf(scaleX, scaleY)

            val scale = if (isCurrentImage) {
                getCurrentScale(coverScale, fitScale)
            } else {
                if (displayModeFit) fitScale else coverScale
            }

            val scaledW = bitmap.width * scale
            val scaledH = bitmap.height * scale
            val left = (width - scaledW) / 2f + if (isCurrentImage) panOffsetX else 0f
            val top = (height - scaledH) / 2f + if (isCurrentImage) panOffsetY else 0f
            canvas.drawBitmap(bitmap, null, RectF(left, top, left + scaledW, top + scaledH), paint)
        }

        /**
         * 4辺のグラデーションシェーダーをキャッシュし、
         * 画像矩形や背景色が変わったときだけ再生成する。
         * フェード中のアルファ変化は Paint.alpha で反映するため
         * シェーダー自体は不透明色→透明色の固定で作る。
         */
        private inner class GradientEdgeCache {
            // キャッシュキー
            private var cImgL = Float.NaN
            private var cImgT = 0f; private var cImgR = 0f; private var cImgB = 0f
            private var cFadeW = 0f; private var cBgRgb = 0
            private var cCanvasW = 0; private var cCanvasH = 0

            // 辺ごとのキャッシュ (0=左, 1=右, 2=上, 3=下)
            private val paints = Array(4) { Paint() }
            private val rects = Array(4) { RectF() }
            private val active = BooleanArray(4)

            fun draw(
                canvas: Canvas, alpha: Int,
                imgL: Float, imgT: Float, imgR: Float, imgB: Float,
                fadeW: Float, bgColor: Int, canvasW: Int, canvasH: Int
            ) {
                val bgRgb = bgColor or (0xFF.shl(24))
                if (imgL != cImgL || imgT != cImgT || imgR != cImgR || imgB != cImgB
                    || fadeW != cFadeW || bgRgb != cBgRgb
                    || canvasW != cCanvasW || canvasH != cCanvasH
                ) {
                    rebuild(imgL, imgT, imgR, imgB, fadeW, bgRgb, canvasW, canvasH)
                }
                for (i in 0..3) {
                    if (active[i]) {
                        paints[i].alpha = alpha
                        canvas.drawRect(rects[i], paints[i])
                    }
                }
            }

            private fun rebuild(
                imgL: Float, imgT: Float, imgR: Float, imgB: Float,
                fadeW: Float, bgRgb: Int, canvasW: Int, canvasH: Int
            ) {
                cImgL = imgL; cImgT = imgT; cImgR = imgR; cImgB = imgB
                cFadeW = fadeW; cBgRgb = bgRgb; cCanvasW = canvasW; cCanvasH = canvasH

                val opaque = bgRgb // 0xFF_RR_GG_BB
                val transparent = Color.argb(0, Color.red(bgRgb), Color.green(bgRgb), Color.blue(bgRgb))

                // 左
                active[0] = imgL > 0
                if (active[0]) {
                    paints[0].shader = LinearGradient(imgL, 0f, imgL + fadeW, 0f, opaque, transparent, Shader.TileMode.CLAMP)
                    rects[0].set(imgL, imgT, imgL + fadeW, imgB)
                }
                // 右
                active[1] = imgR < canvasW
                if (active[1]) {
                    paints[1].shader = LinearGradient(imgR, 0f, imgR - fadeW, 0f, opaque, transparent, Shader.TileMode.CLAMP)
                    rects[1].set(imgR - fadeW, imgT, imgR, imgB)
                }
                // 上
                active[2] = imgT > 0
                if (active[2]) {
                    paints[2].shader = LinearGradient(0f, imgT, 0f, imgT + fadeW, opaque, transparent, Shader.TileMode.CLAMP)
                    rects[2].set(imgL, imgT, imgR, imgT + fadeW)
                }
                // 下
                active[3] = imgB < canvasH
                if (active[3]) {
                    paints[3].shader = LinearGradient(0f, imgB, 0f, imgB - fadeW, opaque, transparent, Shader.TileMode.CLAMP)
                    rects[3].set(imgL, imgB - fadeW, imgR, imgB)
                }
            }
        }
    }
}
