package com.wallpaper.auto.ui.safebooru

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.wallpaper.auto.data.api.pixiv.PixivConstants
import com.wallpaper.auto.data.api.pixiv.PixivFetchMode
import com.wallpaper.auto.data.api.pixiv.PixivMultiPageMode
import com.wallpaper.auto.data.repository.BooruSource
import com.wallpaper.auto.ui.pixiv.PixivLoginDialog

val PRESET_TAGS = listOf("highres", "wallpaper", "landscape", "scenery", "night_sky", "cityscape")

private val RANKING_MODES = listOf(
    "day" to "日間",
    "week" to "週間",
    "month" to "月間",
    "day_male" to "男性向け",
    "day_female" to "女性向け",
    "week_original" to "オリジナル",
    "week_rookie" to "ルーキー"
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SafebooruScreen(viewModel: SafebooruViewModel = hiltViewModel()) {
    val activeTags by viewModel.activeTags.collectAsState()
    val searchQueries by viewModel.searchQueries.collectAsState()
    val previewPosts by viewModel.previewPosts.collectAsState(initial = emptyList())
    val isLoading by viewModel.isLoading.collectAsState()
    val errorMessage by viewModel.errorMessage.collectAsState()
    val downloadedCount by viewModel.downloadedCount.collectAsState()
    val downloadMessage by viewModel.downloadMessage.collectAsState()
    val booruSource by viewModel.booruSource.collectAsState()
    val pixivLoggedIn by viewModel.pixivLoggedIn.collectAsState()
    val pixivUserName by viewModel.pixivUserName.collectAsState()
    val pixivFetchMode by viewModel.pixivFetchMode.collectAsState()
    val pixivRankingMode by viewModel.pixivRankingMode.collectAsState()
    val pixivSearchWord by viewModel.pixivSearchWord.collectAsState()
    val pixivSearchQueries by viewModel.pixivSearchQueries.collectAsState()
    val maxCacheCount by viewModel.maxCacheCount.collectAsState()
    val isDownloading by viewModel.isDownloading.collectAsState()
    val pixivPagingEnabled by viewModel.pixivPagingEnabled.collectAsState()
    val pixivPagingMaxPages by viewModel.pixivPagingMaxPages.collectAsState()
    val pixivMultiPageMode by viewModel.pixivMultiPageMode.collectAsState()
    val mixedSources by viewModel.mixedSources.collectAsState()
    var customTagInput by remember { mutableStateOf("") }

    // 設定画面で変更された保存枚数上限を反映
    LaunchedEffect(Unit) { viewModel.refreshSettings() }

    // ミックスモード時に実際に使われるサブソース集合 (空ならデフォルトの Safebooru/Danbooru)
    val effectiveMixedSources = remember(mixedSources) {
        if (mixedSources.isEmpty()) {
            setOf(BooruSource.SAFEBOORU, BooruSource.DANBOORU)
        } else mixedSources
    }
    val isMixed = booruSource == BooruSource.MIXED
    val showPixivUi = booruSource == BooruSource.PIXIV ||
        (isMixed && effectiveMixedSources.contains(BooruSource.PIXIV))
    val showBooruUi = booruSource == BooruSource.SAFEBOORU ||
        booruSource == BooruSource.DANBOORU ||
        (isMixed && (
            effectiveMixedSources.contains(BooruSource.SAFEBOORU) ||
            effectiveMixedSources.contains(BooruSource.DANBOORU)
        ))
    // ミックスで booru プレビューを行う際に使用するサブソース
    // (両方有効なら Safebooru、片方だけならそちら)
    val booruPreviewSource = when {
        isMixed && effectiveMixedSources.contains(BooruSource.SAFEBOORU) -> BooruSource.SAFEBOORU
        isMixed && effectiveMixedSources.contains(BooruSource.DANBOORU) -> BooruSource.DANBOORU
        else -> BooruSource.SAFEBOORU
    }
    var showPixivLogin by remember { mutableStateOf(false) }

    if (showPixivLogin) {
        PixivLoginDialog(
            onCodeReceived = { code, verifier ->
                showPixivLogin = false
                viewModel.loginToPixiv(code, verifier)
            },
            onDismiss = { showPixivLogin = false }
        )
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        // Source selector
        item {
            Text("画像ソース", style = MaterialTheme.typography.titleLarge)
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.padding(vertical = 4.dp)
            ) {
                items(BooruSource.values().toList()) { source ->
                    FilterChip(
                        selected = booruSource == source,
                        onClick = { viewModel.setBooruSource(source) },
                        label = {
                            Text(
                                when (source) {
                                    BooruSource.SAFEBOORU -> "Safebooru"
                                    BooruSource.DANBOORU -> "Danbooru"
                                    BooruSource.PIXIV -> "Pixiv"
                                    BooruSource.MIXED -> "ミックス"
                                }
                            )
                        }
                    )
                }
            }
            if (booruSource == BooruSource.MIXED) {
                Spacer(Modifier.height(4.dp))
                Text(
                    "ミックスに含めるソース (各DLでランダムに選ばれます)",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.padding(vertical = 4.dp)
                ) {
                    items(
                        listOf(
                            BooruSource.SAFEBOORU,
                            BooruSource.DANBOORU,
                            BooruSource.PIXIV
                        )
                    ) { sub ->
                        FilterChip(
                            selected = mixedSources.contains(sub),
                            onClick = { viewModel.toggleMixedSource(sub) },
                            label = {
                                Text(
                                    when (sub) {
                                        BooruSource.SAFEBOORU -> "Safebooru"
                                        BooruSource.DANBOORU -> "Danbooru"
                                        BooruSource.PIXIV -> "Pixiv"
                                        else -> sub.name
                                    }
                                )
                            }
                        )
                    }
                }
                if (mixedSources.isEmpty()) {
                    Text(
                        "(未選択時は Safebooru/Danbooru の両方を使用)",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                if (mixedSources.contains(BooruSource.PIXIV) && !pixivLoggedIn) {
                    Text(
                        "※ Pixiv を含めるには下のPixivタブでログインが必要",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.error
                    )
                }
            }
        }

        // Cache status card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                )
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            "キャッシュ: ${downloadedCount} / ${maxCacheCount}枚",
                            style = MaterialTheme.typography.titleSmall
                        )
                        val statusText = when {
                            isDownloading -> downloadMessage ?: "ダウンロード中..."
                            isLoading -> "読み込み中..."
                            else -> "待機中"
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            if (isDownloading || isLoading) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(12.dp),
                                    strokeWidth = 2.dp
                                )
                                Spacer(Modifier.width(6.dp))
                            }
                            Text(
                                statusText,
                                style = MaterialTheme.typography.bodySmall,
                                color = if (isDownloading) MaterialTheme.colorScheme.primary
                                        else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                    if (downloadedCount > 0) {
                        LinearProgressIndicator(
                            progress = (downloadedCount.toFloat() / maxCacheCount).coerceIn(0f, 1f),
                            modifier = Modifier.width(60.dp),
                        )
                    }
                }
            }
        }

        // Pixiv-specific settings
        if (showPixivUi) {
            if (isMixed) {
                item {
                    Spacer(Modifier.height(8.dp))
                    Divider()
                    Spacer(Modifier.height(8.dp))
                    Text("Pixiv 設定", style = MaterialTheme.typography.titleMedium)
                }
            }
            item {
                Spacer(Modifier.height(4.dp))
                // Login status
                if (pixivLoggedIn) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("Pixivログイン済み", style = MaterialTheme.typography.labelLarge)
                            if (pixivUserName.isNotBlank()) {
                                Text(pixivUserName, style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                        OutlinedButton(onClick = { viewModel.logoutPixiv() }) {
                            Text("ログアウト")
                        }
                    }
                } else {
                    Button(
                        onClick = { showPixivLogin = true },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Pixivにログイン")
                    }
                }
            }

            if (pixivLoggedIn) {
                // Fetch mode selector
                item {
                    Spacer(Modifier.height(4.dp))
                    Text("取得モード", style = MaterialTheme.typography.labelMedium)
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.padding(vertical = 4.dp)
                    ) {
                        FilterChip(
                            selected = pixivFetchMode == PixivFetchMode.RANKING,
                            onClick = { viewModel.setPixivFetchMode(PixivFetchMode.RANKING) },
                            label = { Text("ランキング") }
                        )
                        FilterChip(
                            selected = pixivFetchMode == PixivFetchMode.SEARCH,
                            onClick = { viewModel.setPixivFetchMode(PixivFetchMode.SEARCH) },
                            label = { Text("タグ検索") }
                        )
                        FilterChip(
                            selected = pixivFetchMode == PixivFetchMode.RECOMMENDED,
                            onClick = { viewModel.setPixivFetchMode(PixivFetchMode.RECOMMENDED) },
                            label = { Text("おすすめ") }
                        )
                    }
                }

                // Ranking mode or search word
                if (pixivFetchMode == PixivFetchMode.RANKING) {
                    item {
                        Text("ランキング種類", style = MaterialTheme.typography.labelMedium)
                        LazyRow(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.padding(vertical = 4.dp)
                        ) {
                            items(RANKING_MODES) { (mode, label) ->
                                FilterChip(
                                    selected = pixivRankingMode == mode,
                                    onClick = { viewModel.setPixivRankingMode(mode) },
                                    label = { Text(label) }
                                )
                            }
                        }
                    }
                } else if (pixivFetchMode == PixivFetchMode.SEARCH) {
                    item {
                        var searchInput by remember { mutableStateOf(pixivSearchWord) }
                        OutlinedTextField(
                            value = searchInput,
                            onValueChange = { searchInput = it },
                            label = { Text("検索ワード") },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true,
                            trailingIcon = {
                                IconButton(onClick = { viewModel.setPixivSearchWord(searchInput) }) {
                                    Icon(Icons.Default.Check, "適用")
                                }
                            }
                        )
                        Spacer(Modifier.height(4.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(onClick = {
                                viewModel.setPixivSearchWord(searchInput)
                                if (isMixed) viewModel.fetchPreviewForSource(BooruSource.PIXIV)
                                else viewModel.fetchPreview()
                            }) { Text("プレビュー") }
                            OutlinedButton(onClick = {
                                viewModel.setPixivSearchWord(searchInput)
                                viewModel.savePixivSearchQuery()
                            }) {
                                Icon(Icons.Default.Save, null, Modifier.size(16.dp))
                                Spacer(Modifier.width(4.dp))
                                Text("検索ワード保存")
                            }
                        }
                    }

                    if (pixivSearchQueries.isNotEmpty()) {
                        item {
                            Spacer(Modifier.height(4.dp))
                            Text("保存済み検索ワード（自動DLで順番に使用）:", style = MaterialTheme.typography.labelMedium)
                            LazyRow(
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                modifier = Modifier.padding(vertical = 4.dp)
                            ) {
                                items(pixivSearchQueries) { query ->
                                    InputChip(
                                        selected = pixivSearchWord == query,
                                        onClick = { viewModel.applyPixivSearchQuery(query) },
                                        label = { Text(query) },
                                        trailingIcon = {
                                            IconButton(
                                                onClick = { viewModel.removePixivSearchQuery(query) },
                                                modifier = Modifier.size(20.dp)
                                            ) {
                                                Icon(Icons.Default.Close, "削除", Modifier.size(14.dp))
                                            }
                                        }
                                    )
                                }
                            }
                        }
                    }
                }

                // Preview button (for ranking / recommended modes)
                if (pixivFetchMode != PixivFetchMode.SEARCH) {
                    item {
                        Spacer(Modifier.height(4.dp))
                        Button(onClick = {
                            if (isMixed) viewModel.fetchPreviewForSource(BooruSource.PIXIV)
                            else viewModel.fetchPreview()
                        }) { Text("プレビュー") }
                    }
                }

                // Paging setting
                item {
                    Spacer(Modifier.height(8.dp))
                    Divider()
                    Spacer(Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("ページング取得", style = MaterialTheme.typography.labelLarge)
                            Text(
                                "複数ページを辿ってまとめて取得（1ページ≒30件）",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Switch(
                            checked = pixivPagingEnabled,
                            onCheckedChange = { viewModel.setPixivPagingEnabled(it) }
                        )
                    }
                    if (pixivPagingEnabled) {
                        Text(
                            "最大ページ数: ${pixivPagingMaxPages}（≒${pixivPagingMaxPages * 30}件）",
                            style = MaterialTheme.typography.bodySmall
                        )
                        Slider(
                            value = pixivPagingMaxPages.toFloat(),
                            onValueChange = { viewModel.setPixivPagingMaxPages(it.toInt()) },
                            valueRange = 2f..10f,
                            steps = 7
                        )
                    }
                }

                // Multi-page illustration mode
                item {
                    Spacer(Modifier.height(8.dp))
                    Divider()
                    Spacer(Modifier.height(8.dp))
                    Text("複数枚イラストの処理", style = MaterialTheme.typography.labelLarge)
                    Text(
                        "複数ページのマンガ・イラストをどう扱うか",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(Modifier.height(4.dp))
                    PixivMultiPageMode.values().forEach { mode ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(
                                selected = pixivMultiPageMode == mode,
                                onClick = { viewModel.setPixivMultiPageMode(mode) }
                            )
                            Column(modifier = Modifier.padding(start = 4.dp)) {
                                Text(
                                    when (mode) {
                                        PixivMultiPageMode.FIRST_PAGE_ONLY -> "1ページ目のみ"
                                        PixivMultiPageMode.RANDOM_PAGE -> "ランダムで1枚"
                                    }
                                )
                                Text(
                                    when (mode) {
                                        PixivMultiPageMode.FIRST_PAGE_ONLY -> "表紙のみを壁紙にする"
                                        PixivMultiPageMode.RANDOM_PAGE -> "毎回ランダムに1ページ選ぶ"
                                    },
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }
        }

        // Booru-specific tag management (Safebooru/Danbooru)
        if (showBooruUi) {
            if (isMixed) {
                item {
                    Spacer(Modifier.height(8.dp))
                    Divider()
                    Spacer(Modifier.height(8.dp))
                    Text("Booru (Safebooru/Danbooru) 設定", style = MaterialTheme.typography.titleMedium)
                }
            }
            item {
                Spacer(Modifier.height(4.dp))
                Text("タグ管理", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(4.dp))
                Text("よく使うタグ:", style = MaterialTheme.typography.labelMedium)
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.padding(vertical = 4.dp)
                ) {
                    items(PRESET_TAGS) { tag ->
                        FilterChip(
                            selected = activeTags.contains(tag),
                            onClick = { viewModel.toggleTag(tag) },
                            label = { Text(tag) }
                        )
                    }
                }
            }

            item {
                Spacer(Modifier.height(4.dp))
                Text("現在のタグ:", style = MaterialTheme.typography.labelMedium)
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.padding(vertical = 4.dp)
                ) {
                    items(activeTags) { tag ->
                        InputChip(
                            selected = true,
                            onClick = { viewModel.removeTag(tag) },
                            label = { Text(tag) },
                            trailingIcon = { Icon(Icons.Default.Close, "削除", Modifier.size(16.dp)) }
                        )
                    }
                }
            }

            item {
                Text(
                    "※ danbooruサイトの検索バーに入力すると検索ワードがわかりやすい",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = customTagInput,
                        onValueChange = { customTagInput = it },
                        label = { Text("カスタムタグ") },
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                    IconButton(onClick = {
                        if (customTagInput.isNotBlank()) {
                            viewModel.addTag(customTagInput.trim())
                            customTagInput = ""
                        }
                    }) {
                        Icon(Icons.Default.Add, "追加")
                    }
                }
            }

            item {
                Spacer(Modifier.height(4.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = {
                        if (isMixed) viewModel.fetchPreviewForSource(booruPreviewSource)
                        else viewModel.fetchPreview()
                    }) { Text("プレビュー") }
                    OutlinedButton(onClick = { viewModel.saveCurrentAsQuery() }) {
                        Icon(Icons.Default.Save, null, Modifier.size(16.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("検索クエリ保存")
                    }
                }
            }

            if (searchQueries.isNotEmpty()) {
                item {
                    Spacer(Modifier.height(4.dp))
                    Text("保存済み検索クエリ（自動DLで順番に使用）:", style = MaterialTheme.typography.labelMedium)
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.padding(vertical = 4.dp)
                    ) {
                        items(searchQueries) { query ->
                            InputChip(
                                selected = true,
                                onClick = {
                                    val tags = query.split(" ").filter { it.isNotBlank() }
                                    tags.forEach { viewModel.addTag(it) }
                                },
                                label = { Text(query) },
                                trailingIcon = {
                                    IconButton(
                                        onClick = { viewModel.removeSearchQuery(query) },
                                        modifier = Modifier.size(20.dp)
                                    ) {
                                        Icon(Icons.Default.Close, "削除", Modifier.size(14.dp))
                                    }
                                }
                            )
                        }
                    }
                }
            }
        }

        // Messages
        item {
            downloadMessage?.let { msg ->
                if (!isDownloading) {
                    Text(text = msg, color = MaterialTheme.colorScheme.primary,
                        style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(vertical = 4.dp))
                }
            }
            errorMessage?.let { msg ->
                Text(text = msg, color = MaterialTheme.colorScheme.error,
                    style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(vertical = 4.dp))
            }
        }

        // Preview grid
        if (isLoading) {
            item {
                Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator()
                }
            }
        } else if (previewPosts.isNotEmpty()) {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("検索結果:", style = MaterialTheme.typography.labelMedium)
                    TextButton(onClick = { viewModel.downloadAll() }) {
                        Icon(Icons.Default.Download, null, Modifier.size(16.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("全てDL")
                    }
                }
            }
            val rows = previewPosts.chunked(3)
            val isPixiv = booruSource == BooruSource.PIXIV
            items(rows.size) { rowIndex ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    for (post in rows[rowIndex]) {
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .aspectRatio(1f)
                                .padding(2.dp)
                        ) {
                            if (isPixiv) {
                                // Pixiv images need Referer header
                                val context = LocalContext.current
                                AsyncImage(
                                    model = ImageRequest.Builder(context)
                                        .data(post.previewUrl)
                                        .addHeader("Referer", PixivConstants.IMAGE_REFERER)
                                        .crossfade(true)
                                        .build(),
                                    contentDescription = null,
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier.fillMaxSize()
                                )
                            } else {
                                AsyncImage(
                                    model = post.previewUrl,
                                    contentDescription = null,
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier.fillMaxSize()
                                )
                            }
                            IconButton(
                                onClick = { viewModel.downloadPost(post) },
                                modifier = Modifier.align(Alignment.BottomEnd)
                            ) {
                                Icon(Icons.Default.Download, "ダウンロード")
                            }
                        }
                    }
                    repeat(3 - rows[rowIndex].size) {
                        Spacer(modifier = Modifier.weight(1f))
                    }
                }
            }
        }
    }
}
