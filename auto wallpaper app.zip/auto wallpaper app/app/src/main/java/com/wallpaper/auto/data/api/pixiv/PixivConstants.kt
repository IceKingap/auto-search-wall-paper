package com.wallpaper.auto.data.api.pixiv

object PixivConstants {
    const val CLIENT_ID = "MOBrBDS8blbauoSck0ZfDbtuzpyT"
    const val CLIENT_SECRET = "lsACyCD94FhDUtGTXi3QzcFE2uU1hqtDaKeqrdwj"

    const val LOGIN_URL = "https://app-api.pixiv.net/web/v1/login"
    const val AUTH_TOKEN_URL = "https://oauth.secure.pixiv.net/auth/token"
    const val REDIRECT_URI = "https://app-api.pixiv.net/web/v1/users/auth/pixiv/callback"

    const val API_BASE_URL = "https://app-api.pixiv.net"
    const val IMAGE_REFERER = "https://app-api.pixiv.net/"
    const val USER_AGENT = "PixivAndroidApp/5.0.234 (Android 11; Pixel 5)"
}
