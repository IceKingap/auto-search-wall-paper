package com.wallpaper.auto.data.api.pixiv

import android.util.Log
import com.wallpaper.auto.data.api.BooruPost
import com.wallpaper.auto.data.repository.SettingsRepository
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import javax.inject.Inject
import javax.inject.Singleton
import kotlin.random.Random

@Singleton
class PixivWallpaperProvider @Inject constructor(
    private val pixivApiService: PixivApiService,
    private val pixivAuthManager: PixivAuthManager,
    private val settingsRepository: SettingsRepository
) {
    // fetchPosts が UI(プレビュー) と WorkManager(自動DL) から同時に呼ばれても
    // 内部状態を壊さないようにロックする。
    private val fetchMutex = Mutex()
    private var searchQueryIndex = 0
    private var lastSearchWord = ""

    suspend fun fetchPosts(limit: Int = 20, randomize: Boolean = true): List<BooruPost> = fetchMutex.withLock {
        if (!pixivAuthManager.isLoggedIn()) {
            Log.w(TAG, "Not logged in to Pixiv")
            return emptyList()
        }

        val modeStr = settingsRepository.getPixivFetchMode()
        val mode = try { PixivFetchMode.valueOf(modeStr) } catch (_: Exception) { PixivFetchMode.RANKING }
        val pagingEnabled = settingsRepository.isPixivPagingEnabled()
        val maxPages = if (pagingEnabled) settingsRepository.getPixivPagingMaxPages() else 1

        return try {
            val allPosts = mutableListOf<BooruPost>()
            var nextOffset: Int? = null
            var isFirstPage = true

            for (page in 0 until maxPages) {
                val response = when (mode) {
                    PixivFetchMode.RANKING -> {
                        val rankingMode = settingsRepository.getPixivRankingMode()
                        val offset = if (isFirstPage && randomize) Random.nextInt(0, 300)
                                     else nextOffset
                        pixivApiService.illustRanking(mode = rankingMode, offset = offset)
                    }
                    PixivFetchMode.SEARCH -> {
                        val word = if (isFirstPage) pickNextSearchWord() else lastSearchWord
                        if (word.isBlank()) break
                        val offset = if (isFirstPage && randomize) Random.nextInt(0, 60)
                                     else nextOffset
                        if (isFirstPage) {
                            lastSearchWord = word
                            Log.d(TAG, "Pixiv search: '$word' offset=$offset")
                        }
                        pixivApiService.searchIllust(word = word, offset = offset)
                    }
                    PixivFetchMode.RECOMMENDED -> {
                        val offset = if (isFirstPage && randomize) Random.nextInt(0, 300)
                                     else nextOffset
                        pixivApiService.illustRecommended(offset = offset)
                    }
                }

                val multiPageMode = try {
                    PixivMultiPageMode.valueOf(settingsRepository.getPixivMultiPageMode())
                } catch (_: Exception) { PixivMultiPageMode.FIRST_PAGE_ONLY }

                val illusts = response.illusts
                    .filter { it.type != "ugoira" && it.xRestrict == 0 }
                val multiPageIllusts = illusts.count { it.metaPages.size > 1 }
                if (isFirstPage) {
                    Log.d(TAG, "Fetch: mode=$multiPageMode illusts=${illusts.size} " +
                        "multiPage=$multiPageIllusts")
                }
                val posts = illusts
                    .flatMap { it.toBooruPosts(multiPageMode) }
                    .filter { it.imageUrl.isNotBlank() }
                allPosts.addAll(posts)

                if (allPosts.size >= limit) break

                // nextUrl からオフセットを抽出して次ページへ
                nextOffset = parseOffsetFromUrl(response.nextUrl) ?: break
                isFirstPage = false
                Log.d(TAG, "Pixiv paging: page=${page + 1} collected=${allPosts.size} nextOffset=$nextOffset")
            }

            allPosts.take(limit)
        } catch (e: Exception) {
            Log.e(TAG, "Pixiv fetch failed (mode=$mode)", e)
            emptyList()
        }
    }

    /** nextUrl のクエリパラメータから offset を取り出す */
    private fun parseOffsetFromUrl(url: String?): Int? {
        if (url.isNullOrBlank()) return null
        return try {
            android.net.Uri.parse(url).getQueryParameter("offset")?.toIntOrNull()
        } catch (_: Exception) { null }
    }

    private suspend fun pickNextSearchWord(): String {
        val queries = settingsRepository.getPixivSearchQueries()
        if (queries.isEmpty()) {
            return settingsRepository.getPixivSearchWord()
        }
        val idx = searchQueryIndex % queries.size
        searchQueryIndex++
        return queries[idx]
    }

    companion object {
        private const val TAG = "PixivWallpaperProvider"
    }
}
