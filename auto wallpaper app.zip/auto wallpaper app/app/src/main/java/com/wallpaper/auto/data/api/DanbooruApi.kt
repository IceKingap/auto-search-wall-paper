package com.wallpaper.auto.data.api

import retrofit2.http.GET
import retrofit2.http.Query

interface DanbooruApi {
    @GET("posts.json")
    suspend fun getPosts(
        @Query("tags") tags: String,
        @Query("limit") limit: Int = 20,
        @Query("page") page: Int = 1
    ): List<DanbooruPost>

    @GET("counts/posts.json")
    suspend fun getPostCount(
        @Query("tags") tags: String
    ): DanbooruCountResponse
}
