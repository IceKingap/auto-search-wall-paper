package com.wallpaper.auto

import android.app.WallpaperManager
import android.content.ComponentName
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import com.wallpaper.auto.service.AutoWallpaperService
import com.wallpaper.auto.service.WallpaperControlService
import com.wallpaper.auto.ui.main.MainScreen
import com.wallpaper.auto.ui.theme.AutoWallpaperTheme
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            AutoWallpaperTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    MainScreen()
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        // 壁紙ピッカーから戻ってきた後など、自前の Live Wallpaper が現在設定済みなら
        // 通知コントロールを起動する
        if (isOurWallpaperActive()) {
            try {
                WallpaperControlService.start(this)
            } catch (_: Exception) {
                // 起動失敗(権限不足など)は致命的ではない
            }
        }
    }

    private fun isOurWallpaperActive(): Boolean {
        val wm = WallpaperManager.getInstance(this)
        val current = wm.wallpaperInfo?.component
        return current == ComponentName(this, AutoWallpaperService::class.java)
    }
}
