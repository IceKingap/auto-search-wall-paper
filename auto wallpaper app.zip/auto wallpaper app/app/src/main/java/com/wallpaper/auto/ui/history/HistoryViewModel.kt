package com.wallpaper.auto.ui.history

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.wallpaper.auto.data.db.entity.ImageType
import com.wallpaper.auto.data.db.entity.LocalImage
import com.wallpaper.auto.data.db.entity.OnlineImage
import com.wallpaper.auto.data.db.entity.WallpaperHistory
import com.wallpaper.auto.data.repository.AlbumRepository
import com.wallpaper.auto.data.repository.HistoryRepository
import com.wallpaper.auto.data.repository.OnlineImageRepository
import com.wallpaper.auto.service.ImagePreloader
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class HistoryViewModel @Inject constructor(
    private val historyRepository: HistoryRepository,
    private val albumRepository: AlbumRepository,
    private val onlineImageRepository: OnlineImageRepository,
    private val imagePreloader: ImagePreloader
) : ViewModel() {

    val history = historyRepository.getRecentHistory()

    private val _imagePathMap = MutableStateFlow<Map<Long, String>>(emptyMap())
    val imagePathMap: StateFlow<Map<Long, String>> = _imagePathMap

    private val _favoritedIds = MutableStateFlow<Set<Long>>(emptySet())
    val favoritedIds: StateFlow<Set<Long>> = _favoritedIds

    private val _blacklistedIds = MutableStateFlow<Set<Long>>(emptySet())
    val blacklistedIds: StateFlow<Set<Long>> = _blacklistedIds

    private val _message = MutableStateFlow<String?>(null)
    val message: StateFlow<String?> = _message

    init {
        viewModelScope.launch {
            history.collect { items ->
                val map = mutableMapOf<Long, String>()
                val favIds = mutableSetOf<Long>()
                val blockIds = mutableSetOf<Long>()
                items.forEach { item ->
                    val record = when (item.imageType) {
                        ImageType.LOCAL -> albumRepository.getLocalImageById(item.imageRefId)
                        ImageType.ONLINE -> onlineImageRepository.getById(item.imageRefId)
                    }
                    val path = item.imagePath ?: when (record) {
                        is LocalImage -> record.filePath
                        is OnlineImage -> record.localCachePath
                        else -> null
                    }
                    if (path != null && java.io.File(path).exists()) map[item.id] = path

                    val isFav = when (record) {
                        is LocalImage -> record.isFavorite
                        is OnlineImage -> record.isFavorite
                        else -> false
                    }
                    if (isFav) favIds.add(item.id)

                    val isBlocked = when (record) {
                        is LocalImage -> record.isBlacklisted
                        is OnlineImage -> record.isBlacklisted
                        else -> false
                    }
                    if (isBlocked) blockIds.add(item.id)
                }
                _imagePathMap.value = map
                _favoritedIds.value = favIds
                _blacklistedIds.value = blockIds
            }
        }
    }

    fun restoreWallpaper(item: WallpaperHistory) = viewModelScope.launch {
        // 履歴の元画像のパスを取得し、強制的に次に表示させる
        val path: String? = when (item.imageType) {
            ImageType.LOCAL -> albumRepository.getLocalImageById(item.imageRefId)?.filePath
            ImageType.ONLINE -> onlineImageRepository.getById(item.imageRefId)?.localCachePath
        }
        if (path == null || !java.io.File(path).exists()) {
            _message.value = "元画像が見つかりません"
            return@launch
        }
        imagePreloader.setForcedNextImage(item.imageType, item.imageRefId, path)
        imagePreloader.requestSkip()
        _message.value = "壁紙を切り替えています"
    }

    fun addToFavorites(item: WallpaperHistory) = viewModelScope.launch {
        when (item.imageType) {
            ImageType.LOCAL -> {
                val image = albumRepository.getLocalImageById(item.imageRefId)
                if (image != null) {
                    albumRepository.setFavorite(item.imageRefId, true)
                    _favoritedIds.value = _favoritedIds.value + item.id
                    _message.value = "お気に入りに追加しました"
                } else {
                    _message.value = "画像が見つかりません"
                }
            }
            ImageType.ONLINE -> {
                val image = onlineImageRepository.getById(item.imageRefId)
                if (image != null) {
                    onlineImageRepository.setFavorite(item.imageRefId, true)
                    _favoritedIds.value = _favoritedIds.value + item.id
                    _message.value = "お気に入りに追加しました"
                } else {
                    _message.value = "キャッシュ削除済みのため追加できません"
                }
            }
        }
    }

    /** この画像を二度と壁紙に使用しないようブラックリストに追加する。 */
    fun blacklistWallpaper(item: WallpaperHistory) = viewModelScope.launch {
        when (item.imageType) {
            ImageType.LOCAL -> {
                val image = albumRepository.getLocalImageById(item.imageRefId)
                if (image != null) {
                    albumRepository.setBlacklisted(item.imageRefId, true)
                    _blacklistedIds.value = _blacklistedIds.value + item.id
                    _message.value = "この画像はもう表示されません"
                } else {
                    _message.value = "画像が見つかりません"
                }
            }
            ImageType.ONLINE -> {
                val image = onlineImageRepository.getById(item.imageRefId)
                if (image != null) {
                    onlineImageRepository.setBlacklisted(item.imageRefId, true)
                    _blacklistedIds.value = _blacklistedIds.value + item.id
                    _message.value = "この画像はもう表示されません"
                } else {
                    _message.value = "キャッシュ削除済みのため操作できません"
                }
            }
        }
    }

    /** ブラックリストを解除する（取り消し用）。 */
    fun unblacklistWallpaper(item: WallpaperHistory) = viewModelScope.launch {
        when (item.imageType) {
            ImageType.LOCAL -> albumRepository.setBlacklisted(item.imageRefId, false)
            ImageType.ONLINE -> onlineImageRepository.setBlacklisted(item.imageRefId, false)
        }
        _blacklistedIds.value = _blacklistedIds.value - item.id
        _message.value = "ブラックリストから解除しました"
    }

    fun clearMessage() {
        _message.value = null
    }
}
