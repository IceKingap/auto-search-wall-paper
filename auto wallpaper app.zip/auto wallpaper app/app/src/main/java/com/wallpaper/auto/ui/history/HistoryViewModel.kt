package com.wallpaper.auto.ui.history

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.wallpaper.auto.data.db.entity.ImageType
import com.wallpaper.auto.data.db.entity.LocalImage
import com.wallpaper.auto.data.db.entity.OnlineImage
import com.wallpaper.auto.data.db.entity.WallpaperHistory
import com.wallpaper.auto.data.repository.AlbumRepository
import com.wallpaper.auto.data.repository.HistoryRepository
import com.wallpaper.auto.data.repository.OnlineImageRepository
import com.wallpaper.auto.service.ImagePreloader
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class HistoryViewModel @Inject constructor(
    private val historyRepository: HistoryRepository,
    private val albumRepository: AlbumRepository,
    private val onlineImageRepository: OnlineImageRepository,
    private val imagePreloader: ImagePreloader
) : ViewModel() {

    val history = historyRepository.getRecentHistory()

    // setFavorite / setBlacklisted のたびに bump することで、
    // _favoritedIds/_blacklistedIds が最新 DB 値を再読込する。
    // これにより "collect 中に toggle → 古い値で上書き" のレースを防ぐ。
    private val refreshTrigger = MutableStateFlow(0L)

    private val derived = history.combine(refreshTrigger) { items, _ -> items }
        .map { items ->
            val map = mutableMapOf<Long, String>()
            val favIds = mutableSetOf<Long>()
            val blockIds = mutableSetOf<Long>()
            items.forEach { item ->
                val record: Any? = when (item.imageType) {
                    ImageType.LOCAL -> albumRepository.getLocalImageById(item.imageRefId)
                    ImageType.ONLINE -> onlineImageRepository.getById(item.imageRefId)
                }
                val path = item.imagePath ?: when (record) {
                    is LocalImage -> record.filePath
                    is OnlineImage -> record.localCachePath
                    else -> null
                }
                if (path != null && java.io.File(path).exists()) map[item.id] = path

                val isFav = when (record) {
                    is LocalImage -> record.isFavorite
                    is OnlineImage -> record.isFavorite
                    else -> false
                }
                if (isFav) favIds.add(item.id)

                val isBlocked = when (record) {
                    is LocalImage -> record.isBlacklisted
                    is OnlineImage -> record.isBlacklisted
                    else -> false
                }
                if (isBlocked) blockIds.add(item.id)
            }
            Triple(map.toMap(), favIds.toSet(), blockIds.toSet())
        }
        .flowOn(Dispatchers.IO)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), Triple(emptyMap(), emptySet(), emptySet()))

    val imagePathMap: StateFlow<Map<Long, String>> = derived.map { it.first }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyMap())
    val favoritedIds: StateFlow<Set<Long>> = derived.map { it.second }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptySet())
    val blacklistedIds: StateFlow<Set<Long>> = derived.map { it.third }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptySet())

    private val _message = MutableStateFlow<String?>(null)
    val message: StateFlow<String?> = _message

    private fun triggerRefresh() {
        refreshTrigger.value = System.currentTimeMillis()
    }

    fun restoreWallpaper(item: WallpaperHistory) = viewModelScope.launch {
        // 履歴の元画像のパスを取得し、強制的に次に表示させる
        val path: String? = when (item.imageType) {
            ImageType.LOCAL -> albumRepository.getLocalImageById(item.imageRefId)?.filePath
            ImageType.ONLINE -> onlineImageRepository.getById(item.imageRefId)?.localCachePath
        }
        if (path == null || !java.io.File(path).exists()) {
            _message.value = "元画像が見つかりません"
            return@launch
        }
        imagePreloader.setForcedNextImage(item.imageType, item.imageRefId, path)
        imagePreloader.requestSkip()
        _message.value = "壁紙を切り替えています"
    }

    fun addToFavorites(item: WallpaperHistory) = viewModelScope.launch {
        val exists = when (item.imageType) {
            ImageType.LOCAL -> albumRepository.getLocalImageById(item.imageRefId) != null
            ImageType.ONLINE -> onlineImageRepository.getById(item.imageRefId) != null
        }
        if (!exists) {
            _message.value = if (item.imageType == ImageType.ONLINE)
                "キャッシュ削除済みのため追加できません" else "画像が見つかりません"
            return@launch
        }
        when (item.imageType) {
            ImageType.LOCAL -> albumRepository.setFavorite(item.imageRefId, true)
            ImageType.ONLINE -> onlineImageRepository.setFavorite(item.imageRefId, true)
        }
        triggerRefresh()
        _message.value = "お気に入りに追加しました"
    }

    /** この画像を二度と壁紙に使用しないようブラックリストに追加する。 */
    fun blacklistWallpaper(item: WallpaperHistory) = viewModelScope.launch {
        val exists = when (item.imageType) {
            ImageType.LOCAL -> albumRepository.getLocalImageById(item.imageRefId) != null
            ImageType.ONLINE -> onlineImageRepository.getById(item.imageRefId) != null
        }
        if (!exists) {
            _message.value = if (item.imageType == ImageType.ONLINE)
                "キャッシュ削除済みのため操作できません" else "画像が見つかりません"
            return@launch
        }
        when (item.imageType) {
            ImageType.LOCAL -> albumRepository.setBlacklisted(item.imageRefId, true)
            ImageType.ONLINE -> onlineImageRepository.setBlacklisted(item.imageRefId, true)
        }
        triggerRefresh()
        _message.value = "この画像はもう表示されません"
    }

    /** ブラックリストを解除する（取り消し用）。 */
    fun unblacklistWallpaper(item: WallpaperHistory) = viewModelScope.launch {
        when (item.imageType) {
            ImageType.LOCAL -> albumRepository.setBlacklisted(item.imageRefId, false)
            ImageType.ONLINE -> onlineImageRepository.setBlacklisted(item.imageRefId, false)
        }
        triggerRefresh()
        _message.value = "ブラックリストから解除しました"
    }

    fun clearMessage() {
        _message.value = null
    }
}
