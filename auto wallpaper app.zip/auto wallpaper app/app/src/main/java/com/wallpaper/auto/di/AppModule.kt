package com.wallpaper.auto.di

import android.content.Context
import androidx.room.Room
import com.wallpaper.auto.data.db.AppDatabase
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object AppModule {

    @Provides
    @Singleton
    fun provideDatabase(@ApplicationContext context: Context): AppDatabase {
        return Room.databaseBuilder(context, AppDatabase::class.java, "auto_wallpaper.db")
            .fallbackToDestructiveMigration()
            .build()
    }

    @Provides fun provideAlbumDao(db: AppDatabase) = db.albumDao()
    @Provides fun provideLocalImageDao(db: AppDatabase) = db.localImageDao()
    @Provides fun provideOnlineImageDao(db: AppDatabase) = db.onlineImageDao()
    @Provides fun provideHistoryDao(db: AppDatabase) = db.wallpaperHistoryDao()
    @Provides fun provideTagPresetDao(db: AppDatabase) = db.tagPresetDao()
    @Provides fun provideAppSettingsDao(db: AppDatabase) = db.appSettingsDao()
}
