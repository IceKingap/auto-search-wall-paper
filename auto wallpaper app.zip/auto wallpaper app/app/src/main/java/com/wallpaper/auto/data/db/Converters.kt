package com.wallpaper.auto.data.db

import androidx.room.TypeConverter
import com.wallpaper.auto.data.db.entity.CropMode
import com.wallpaper.auto.data.db.entity.DisplayMode
import com.wallpaper.auto.data.db.entity.ImageType

class Converters {
    @TypeConverter
    fun fromCropMode(value: CropMode): String = value.name

    @TypeConverter
    fun toCropMode(value: String): CropMode = CropMode.valueOf(value)

    @TypeConverter
    fun fromDisplayMode(value: DisplayMode): String = value.name

    @TypeConverter
    fun toDisplayMode(value: String): DisplayMode = DisplayMode.valueOf(value)

    @TypeConverter
    fun fromImageType(value: ImageType): String = value.name

    @TypeConverter
    fun toImageType(value: String): ImageType = ImageType.valueOf(value)
}
