package com.wallpaper.auto.data.db.dao

import androidx.room.*
import com.wallpaper.auto.data.db.entity.AppSettings

@Dao
interface AppSettingsDao {
    @Query("SELECT value FROM app_settings WHERE `key` = :key")
    suspend fun getValue(key: String): String?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun setValue(settings: AppSettings)

    @Query("DELETE FROM app_settings WHERE `key` = :key")
    suspend fun deleteKey(key: String)
}
