package com.wallpaper.auto.data.repository

import android.content.Context
import com.wallpaper.auto.data.api.BooruPost
import com.wallpaper.auto.data.api.DanbooruApi
import com.wallpaper.auto.data.api.SafebooruApi
import com.wallpaper.auto.data.api.pixiv.PixivConstants
import com.wallpaper.auto.data.api.pixiv.PixivWallpaperProvider
import com.wallpaper.auto.data.api.toBooruPost
import com.wallpaper.auto.data.db.dao.OnlineImageDao
import com.wallpaper.auto.data.db.entity.OnlineImage
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.io.FileOutputStream
import java.util.UUID
import javax.inject.Inject
import javax.inject.Singleton
import kotlin.random.Random

@Singleton
class OnlineImageRepository @Inject constructor(
    @ApplicationContext private val context: Context,
    private val onlineImageDao: OnlineImageDao,
    private val safebooruApi: SafebooruApi,
    private val danbooruApi: DanbooruApi,
    private val settingsRepository: SettingsRepository,
    private val pixivWallpaperProvider: PixivWallpaperProvider,
    private val okHttpClient: OkHttpClient
) {
    fun getAllActiveImages(): Flow<List<OnlineImage>> = onlineImageDao.getAllActiveImages()
    fun getFavoriteImages(): Flow<List<OnlineImage>> = onlineImageDao.getFavoriteImages()
    fun getBlacklistedImages(): Flow<List<OnlineImage>> = onlineImageDao.getBlacklistedImages()
    fun observeCachedCount(): Flow<Int> = onlineImageDao.observeCachedCount()

    suspend fun fetchPosts(
        tags: List<String>,
        limit: Int = 20,
        randomize: Boolean = true
    ): List<BooruPost> {
        val source = settingsRepository.getBooruSource()
        return fetchFromSource(source, tags, limit, randomize)
    }

    suspend fun fetchPostsFromSource(
        source: BooruSource,
        tags: List<String>,
        limit: Int = 20,
        randomize: Boolean = true
    ): List<BooruPost> = fetchFromSource(source, tags, limit, randomize)

    private suspend fun fetchFromSource(
        source: BooruSource,
        tags: List<String>,
        limit: Int,
        randomize: Boolean
    ): List<BooruPost> {
        return when (source) {
            BooruSource.SAFEBOORU -> fetchSafebooruPosts(tags, limit, randomize)
            BooruSource.DANBOORU -> fetchDanbooruPosts(tags, limit, randomize)
            BooruSource.PIXIV -> fetchPixivPosts(limit, randomize)
            BooruSource.MIXED -> {
                val configured = settingsRepository.getMixedSources()
                    .filter { it != BooruSource.MIXED }
                val pool = if (configured.isEmpty()) {
                    listOf(BooruSource.SAFEBOORU, BooruSource.DANBOORU)
                } else configured
                val picked = pool.random()
                fetchFromSource(picked, tags, limit, randomize)
            }
        }
    }

    private suspend fun fetchSafebooruPosts(
        tags: List<String>, limit: Int, randomize: Boolean
    ): List<BooruPost> {
        val cleaned = tags.map { it.trim() }.filter { it.isNotBlank() }
        // ユーザーが既に rating:* を指定している場合、rating:general を重ねると検索結果が 0 になる。
        val hasRating = cleaned.any { it.startsWith("rating:") }
        val withRating = if (hasRating) cleaned.distinct() else (cleaned + "rating:general").distinct()
        val tagString = withRating.joinToString("+")

        val page = if (randomize) {
            val count = getSafebooruPostCount(tagString)
            if (count > limit) Random.nextInt((count / limit).coerceAtLeast(1)) else 0
        } else 0

        return try {
            safebooruApi.getPosts(tags = tagString, limit = limit, page = page)
                .map { it.toBooruPost() }
        } catch (e: Exception) {
            emptyList()
        }
    }

    private suspend fun fetchDanbooruPosts(
        tags: List<String>, limit: Int, randomize: Boolean
    ): List<BooruPost> {
        val cleaned = tags.map { it.trim() }.filter { it.isNotBlank() }
        val hasRating = cleaned.any { it.startsWith("rating:") }
        val withRating = if (hasRating) cleaned.distinct() else (cleaned + "rating:general").distinct()
        val tagString = withRating.joinToString(" ")

        val page = if (randomize) {
            try {
                val countResp = danbooruApi.getPostCount(tagString)
                val total = countResp.counts.posts
                if (total > limit) Random.nextInt(1, (total / limit).coerceAtLeast(2)) else 1
            } catch (_: Exception) { 1 }
        } else 1

        return try {
            danbooruApi.getPosts(tags = tagString, limit = limit, page = page)
                .filter { it.fileUrl != null || it.largeFileUrl != null }
                .map { it.toBooruPost() }
        } catch (e: Exception) {
            emptyList()
        }
    }

    private suspend fun fetchPixivPosts(limit: Int, randomize: Boolean): List<BooruPost> {
        return try {
            pixivWallpaperProvider.fetchPosts(limit = limit, randomize = randomize)
        } catch (e: Exception) {
            android.util.Log.e("OnlineImageRepo", "Pixiv fetch failed", e)
            emptyList()
        }
    }

    private suspend fun getSafebooruPostCount(tagString: String): Int {
        return try {
            val body = safebooruApi.getPostCountXml(tags = tagString, limit = 0)
            val xml = body.string()
            Regex("""count="(\d+)"""").find(xml)
                ?.groupValues?.get(1)?.toIntOrNull() ?: 0
        } catch (e: Exception) {
            0
        }
    }

    suspend fun downloadAndSave(post: BooruPost): OnlineImage? = withContext(Dispatchers.IO) {
        try {
            // ソース URL はサイト・ID・ページに対して一意なので、これだけで重複判定する。
            // 以前は post.id でも重複判定していたが、Safebooru/Danbooru/Pixiv 間で
            // id が衝突すると別サイトのレコードを返してしまうバグの原因になっていた。
            val byUrl = onlineImageDao.getBySourceUrl(post.imageUrl)
            if (byUrl != null) return@withContext byUrl

            val cacheDir = File(context.filesDir, "online_cache")
            cacheDir.mkdirs()
            val ext = post.imageUrl.substringAfterLast('.', "jpg").take(4)
            val destFile = File(cacheDir, "${UUID.randomUUID()}.$ext")

            val requestBuilder = Request.Builder().url(post.imageUrl)
            if (post.imageUrl.contains("i.pximg.net")) {
                requestBuilder.addHeader("Referer", PixivConstants.IMAGE_REFERER)
                requestBuilder.addHeader("User-Agent", PixivConstants.USER_AGENT)
            }
            val request = requestBuilder.build()
            okHttpClient.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    android.util.Log.e("OnlineImageRepo", "Download failed: HTTP ${response.code} for ${post.imageUrl}")
                    return@withContext null
                }
                val body = response.body ?: run {
                    android.util.Log.e("OnlineImageRepo", "Download failed: empty body for ${post.imageUrl}")
                    return@withContext null
                }
                body.byteStream().use { input ->
                    FileOutputStream(destFile).use { output ->
                        input.copyTo(output)
                    }
                }
            }

            if (!destFile.exists() || destFile.length() == 0L) {
                android.util.Log.e("OnlineImageRepo", "Download failed: file empty or missing after write")
                destFile.delete()
                return@withContext null
            }

            android.util.Log.d("OnlineImageRepo", "Downloaded ${destFile.length()} bytes -> ${destFile.absolutePath}")

            val image = OnlineImage(
                safebooruId = post.id,
                localCachePath = destFile.absolutePath,
                tags = post.tags,
                sourceUrl = post.imageUrl
            )
            val id = onlineImageDao.insert(image)
            image.copy(id = id)
        } catch (e: kotlinx.coroutines.CancellationException) {
            throw e
        } catch (e: Exception) {
            android.util.Log.e("OnlineImageRepo", "Download exception for ${post.imageUrl}", e)
            null
        }
    }

    suspend fun setFavorite(id: Long, isFavorite: Boolean) = onlineImageDao.setFavorite(id, isFavorite)

    suspend fun setBlacklisted(id: Long, isBlacklisted: Boolean) = onlineImageDao.setBlacklisted(id, isBlacklisted)

    suspend fun getCachedCount(): Int = onlineImageDao.getCachedCount()

    suspend fun getUnseenCount(): Int = onlineImageDao.getUnseenCount()

    suspend fun markDisplayed(id: Long) = onlineImageDao.incrementDisplayCount(id)

    suspend fun evictOldCache(limitMb: Int) = withContext(Dispatchers.IO) {
        val cacheDir = File(context.filesDir, "online_cache")
        val limitBytes = limitMb.toLong() * 1024 * 1024
        var totalSize = cacheDir.walkTopDown().filter { it.isFile }.sumOf { it.length() }

        if (totalSize <= limitBytes) return@withContext

        val oldImages = onlineImageDao.getOldestNonFavorite(50)
        for (img in oldImages) {
            if (totalSize <= limitBytes) break
            img.localCachePath?.let { path ->
                val file = File(path)
                if (file.exists()) {
                    totalSize -= file.length()
                    file.delete()
                }
            }
            onlineImageDao.delete(img)
        }
    }

    suspend fun evictToCount(maxCount: Int) = withContext(Dispatchers.IO) {
        val currentCount = onlineImageDao.getCachedCount()
        if (currentCount <= maxCount) return@withContext
        val excess = currentCount - maxCount
        val oldImages = onlineImageDao.getOldestNonFavorite(excess)
        for (img in oldImages) {
            img.localCachePath?.let { path ->
                File(path).delete()
            }
            onlineImageDao.delete(img)
        }
    }

    suspend fun deleteById(id: Long) = onlineImageDao.deleteById(id)

    suspend fun getById(id: Long): OnlineImage? = onlineImageDao.getById(id)

    suspend fun clearAllCache() = withContext(Dispatchers.IO) {
        val cacheDir = File(context.filesDir, "online_cache")
        cacheDir.listFiles()?.forEach { it.delete() }
        onlineImageDao.deleteAll()
    }
}
