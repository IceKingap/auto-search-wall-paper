package com.wallpaper.auto.data.db.dao

import androidx.room.*
import com.wallpaper.auto.data.db.entity.WallpaperHistory
import kotlinx.coroutines.flow.Flow

@Dao
interface WallpaperHistoryDao {
    @Query("SELECT * FROM wallpaper_history ORDER BY displayedAt DESC LIMIT 50")
    fun getRecentHistory(): Flow<List<WallpaperHistory>>

    /** 非 Flow 版。"戻る" の多段遡上で一時的に同期取得する用途。 */
    @Query("SELECT * FROM wallpaper_history ORDER BY displayedAt DESC LIMIT 50")
    suspend fun getRecentList(): List<WallpaperHistory>

    @Insert
    suspend fun insert(history: WallpaperHistory): Long

    @Query("DELETE FROM wallpaper_history WHERE id NOT IN (SELECT id FROM wallpaper_history ORDER BY displayedAt DESC LIMIT 50)")
    suspend fun trimToLimit()

    @Query("SELECT * FROM wallpaper_history ORDER BY displayedAt DESC LIMIT 1")
    suspend fun getLatest(): WallpaperHistory?
}
