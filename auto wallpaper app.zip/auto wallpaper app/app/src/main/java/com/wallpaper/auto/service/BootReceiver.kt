package com.wallpaper.auto.service

import android.app.WallpaperManager
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.util.Log

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        Log.d("BootReceiver", "Boot completed")
        // 自前の Live Wallpaper が現在設定済みなら通知コントロールサービスを再開する
        try {
            val wm = WallpaperManager.getInstance(context)
            val active = wm.wallpaperInfo?.component
            if (active == ComponentName(context, AutoWallpaperService::class.java)) {
                WallpaperControlService.start(context)
            }
        } catch (e: Exception) {
            Log.w("BootReceiver", "Failed to start WallpaperControlService on boot", e)
        }
    }
}
