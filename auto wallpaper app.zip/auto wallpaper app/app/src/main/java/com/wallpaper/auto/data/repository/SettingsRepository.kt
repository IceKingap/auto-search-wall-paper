package com.wallpaper.auto.data.repository

import com.wallpaper.auto.data.db.dao.AppSettingsDao
import com.wallpaper.auto.data.db.entity.AppSettings
import javax.inject.Inject
import javax.inject.Singleton

enum class SourceMode { LOCAL_ONLY, ONLINE_ONLY, BOTH }
enum class SelectionOrder { RANDOM, SEQUENTIAL, FAVORITES_FIRST }
enum class BooruSource {
    SAFEBOORU,
    DANBOORU,
    PIXIV,
    /**
     * 複数のオンラインソースをランダムに混ぜて使用するモード。
     * 実際にどのソースを混ぜるかは [SettingsRepository.getMixedSources] が返す。
     */
    MIXED
}

enum class EdgeColorMode {
    EDGE_AVERAGE,    // 辺の平均色
    CORNER_AVERAGE,  // 角の平均色
    DOMINANT,        // 最頻色
    BLACK,           // 黒
    WHITE            // 白
}

data class OverlayRect(
    val left: Float,
    val top: Float,
    val width: Float,
    val height: Float,
    val alpha: Float = 0.6f
)

@Singleton
class SettingsRepository @Inject constructor(
    private val appSettingsDao: AppSettingsDao
) {
    companion object {
        const val KEY_SOURCE_MODE = "source_mode"
        const val KEY_SELECTION_ORDER = "selection_order"
        const val KEY_WIFI_ONLY = "wifi_only"
        const val KEY_CACHE_LIMIT_MB = "cache_limit_mb"
        const val KEY_DISPLAY_MODE = "display_mode"
        const val KEY_ACTIVE_TAGS = "active_tags"
        const val KEY_CURRENT_IMAGE_INDEX = "current_image_index"
        const val KEY_CURRENT_IMAGE_TYPE = "current_image_type"
        const val KEY_AUTO_DOWNLOAD = "auto_download"
        const val KEY_MAX_CACHE_COUNT = "max_cache_count"
        const val KEY_CHANGE_ON_HOME = "change_on_home"
        const val KEY_SEARCH_QUERIES = "search_queries"
        const val KEY_ZOOM_OUT_ENABLED = "zoom_out_enabled"
        const val KEY_ZOOM_OUT_DURATION = "zoom_out_duration"
        const val KEY_STATUS_BAR_OVERLAY_HEIGHT = "status_bar_overlay_height"
        const val KEY_LOCK_OVERLAY_RECTS = "lock_overlay_rects"
        const val KEY_PAN_INVERTED = "pan_inverted"
        const val KEY_PAN_SPEED = "pan_speed"
        const val KEY_BOORU_SOURCE = "booru_source"
        const val KEY_PAN_ENABLED = "pan_enabled"
        const val KEY_EDGE_FILL_ENABLED = "edge_fill_enabled"
        const val KEY_EDGE_FADE_WIDTH = "edge_fade_width"
        const val KEY_PIXIV_ACCESS_TOKEN = "pixiv_access_token"
        const val KEY_PIXIV_REFRESH_TOKEN = "pixiv_refresh_token"
        const val KEY_PIXIV_TOKEN_TIMESTAMP = "pixiv_token_timestamp"
        const val KEY_PIXIV_FETCH_MODE = "pixiv_fetch_mode"
        const val KEY_PIXIV_RANKING_MODE = "pixiv_ranking_mode"
        const val KEY_PIXIV_SEARCH_WORD = "pixiv_search_word"
        const val KEY_PIXIV_USER_NAME = "pixiv_user_name"
        const val KEY_PIXIV_SEARCH_QUERIES = "pixiv_search_queries"
        const val KEY_PIXIV_PAGING_ENABLED = "pixiv_paging_enabled"
        const val KEY_PIXIV_PAGING_MAX_PAGES = "pixiv_paging_max_pages"
        const val KEY_PIXIV_MULTI_PAGE_MODE = "pixiv_multi_page_mode"
        const val KEY_ONLINE_RATIO = "online_ratio"
        const val KEY_MIXED_SOURCES = "mixed_booru_sources"
        const val KEY_ANIMATION_FPS = "animation_fps"
        const val KEY_CHANGE_ON_SCREEN_OFF = "change_on_screen_off"
        const val KEY_GPU_RENDERING = "gpu_rendering"
        const val KEY_EDGE_COLOR_MODE = "edge_color_mode"
        const val KEY_FAVORITE_BOOST_PERCENT = "favorite_boost_percent"
    }

    suspend fun getSourceMode(): SourceMode {
        val value = appSettingsDao.getValue(KEY_SOURCE_MODE) ?: SourceMode.BOTH.name
        return SourceMode.valueOf(value)
    }

    suspend fun setSourceMode(mode: SourceMode) {
        appSettingsDao.setValue(AppSettings(KEY_SOURCE_MODE, mode.name))
    }

    suspend fun getSelectionOrder(): SelectionOrder {
        val value = appSettingsDao.getValue(KEY_SELECTION_ORDER) ?: SelectionOrder.RANDOM.name
        return SelectionOrder.valueOf(value)
    }

    suspend fun setSelectionOrder(order: SelectionOrder) {
        appSettingsDao.setValue(AppSettings(KEY_SELECTION_ORDER, order.name))
    }

    suspend fun isWifiOnly(): Boolean {
        return appSettingsDao.getValue(KEY_WIFI_ONLY)?.toBoolean() ?: true
    }

    suspend fun setWifiOnly(enabled: Boolean) {
        appSettingsDao.setValue(AppSettings(KEY_WIFI_ONLY, enabled.toString()))
    }

    suspend fun getCacheLimitMb(): Int {
        return appSettingsDao.getValue(KEY_CACHE_LIMIT_MB)?.toInt() ?: 200
    }

    suspend fun setCacheLimitMb(limitMb: Int) {
        appSettingsDao.setValue(AppSettings(KEY_CACHE_LIMIT_MB, limitMb.toString()))
    }

    suspend fun getActiveTags(): List<String> {
        val value = appSettingsDao.getValue(KEY_ACTIVE_TAGS) ?: "rating:general"
        return if (value.isBlank()) listOf("rating:general") else value.split(",")
    }

    suspend fun setActiveTags(tags: List<String>) {
        appSettingsDao.setValue(AppSettings(KEY_ACTIVE_TAGS, tags.joinToString(",")))
    }

    /** グローバル表示モード: "COVER" (画面にフィット) / "FIT" (画像全体表示) */
    suspend fun getGlobalDisplayMode(): String {
        return appSettingsDao.getValue(KEY_DISPLAY_MODE) ?: "COVER"
    }

    suspend fun setGlobalDisplayMode(mode: String) {
        appSettingsDao.setValue(AppSettings(KEY_DISPLAY_MODE, mode))
    }

    suspend fun isAutoDownloadEnabled(): Boolean {
        return appSettingsDao.getValue(KEY_AUTO_DOWNLOAD)?.toBoolean() ?: true
    }

    suspend fun setAutoDownloadEnabled(enabled: Boolean) {
        appSettingsDao.setValue(AppSettings(KEY_AUTO_DOWNLOAD, enabled.toString()))
    }

    suspend fun getMaxCacheCount(): Int {
        return appSettingsDao.getValue(KEY_MAX_CACHE_COUNT)?.toIntOrNull() ?: 50
    }

    suspend fun setMaxCacheCount(count: Int) {
        appSettingsDao.setValue(AppSettings(KEY_MAX_CACHE_COUNT, count.toString()))
    }

    suspend fun isChangeOnHomeEnabled(): Boolean {
        return appSettingsDao.getValue(KEY_CHANGE_ON_HOME)?.toBoolean() ?: false
    }

    suspend fun setChangeOnHomeEnabled(enabled: Boolean) {
        appSettingsDao.setValue(AppSettings(KEY_CHANGE_ON_HOME, enabled.toString()))
    }

    suspend fun isZoomOutEnabled(): Boolean {
        return appSettingsDao.getValue(KEY_ZOOM_OUT_ENABLED)?.toBoolean() ?: false
    }

    suspend fun setZoomOutEnabled(enabled: Boolean) {
        appSettingsDao.setValue(AppSettings(KEY_ZOOM_OUT_ENABLED, enabled.toString()))
    }

    /** ズームアウト時間（秒） */
    suspend fun getZoomOutDuration(): Int {
        return appSettingsDao.getValue(KEY_ZOOM_OUT_DURATION)?.toIntOrNull() ?: 10
    }

    suspend fun setZoomOutDuration(seconds: Int) {
        appSettingsDao.setValue(AppSettings(KEY_ZOOM_OUT_DURATION, seconds.toString()))
    }

    /**
     * 検索クエリ一覧。各クエリはスペース区切りのタグ文字列。
     * 保存形式: "landscape scenery|night_sky stars|cityscape"
     */
    suspend fun getSearchQueries(): List<String> {
        val value = appSettingsDao.getValue(KEY_SEARCH_QUERIES) ?: return emptyList()
        return value.split("|").filter { it.isNotBlank() }
    }

    suspend fun setSearchQueries(queries: List<String>) {
        appSettingsDao.setValue(AppSettings(KEY_SEARCH_QUERIES, queries.joinToString("|")))
    }

    suspend fun addSearchQuery(query: String) {
        val current = getSearchQueries().toMutableList()
        if (!current.contains(query)) {
            current.add(query)
            setSearchQueries(current)
        }
    }

    suspend fun removeSearchQuery(query: String) {
        val current = getSearchQueries().toMutableList()
        current.remove(query)
        setSearchQueries(current)
    }

    suspend fun getStatusBarOverlayHeight(): Int {
        return appSettingsDao.getValue(KEY_STATUS_BAR_OVERLAY_HEIGHT)?.toIntOrNull() ?: 0
    }

    suspend fun setStatusBarOverlayHeight(heightDp: Int) {
        appSettingsDao.setValue(AppSettings(KEY_STATUS_BAR_OVERLAY_HEIGHT, heightDp.toString()))
    }

    suspend fun getLockOverlayRects(): List<OverlayRect> {
        val value = appSettingsDao.getValue(KEY_LOCK_OVERLAY_RECTS) ?: return emptyList()
        return value.split("|").mapNotNull { s ->
            try {
                val parts = s.split(",").map { it.toFloat() }
                when (parts.size) {
                    5 -> OverlayRect(parts[0], parts[1], parts[2], parts[3], parts[4])
                    4 -> OverlayRect(parts[0], parts[1], parts[2], parts[3])
                    else -> null
                }
            } catch (_: Exception) { null }
        }
    }

    suspend fun setLockOverlayRects(rects: List<OverlayRect>) {
        val value = rects.joinToString("|") { "${it.left},${it.top},${it.width},${it.height},${it.alpha}" }
        appSettingsDao.setValue(AppSettings(KEY_LOCK_OVERLAY_RECTS, value))
    }

    suspend fun isPanEnabled(): Boolean {
        return appSettingsDao.getValue(KEY_PAN_ENABLED)?.toBoolean() ?: false
    }

    suspend fun setPanEnabled(enabled: Boolean) {
        appSettingsDao.setValue(AppSettings(KEY_PAN_ENABLED, enabled.toString()))
    }

    suspend fun isPanInverted(): Boolean {
        return appSettingsDao.getValue(KEY_PAN_INVERTED)?.toBoolean() ?: false
    }

    suspend fun setPanInverted(inverted: Boolean) {
        appSettingsDao.setValue(AppSettings(KEY_PAN_INVERTED, inverted.toString()))
    }

    suspend fun getPanSpeed(): Float {
        return appSettingsDao.getValue(KEY_PAN_SPEED)?.toFloatOrNull() ?: 1.0f
    }

    suspend fun setPanSpeed(speed: Float) {
        appSettingsDao.setValue(AppSettings(KEY_PAN_SPEED, speed.toString()))
    }

    suspend fun getBooruSource(): BooruSource {
        val value = appSettingsDao.getValue(KEY_BOORU_SOURCE) ?: BooruSource.SAFEBOORU.name
        return try { BooruSource.valueOf(value) } catch (_: Exception) { BooruSource.SAFEBOORU }
    }

    suspend fun setBooruSource(source: BooruSource) {
        appSettingsDao.setValue(AppSettings(KEY_BOORU_SOURCE, source.name))
    }

    suspend fun isEdgeFillEnabled(): Boolean {
        return appSettingsDao.getValue(KEY_EDGE_FILL_ENABLED)?.toBoolean() ?: false
    }

    suspend fun setEdgeFillEnabled(enabled: Boolean) {
        appSettingsDao.setValue(AppSettings(KEY_EDGE_FILL_ENABLED, enabled.toString()))
    }

    suspend fun getEdgeFadeWidth(): Int {
        return appSettingsDao.getValue(KEY_EDGE_FADE_WIDTH)?.toIntOrNull() ?: 40
    }

    suspend fun setEdgeFadeWidth(widthDp: Int) {
        appSettingsDao.setValue(AppSettings(KEY_EDGE_FADE_WIDTH, widthDp.toString()))
    }

    // ── Pixiv ──

    suspend fun getPixivAccessToken(): String? {
        return appSettingsDao.getValue(KEY_PIXIV_ACCESS_TOKEN)?.takeIf { it.isNotBlank() }
    }

    suspend fun setPixivAccessToken(token: String) {
        appSettingsDao.setValue(AppSettings(KEY_PIXIV_ACCESS_TOKEN, token))
    }

    suspend fun getPixivRefreshToken(): String? {
        return appSettingsDao.getValue(KEY_PIXIV_REFRESH_TOKEN)?.takeIf { it.isNotBlank() }
    }

    suspend fun setPixivRefreshToken(token: String) {
        appSettingsDao.setValue(AppSettings(KEY_PIXIV_REFRESH_TOKEN, token))
    }

    suspend fun getPixivTokenTimestamp(): Long {
        return appSettingsDao.getValue(KEY_PIXIV_TOKEN_TIMESTAMP)?.toLongOrNull() ?: 0L
    }

    suspend fun setPixivTokenTimestamp(timestamp: Long) {
        appSettingsDao.setValue(AppSettings(KEY_PIXIV_TOKEN_TIMESTAMP, timestamp.toString()))
    }

    suspend fun isPixivLoggedIn(): Boolean {
        return getPixivAccessToken() != null
    }

    suspend fun clearPixivTokens() {
        appSettingsDao.deleteKey(KEY_PIXIV_ACCESS_TOKEN)
        appSettingsDao.deleteKey(KEY_PIXIV_REFRESH_TOKEN)
        appSettingsDao.deleteKey(KEY_PIXIV_TOKEN_TIMESTAMP)
        appSettingsDao.deleteKey(KEY_PIXIV_USER_NAME)
    }

    suspend fun getPixivFetchMode(): String {
        return appSettingsDao.getValue(KEY_PIXIV_FETCH_MODE) ?: "RANKING"
    }

    suspend fun setPixivFetchMode(mode: String) {
        appSettingsDao.setValue(AppSettings(KEY_PIXIV_FETCH_MODE, mode))
    }

    suspend fun getPixivRankingMode(): String {
        return appSettingsDao.getValue(KEY_PIXIV_RANKING_MODE) ?: "day"
    }

    suspend fun setPixivRankingMode(mode: String) {
        appSettingsDao.setValue(AppSettings(KEY_PIXIV_RANKING_MODE, mode))
    }

    suspend fun getPixivSearchWord(): String {
        return appSettingsDao.getValue(KEY_PIXIV_SEARCH_WORD) ?: ""
    }

    suspend fun setPixivSearchWord(word: String) {
        appSettingsDao.setValue(AppSettings(KEY_PIXIV_SEARCH_WORD, word))
    }

    suspend fun getPixivUserName(): String {
        return appSettingsDao.getValue(KEY_PIXIV_USER_NAME) ?: ""
    }

    suspend fun setPixivUserName(name: String) {
        appSettingsDao.setValue(AppSettings(KEY_PIXIV_USER_NAME, name))
    }

    suspend fun getPixivSearchQueries(): List<String> {
        val value = appSettingsDao.getValue(KEY_PIXIV_SEARCH_QUERIES) ?: return emptyList()
        return value.split("|").filter { it.isNotBlank() }
    }

    suspend fun setPixivSearchQueries(queries: List<String>) {
        appSettingsDao.setValue(AppSettings(KEY_PIXIV_SEARCH_QUERIES, queries.joinToString("|")))
    }

    suspend fun addPixivSearchQuery(query: String) {
        val current = getPixivSearchQueries().toMutableList()
        if (!current.contains(query)) {
            current.add(query)
            setPixivSearchQueries(current)
        }
    }

    suspend fun removePixivSearchQuery(query: String) {
        val current = getPixivSearchQueries().toMutableList()
        current.remove(query)
        setPixivSearchQueries(current)
    }

    suspend fun isPixivPagingEnabled(): Boolean {
        return appSettingsDao.getValue(KEY_PIXIV_PAGING_ENABLED)?.toBoolean() ?: false
    }

    suspend fun setPixivPagingEnabled(enabled: Boolean) {
        appSettingsDao.setValue(AppSettings(KEY_PIXIV_PAGING_ENABLED, enabled.toString()))
    }

    /** ページングで最大何ページまで辿るか (1ページ≒30件) */
    suspend fun getPixivPagingMaxPages(): Int {
        return appSettingsDao.getValue(KEY_PIXIV_PAGING_MAX_PAGES)?.toIntOrNull()?.coerceIn(2, 10) ?: 5
    }

    suspend fun setPixivPagingMaxPages(pages: Int) {
        appSettingsDao.setValue(AppSettings(KEY_PIXIV_PAGING_MAX_PAGES, pages.coerceIn(2, 10).toString()))
    }

    suspend fun getPixivMultiPageMode(): String {
        return appSettingsDao.getValue(KEY_PIXIV_MULTI_PAGE_MODE) ?: "FIRST_PAGE_ONLY"
    }

    suspend fun setPixivMultiPageMode(mode: String) {
        appSettingsDao.setValue(AppSettings(KEY_PIXIV_MULTI_PAGE_MODE, mode))
    }

    // ── BOTH モード時のローカル/オンライン比率 ──
    // 0.0 = 全てローカル, 1.0 = 全てオンライン (デフォルト 0.5)

    suspend fun getOnlineRatio(): Float {
        return appSettingsDao.getValue(KEY_ONLINE_RATIO)?.toFloatOrNull()?.coerceIn(0f, 1f) ?: 0.5f
    }

    suspend fun setOnlineRatio(ratio: Float) {
        appSettingsDao.setValue(AppSettings(KEY_ONLINE_RATIO, ratio.coerceIn(0f, 1f).toString()))
    }

    // ── ミックスソース (Safebooru/Danbooru/Pixiv をランダム使用) ──

    suspend fun getMixedSources(): Set<BooruSource> {
        val raw = appSettingsDao.getValue(KEY_MIXED_SOURCES) ?: return emptySet()
        return raw.split(",").mapNotNull { name ->
            try {
                BooruSource.valueOf(name.trim())
            } catch (_: Exception) {
                null
            }
        }.toSet()
    }

    suspend fun setMixedSources(sources: Set<BooruSource>) {
        appSettingsDao.setValue(
            AppSettings(KEY_MIXED_SOURCES, sources.joinToString(",") { it.name })
        )
    }

    // ── 省電力 ──

    suspend fun getAnimationFps(): Int {
        return appSettingsDao.getValue(KEY_ANIMATION_FPS)?.toIntOrNull()?.coerceIn(1, 120) ?: 30
    }

    suspend fun setAnimationFps(fps: Int) {
        appSettingsDao.setValue(AppSettings(KEY_ANIMATION_FPS, fps.coerceIn(1, 120).toString()))
    }

    suspend fun isChangeOnScreenOffEnabled(): Boolean {
        return appSettingsDao.getValue(KEY_CHANGE_ON_SCREEN_OFF)?.toBoolean() ?: true
    }

    suspend fun setChangeOnScreenOffEnabled(enabled: Boolean) {
        appSettingsDao.setValue(AppSettings(KEY_CHANGE_ON_SCREEN_OFF, enabled.toString()))
    }

    suspend fun isGpuRenderingEnabled(): Boolean {
        return appSettingsDao.getValue(KEY_GPU_RENDERING)?.toBoolean() ?: true
    }

    suspend fun setGpuRenderingEnabled(enabled: Boolean) {
        appSettingsDao.setValue(AppSettings(KEY_GPU_RENDERING, enabled.toString()))
    }

    suspend fun getEdgeColorMode(): EdgeColorMode {
        val value = appSettingsDao.getValue(KEY_EDGE_COLOR_MODE) ?: EdgeColorMode.EDGE_AVERAGE.name
        return try { EdgeColorMode.valueOf(value) } catch (_: Exception) { EdgeColorMode.EDGE_AVERAGE }
    }

    suspend fun setEdgeColorMode(mode: EdgeColorMode) {
        appSettingsDao.setValue(AppSettings(KEY_EDGE_COLOR_MODE, mode.name))
    }

    // ── お気に入り優先度 (FAVORITES_FIRST 選択時の確率 0-100%) ──

    suspend fun getFavoriteBoostPercent(): Int {
        return appSettingsDao.getValue(KEY_FAVORITE_BOOST_PERCENT)?.toIntOrNull()?.coerceIn(0, 100) ?: 50
    }

    suspend fun setFavoriteBoostPercent(percent: Int) {
        appSettingsDao.setValue(AppSettings(KEY_FAVORITE_BOOST_PERCENT, percent.coerceIn(0, 100).toString()))
    }

    // ── General ──

    suspend fun getString(key: String, default: String = ""): String {
        return appSettingsDao.getValue(key) ?: default
    }

    suspend fun setString(key: String, value: String) {
        appSettingsDao.setValue(AppSettings(key, value))
    }
}
