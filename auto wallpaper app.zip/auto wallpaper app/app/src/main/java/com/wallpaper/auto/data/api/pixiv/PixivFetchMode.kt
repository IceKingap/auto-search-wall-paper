package com.wallpaper.auto.data.api.pixiv

enum class PixivFetchMode { RANKING, SEARCH, RECOMMENDED }
