package com.wallpaper.auto.data.db.entity

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

enum class ImageType { LOCAL, ONLINE }

@Entity(tableName = "wallpaper_history")
data class WallpaperHistory(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val imageType: ImageType,
    val imageRefId: Long,
    val displayedAt: Long = System.currentTimeMillis(),
    @ColumnInfo(defaultValue = "")
    val imagePath: String? = null
)
