package com.wallpaper.auto.data.db

import androidx.room.Database
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import com.wallpaper.auto.data.db.dao.*
import com.wallpaper.auto.data.db.entity.*

@Database(
    entities = [
        Album::class,
        LocalImage::class,
        OnlineImage::class,
        WallpaperHistory::class,
        TagPreset::class,
        AppSettings::class
    ],
    version = 4,
    exportSchema = false
)
@TypeConverters(Converters::class)
abstract class AppDatabase : RoomDatabase() {
    abstract fun albumDao(): AlbumDao
    abstract fun localImageDao(): LocalImageDao
    abstract fun onlineImageDao(): OnlineImageDao
    abstract fun wallpaperHistoryDao(): WallpaperHistoryDao
    abstract fun tagPresetDao(): TagPresetDao
    abstract fun appSettingsDao(): AppSettingsDao
}
