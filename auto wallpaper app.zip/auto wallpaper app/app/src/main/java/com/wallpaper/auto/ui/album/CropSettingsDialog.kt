package com.wallpaper.auto.ui.album

import android.graphics.BitmapFactory
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.wallpaper.auto.data.db.entity.CropMode
import com.wallpaper.auto.data.db.entity.LocalImage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CropSettingsDialog(
    image: LocalImage,
    onDismiss: () -> Unit,
    onSave: (CropMode, String?) -> Unit
) {
    var selectedMode by remember { mutableStateOf(image.cropMode) }
    // Normalized crop rect: "left,top,right,bottom"
    val initialRect = remember {
        image.cropRect?.let { parseCropRect(it) } ?: Rect(0.1f, 0.1f, 0.9f, 0.9f)
    }
    var cropRect by remember { mutableStateOf(initialRect) }
    // Split ratio (0.0-1.0) for SPLIT_LR
    var splitRatio by remember {
        mutableStateOf(
            if (image.cropMode == CropMode.SPLIT_LR) {
                image.cropRect?.toFloatOrNull() ?: 0.5f
            } else 0.5f
        )
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("クロップ設定") },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
            ) {
                // Mode selection
                Text("クロップモード", style = MaterialTheme.typography.labelLarge)
                Spacer(Modifier.height(4.dp))
                CropModeOption(
                    label = "そのまま（全体を使用）",
                    selected = selectedMode == CropMode.FULL,
                    onClick = { selectedMode = CropMode.FULL }
                )
                CropModeOption(
                    label = "左右分割（横長画像を2枚に）",
                    selected = selectedMode == CropMode.SPLIT_LR,
                    onClick = { selectedMode = CropMode.SPLIT_LR }
                )
                CropModeOption(
                    label = "カスタムクロップ",
                    selected = selectedMode == CropMode.CUSTOM,
                    onClick = { selectedMode = CropMode.CUSTOM }
                )

                // Custom crop editor
                if (selectedMode == CropMode.CUSTOM) {
                    Spacer(Modifier.height(12.dp))
                    Text(
                        "四隅のハンドルをドラッグして範囲を指定、中央をドラッグして移動",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(Modifier.height(8.dp))
                    CustomCropEditor(
                        imagePath = image.filePath,
                        cropRect = cropRect,
                        onRectChanged = { cropRect = it }
                    )
                }

                // Split LR preview with adjustable split line
                if (selectedMode == CropMode.SPLIT_LR) {
                    var imageAspectRatio by remember { mutableStateOf(2f) }
                    LaunchedEffect(image.filePath) {
                        withContext(Dispatchers.IO) {
                            val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                            BitmapFactory.decodeFile(image.filePath, opts)
                            if (opts.outWidth > 0 && opts.outHeight > 0) {
                                imageAspectRatio = opts.outWidth.toFloat() / opts.outHeight
                            }
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    Text(
                        "分割位置: ${(splitRatio * 100).toInt()}%",
                        style = MaterialTheme.typography.bodySmall
                    )
                    Slider(
                        value = splitRatio,
                        onValueChange = { splitRatio = it },
                        valueRange = 0.1f..0.9f
                    )
                    Box(modifier = Modifier.fillMaxWidth()) {
                        AsyncImage(
                            model = image.filePath,
                            contentDescription = null,
                            contentScale = ContentScale.FillBounds,
                            modifier = Modifier
                                .fillMaxWidth()
                                .aspectRatio(imageAspectRatio)
                        )
                        Canvas(
                            modifier = Modifier
                                .fillMaxWidth()
                                .aspectRatio(imageAspectRatio)
                        ) {
                            val lineX = size.width * splitRatio
                            // Left overlay
                            drawRect(
                                Color(0x3300FF00),
                                topLeft = Offset.Zero,
                                size = Size(lineX, size.height)
                            )
                            // Right overlay
                            drawRect(
                                Color(0x330000FF),
                                topLeft = Offset(lineX, 0f),
                                size = Size(size.width - lineX, size.height)
                            )
                            // Split line
                            drawLine(
                                Color.Red,
                                start = Offset(lineX, 0f),
                                end = Offset(lineX, size.height),
                                strokeWidth = 3f
                            )
                        }
                        Text(
                            "左",
                            modifier = Modifier.align(Alignment.CenterStart).padding(8.dp),
                            color = Color.White,
                            style = MaterialTheme.typography.labelLarge
                        )
                        Text(
                            "右",
                            modifier = Modifier.align(Alignment.CenterEnd).padding(8.dp),
                            color = Color.White,
                            style = MaterialTheme.typography.labelLarge
                        )
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val rectStr = when (selectedMode) {
                    CropMode.CUSTOM -> formatCropRect(cropRect)
                    CropMode.SPLIT_LR -> splitRatio.toString()
                    else -> null
                }
                onSave(selectedMode, rectStr)
            }) { Text("保存") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("キャンセル") }
        }
    )
}

@Composable
private fun CropModeOption(label: String, selected: Boolean, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 2.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        RadioButton(selected = selected, onClick = onClick)
        Text(label, modifier = Modifier.padding(start = 4.dp))
    }
}

@Composable
fun CustomCropEditor(
    imagePath: String,
    cropRect: Rect,
    onRectChanged: (Rect) -> Unit
) {
    val handleRadius = 20f
    var dragHandle by remember { mutableStateOf<DragHandle?>(null) }
    var aspectRatio by remember { mutableStateOf(1f) }

    LaunchedEffect(imagePath) {
        withContext(Dispatchers.IO) {
            val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(imagePath, opts)
            if (opts.outWidth > 0 && opts.outHeight > 0) {
                aspectRatio = opts.outWidth.toFloat() / opts.outHeight
            }
        }
    }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .aspectRatio(aspectRatio)
    ) {
        AsyncImage(
            model = imagePath,
            contentDescription = null,
            contentScale = ContentScale.FillBounds,
            modifier = Modifier.fillMaxSize()
        )

        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .pointerInput(cropRect) {
                    detectDragGestures(
                        onDragStart = { offset ->
                            val w = size.width.toFloat()
                            val h = size.height.toFloat()
                            val l = cropRect.left * w
                            val t = cropRect.top * h
                            val r = cropRect.right * w
                            val b = cropRect.bottom * h
                            dragHandle = when {
                                (offset - Offset(l, t)).getDistance() < handleRadius * 2 -> DragHandle.TOP_LEFT
                                (offset - Offset(r, t)).getDistance() < handleRadius * 2 -> DragHandle.TOP_RIGHT
                                (offset - Offset(l, b)).getDistance() < handleRadius * 2 -> DragHandle.BOTTOM_LEFT
                                (offset - Offset(r, b)).getDistance() < handleRadius * 2 -> DragHandle.BOTTOM_RIGHT
                                offset.x in l..r && offset.y in t..b -> DragHandle.CENTER
                                else -> null
                            }
                        },
                        onDrag = { change, dragAmount ->
                            change.consume()
                            val w = size.width.toFloat()
                            val h = size.height.toFloat()
                            val dx = dragAmount.x / w
                            val dy = dragAmount.y / h
                            val minSize = 0.1f
                            val newRect = when (dragHandle) {
                                DragHandle.TOP_LEFT -> Rect(
                                    left = (cropRect.left + dx).coerceIn(0f, cropRect.right - minSize),
                                    top = (cropRect.top + dy).coerceIn(0f, cropRect.bottom - minSize),
                                    right = cropRect.right,
                                    bottom = cropRect.bottom
                                )
                                DragHandle.TOP_RIGHT -> Rect(
                                    left = cropRect.left,
                                    top = (cropRect.top + dy).coerceIn(0f, cropRect.bottom - minSize),
                                    right = (cropRect.right + dx).coerceIn(cropRect.left + minSize, 1f),
                                    bottom = cropRect.bottom
                                )
                                DragHandle.BOTTOM_LEFT -> Rect(
                                    left = (cropRect.left + dx).coerceIn(0f, cropRect.right - minSize),
                                    top = cropRect.top,
                                    right = cropRect.right,
                                    bottom = (cropRect.bottom + dy).coerceIn(cropRect.top + minSize, 1f)
                                )
                                DragHandle.BOTTOM_RIGHT -> Rect(
                                    left = cropRect.left,
                                    top = cropRect.top,
                                    right = (cropRect.right + dx).coerceIn(cropRect.left + minSize, 1f),
                                    bottom = (cropRect.bottom + dy).coerceIn(cropRect.top + minSize, 1f)
                                )
                                DragHandle.CENTER -> {
                                    val w2 = cropRect.right - cropRect.left
                                    val h2 = cropRect.bottom - cropRect.top
                                    val newL = (cropRect.left + dx).coerceIn(0f, 1f - w2)
                                    val newT = (cropRect.top + dy).coerceIn(0f, 1f - h2)
                                    Rect(newL, newT, newL + w2, newT + h2)
                                }
                                null -> cropRect
                            }
                            onRectChanged(newRect)
                        },
                        onDragEnd = { dragHandle = null }
                    )
                }
        ) {
            val w = size.width
            val h = size.height
            val l = cropRect.left * w
            val t = cropRect.top * h
            val r = cropRect.right * w
            val b = cropRect.bottom * h

            // Dark overlay outside crop area (4 rects)
            val overlayColor = Color.Black.copy(alpha = 0.55f)
            drawRect(overlayColor, topLeft = Offset(0f, 0f), size = Size(w, t))           // top
            drawRect(overlayColor, topLeft = Offset(0f, b), size = Size(w, h - b))        // bottom
            drawRect(overlayColor, topLeft = Offset(0f, t), size = Size(l, b - t))        // left
            drawRect(overlayColor, topLeft = Offset(r, t), size = Size(w - r, b - t))     // right

            // Crop border
            drawRect(
                color = Color.White,
                topLeft = Offset(l, t),
                size = Size(r - l, b - t),
                style = Stroke(width = 2f)
            )

            // Rule-of-thirds grid lines
            val gridColor = Color.White.copy(alpha = 0.4f)
            drawLine(gridColor, Offset(l + (r - l) / 3, t), Offset(l + (r - l) / 3, b))
            drawLine(gridColor, Offset(l + (r - l) * 2 / 3, t), Offset(l + (r - l) * 2 / 3, b))
            drawLine(gridColor, Offset(l, t + (b - t) / 3), Offset(r, t + (b - t) / 3))
            drawLine(gridColor, Offset(l, t + (b - t) * 2 / 3), Offset(r, t + (b - t) * 2 / 3))

            // Corner handles
            val handleColor = Color.White
            val handles = listOf(Offset(l, t), Offset(r, t), Offset(l, b), Offset(r, b))
            handles.forEach { pos ->
                drawCircle(Color.Black.copy(alpha = 0.4f), handleRadius + 2f, pos)
                drawCircle(handleColor, handleRadius, pos)
            }
        }
    }
}

private enum class DragHandle { TOP_LEFT, TOP_RIGHT, BOTTOM_LEFT, BOTTOM_RIGHT, CENTER }

fun parseCropRect(s: String): Rect {
    return try {
        val parts = s.split(",").map { it.toFloat() }
        Rect(parts[0], parts[1], parts[2], parts[3])
    } catch (e: Exception) {
        Rect(0.1f, 0.1f, 0.9f, 0.9f)
    }
}

fun formatCropRect(rect: Rect): String =
    "${rect.left},${rect.top},${rect.right},${rect.bottom}"
