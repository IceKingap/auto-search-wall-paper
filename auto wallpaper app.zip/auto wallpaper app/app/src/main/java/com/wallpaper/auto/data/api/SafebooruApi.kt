package com.wallpaper.auto.data.api

import okhttp3.ResponseBody
import retrofit2.http.GET
import retrofit2.http.Query

interface SafebooruApi {
    /**
     * encoded = true で Retrofit の自動URLエンコードを無効にする。
     * Safebooru はタグ区切りに + (URLスペース)、メタタグに : をそのまま要求するため、
     * %2B や %3A にエンコードされると検索が壊れる。
     */
    @GET("index.php?page=dapi&s=post&q=index&json=1")
    suspend fun getPosts(
        @Query("tags", encoded = true) tags: String,
        @Query("limit") limit: Int = 20,
        @Query("pid") page: Int = 0
    ): List<SafebooruPost>

    /** XML版 (json=1 なし)。レスポンスの <posts count="N"> から総件数を取得するために使う */
    @GET("index.php?page=dapi&s=post&q=index")
    suspend fun getPostCountXml(
        @Query("tags", encoded = true) tags: String,
        @Query("limit") limit: Int = 0
    ): ResponseBody
}
