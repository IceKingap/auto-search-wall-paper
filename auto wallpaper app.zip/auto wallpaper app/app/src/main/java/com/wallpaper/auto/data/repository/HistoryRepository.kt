package com.wallpaper.auto.data.repository

import com.wallpaper.auto.data.db.dao.WallpaperHistoryDao
import com.wallpaper.auto.data.db.entity.ImageType
import com.wallpaper.auto.data.db.entity.WallpaperHistory
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class HistoryRepository @Inject constructor(
    private val historyDao: WallpaperHistoryDao
) {
    // 多段戻るのための状態。
    // backPosition: 現在表示中の画像が履歴の何番目か (0 = 最新)。
    // suppressAddCount: 次の N 回 addHistory を無視する (「戻る」復元後に自動ADDが走る分)。
    private val stateMutex = Mutex()
    private var backPosition = 0
    private var suppressAddCount = 0

    fun getRecentHistory(): Flow<List<WallpaperHistory>> = historyDao.getRecentHistory()

    suspend fun addHistory(imageType: ImageType, imageRefId: Long, imagePath: String? = null) {
        val shouldSkip = stateMutex.withLock {
            if (suppressAddCount > 0) {
                suppressAddCount--
                true
            } else {
                backPosition = 0
                false
            }
        }
        if (shouldSkip) return
        historyDao.insert(WallpaperHistory(imageType = imageType, imageRefId = imageRefId, imagePath = imagePath))
        historyDao.trimToLimit()
    }

    suspend fun getLatest(): WallpaperHistory? = historyDao.getLatest()

    /**
     * 現在位置の1つ前の履歴を返す。連続して呼ぶと更に遡る。
     * 返却成功時に backPosition を進め、次の addHistory が1回スキップされるように印をつける。
     */
    suspend fun getPrevious(): WallpaperHistory? {
        val items = historyDao.getRecentList()
        return stateMutex.withLock {
            val nextPos = backPosition + 1
            if (nextPos >= items.size) return@withLock null
            backPosition = nextPos
            suppressAddCount++
            items[nextPos]
        }
    }

    /** "skip" (通常の次画像要求) などで現在位置がリセットされた時用。 */
    suspend fun resetBackPosition() = stateMutex.withLock {
        backPosition = 0
    }
}
