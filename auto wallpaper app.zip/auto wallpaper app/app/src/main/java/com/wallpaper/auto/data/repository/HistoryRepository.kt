package com.wallpaper.auto.data.repository

import com.wallpaper.auto.data.db.dao.WallpaperHistoryDao
import com.wallpaper.auto.data.db.entity.ImageType
import com.wallpaper.auto.data.db.entity.WallpaperHistory
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class HistoryRepository @Inject constructor(
    private val historyDao: WallpaperHistoryDao
) {
    fun getRecentHistory(): Flow<List<WallpaperHistory>> = historyDao.getRecentHistory()

    suspend fun addHistory(imageType: ImageType, imageRefId: Long, imagePath: String? = null) {
        historyDao.insert(WallpaperHistory(imageType = imageType, imageRefId = imageRefId, imagePath = imagePath))
        historyDao.trimToLimit()
    }

    suspend fun getLatest(): WallpaperHistory? = historyDao.getLatest()

    suspend fun getPrevious(): WallpaperHistory? {
        val latest = historyDao.getLatestTwo()
        return if (latest.size >= 2) latest[1] else null
    }
}
