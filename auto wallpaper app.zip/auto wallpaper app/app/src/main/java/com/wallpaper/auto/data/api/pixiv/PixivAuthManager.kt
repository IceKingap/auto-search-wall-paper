package com.wallpaper.auto.data.api.pixiv

import android.util.Log
import com.google.gson.Gson
import com.wallpaper.auto.data.repository.SettingsRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import okhttp3.FormBody
import okhttp3.OkHttpClient
import okhttp3.Request
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class PixivAuthManager @Inject constructor(
    private val settingsRepository: SettingsRepository,
    private val okHttpClient: OkHttpClient
) {
    private val gson = Gson()
    private val refreshMutex = Mutex()

    suspend fun getAccessToken(): String? = settingsRepository.getPixivAccessToken()

    suspend fun isLoggedIn(): Boolean = settingsRepository.isPixivLoggedIn()

    fun buildLoginUrl(codeChallenge: String): String {
        return "${PixivConstants.LOGIN_URL}?code_challenge=$codeChallenge" +
                "&code_challenge_method=S256&client=pixiv-android"
    }

    suspend fun exchangeCodeForToken(code: String, codeVerifier: String): Boolean =
        withContext(Dispatchers.IO) {
            try {
                val body = FormBody.Builder()
                    .add("client_id", PixivConstants.CLIENT_ID)
                    .add("client_secret", PixivConstants.CLIENT_SECRET)
                    .add("grant_type", "authorization_code")
                    .add("code", code)
                    .add("redirect_uri", PixivConstants.REDIRECT_URI)
                    .add("code_verifier", codeVerifier)
                    .add("include_policy", "true")
                    .build()

                val request = Request.Builder()
                    .url(PixivConstants.AUTH_TOKEN_URL)
                    .post(body)
                    .addHeader("User-Agent", PixivConstants.USER_AGENT)
                    .build()

                okHttpClient.newCall(request).execute().use { response ->
                    if (!response.isSuccessful) {
                        Log.e(TAG, "Token exchange failed: ${response.code}")
                        return@withContext false
                    }
                    val json = response.body?.string() ?: return@withContext false
                    val tokenResp = gson.fromJson(json, PixivTokenResponse::class.java)
                    saveTokens(tokenResp)
                    true
                }
            } catch (e: Exception) {
                Log.e(TAG, "Token exchange error", e)
                false
            }
        }

    suspend fun refreshToken(): Boolean = refreshMutex.withLock {
        withContext(Dispatchers.IO) {
            try {
                val refreshToken = settingsRepository.getPixivRefreshToken()
                    ?: return@withContext false

                val body = FormBody.Builder()
                    .add("client_id", PixivConstants.CLIENT_ID)
                    .add("client_secret", PixivConstants.CLIENT_SECRET)
                    .add("grant_type", "refresh_token")
                    .add("refresh_token", refreshToken)
                    .add("include_policy", "true")
                    .build()

                val request = Request.Builder()
                    .url(PixivConstants.AUTH_TOKEN_URL)
                    .post(body)
                    .addHeader("User-Agent", PixivConstants.USER_AGENT)
                    .build()

                okHttpClient.newCall(request).execute().use { response ->
                    if (!response.isSuccessful) {
                        Log.e(TAG, "Token refresh failed: ${response.code}")
                        return@withContext false
                    }
                    val json = response.body?.string() ?: return@withContext false
                    val tokenResp = gson.fromJson(json, PixivTokenResponse::class.java)
                    saveTokens(tokenResp)
                    Log.d(TAG, "Token refreshed successfully")
                    true
                }
            } catch (e: Exception) {
                Log.e(TAG, "Token refresh error", e)
                false
            }
        }
    }

    suspend fun logout() {
        settingsRepository.clearPixivTokens()
    }

    private suspend fun saveTokens(response: PixivTokenResponse) {
        settingsRepository.setPixivAccessToken(response.accessToken)
        settingsRepository.setPixivRefreshToken(response.refreshToken)
        settingsRepository.setPixivTokenTimestamp(System.currentTimeMillis())
        response.user?.name?.let { settingsRepository.setPixivUserName(it) }
    }

    companion object {
        private const val TAG = "PixivAuthManager"
    }
}
