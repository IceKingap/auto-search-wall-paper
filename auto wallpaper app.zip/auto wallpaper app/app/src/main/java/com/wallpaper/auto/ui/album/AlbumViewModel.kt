package com.wallpaper.auto.ui.album

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.wallpaper.auto.data.db.entity.Album
import com.wallpaper.auto.data.db.entity.CropMode
import com.wallpaper.auto.data.db.entity.LocalImage
import com.wallpaper.auto.data.repository.AlbumRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class AlbumViewModel @Inject constructor(
    private val albumRepository: AlbumRepository
) : ViewModel() {

    val albums = albumRepository.getAllAlbums()

    fun getImagesForAlbum(albumId: Long): Flow<List<LocalImage>> =
        albumRepository.getImagesForAlbum(albumId)

    fun createAlbum(name: String) = viewModelScope.launch {
        albumRepository.createAlbum(name)
    }

    fun toggleAlbum(album: Album) = viewModelScope.launch {
        albumRepository.updateAlbum(album.copy(isEnabled = !album.isEnabled))
    }

    fun deleteAlbum(album: Album) = viewModelScope.launch {
        albumRepository.deleteAlbum(album)
    }

    fun importImage(albumId: Long, uri: Uri) = viewModelScope.launch {
        albumRepository.importImage(albumId, uri)
    }

    fun deleteImage(image: LocalImage) = viewModelScope.launch {
        albumRepository.deleteImage(image)
    }

    fun toggleFavorite(image: LocalImage) = viewModelScope.launch {
        albumRepository.setFavorite(image.id, !image.isFavorite)
    }

    fun saveCrop(image: LocalImage, mode: CropMode, cropRect: String?) = viewModelScope.launch {
        albumRepository.updateImage(image.copy(cropMode = mode, cropRect = cropRect))
    }
}
