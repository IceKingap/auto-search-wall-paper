package com.wallpaper.auto.data.db.entity

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

enum class CropMode { FULL, SPLIT_LR, CUSTOM }
enum class DisplayMode { GLOBAL_DEFAULT, COVER, FIT, BLUR_FILL }

@Entity(
    tableName = "local_images",
    foreignKeys = [ForeignKey(
        entity = Album::class,
        parentColumns = ["id"],
        childColumns = ["albumId"],
        onDelete = ForeignKey.CASCADE
    )],
    indices = [Index("albumId")]
)
data class LocalImage(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val albumId: Long,
    val filePath: String,
    val cropMode: CropMode = CropMode.FULL,
    val cropRect: String? = null, // JSON: {left, top, right, bottom} normalized 0-1
    val displayMode: DisplayMode = DisplayMode.GLOBAL_DEFAULT,
    val isFavorite: Boolean = false,
    val isBlacklisted: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)
