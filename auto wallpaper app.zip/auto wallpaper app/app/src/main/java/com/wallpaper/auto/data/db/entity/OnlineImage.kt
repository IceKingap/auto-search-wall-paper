package com.wallpaper.auto.data.db.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "online_images")
data class OnlineImage(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val safebooruId: Long,
    val localCachePath: String?,
    val tags: String,
    val sourceUrl: String,
    val displayMode: DisplayMode = DisplayMode.GLOBAL_DEFAULT,
    val isFavorite: Boolean = false,
    val isBlacklisted: Boolean = false,
    val downloadedAt: Long = System.currentTimeMillis(),
    val displayCount: Int = 0,
    val lastDisplayedAt: Long = 0L
)
