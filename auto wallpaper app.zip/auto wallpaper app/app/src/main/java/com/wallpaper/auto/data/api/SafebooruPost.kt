package com.wallpaper.auto.data.api

import com.google.gson.annotations.SerializedName

data class SafebooruPost(
    @SerializedName("id") val id: Long,
    @SerializedName("directory") val directory: String,
    @SerializedName("image") val image: String,
    @SerializedName("tags") val tags: String,
    @SerializedName("score") val score: Int = 0
) {
    val imageUrl: String
        get() = "https://safebooru.org/images/$directory/$image"
}
