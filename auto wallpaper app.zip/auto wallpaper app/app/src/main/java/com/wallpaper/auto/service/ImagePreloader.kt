package com.wallpaper.auto.service

import android.content.Context
import android.graphics.Bitmap
import android.util.Log
import com.wallpaper.auto.data.db.entity.CropMode
import com.wallpaper.auto.data.db.entity.ImageType
import com.wallpaper.auto.data.repository.AlbumRepository
import com.wallpaper.auto.data.repository.HistoryRepository
import com.wallpaper.auto.data.repository.OnlineImageRepository
import com.wallpaper.auto.data.repository.SelectionOrder
import com.wallpaper.auto.data.repository.SettingsRepository
import com.wallpaper.auto.data.repository.SourceMode
import com.wallpaper.auto.util.BitmapUtils
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class ImagePreloader @Inject constructor(
    @ApplicationContext private val context: Context,
    private val albumRepository: AlbumRepository,
    private val onlineImageRepository: OnlineImageRepository,
    private val historyRepository: HistoryRepository,
    private val settingsRepository: SettingsRepository
) {
    private var currentImageType: ImageType = ImageType.LOCAL
    private var currentImageId: Long = -1
    private var sequentialIndex = 0
    private var splitShowLeft = true
    private var tagPresetIndex = 0

    // Optional override for the next candidate (used for "previous" button)
    private var forcedNextType: ImageType? = null
    private var forcedNextId: Long = -1
    private var forcedNextPath: String? = null

    @Volatile
    var suppressNextHomeChange = false
        private set

    private val selectionMutex = Mutex()

    private val refillScope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    private val _skipEvent = MutableSharedFlow<Unit>(extraBufferCapacity = 1)
    val skipEvent: SharedFlow<Unit> = _skipEvent

    fun requestSkip() {
        _skipEvent.tryEmit(Unit)
    }

    fun setForcedNextImage(type: ImageType, id: Long, path: String?) {
        forcedNextType = type
        forcedNextId = id
        forcedNextPath = path
        suppressNextHomeChange = true
    }

    fun consumeSuppressHomeChange(): Boolean {
        val was = suppressNextHomeChange
        suppressNextHomeChange = false
        return was
    }

    fun getCurrentImageInfo(): Pair<ImageType, Long> = currentImageType to currentImageId

    suspend fun loadCurrentImage(screenWidth: Int, screenHeight: Int): Bitmap? =
        withContext(Dispatchers.IO) {
            refillIfNeeded()
            val candidate = getNextCandidate() ?: return@withContext null
            currentImageType = candidate.type
            currentImageId = candidate.id
            loadAndProcessBitmap(candidate, screenWidth, screenHeight)
        }

    suspend fun preloadNext(screenWidth: Int, screenHeight: Int): Bitmap? =
        withContext(Dispatchers.IO) {
            val candidate = getNextCandidate() ?: return@withContext null
            currentImageType = candidate.type
            currentImageId = candidate.id
            val bitmap = loadAndProcessBitmap(candidate, screenWidth, screenHeight)
            if (bitmap != null) {
                val thumbPath = candidate.path?.let { saveHistoryThumbnail(it) }
                historyRepository.addHistory(candidate.type, candidate.id, thumbPath ?: candidate.path)
                if (candidate.type == ImageType.ONLINE) {
                    consumeAndRefill(candidate.id)
                }
            }
            bitmap
        }

    private fun saveHistoryThumbnail(sourcePath: String): String? {
        val thumbDir = java.io.File(context.filesDir, "history_thumbnails")
        thumbDir.mkdirs()
        val thumbFile = java.io.File(thumbDir, "${java.util.UUID.randomUUID()}.jpg")
        val result = BitmapUtils.saveThumbnail(sourcePath, thumbFile)
        if (result != null) {
            cleanupOldThumbnails(thumbDir, MAX_THUMBNAILS)
        }
        return result
    }

    private fun cleanupOldThumbnails(dir: java.io.File, maxCount: Int) {
        val files = dir.listFiles() ?: return
        if (files.size <= maxCount) return
        files.sortBy { it.lastModified() }
        val toDelete = files.size - maxCount
        for (i in 0 until toDelete) {
            files[i].delete()
        }
    }

    private fun consumeAndRefill(imageId: Long) {
        refillScope.launch {
            try {
                onlineImageRepository.markDisplayed(imageId)
                Log.d(TAG, "Marked online image $imageId as displayed")
                refillIfNeeded()
                val maxCount = settingsRepository.getMaxCacheCount()
                onlineImageRepository.evictToCount(maxCount)
            } catch (e: Exception) {
                Log.e(TAG, "consumeAndRefill failed", e)
            }
        }
    }

    private suspend fun refillIfNeeded() {
        if (!settingsRepository.isAutoDownloadEnabled()) return
        val sourceMode = settingsRepository.getSourceMode()
        if (sourceMode == SourceMode.LOCAL_ONLY) return

        val maxCount = settingsRepository.getMaxCacheCount()
        val unseenCount = onlineImageRepository.getUnseenCount()
        val refillThreshold = (maxCount / 2).coerceAtLeast(1)
        if (unseenCount >= refillThreshold) return

        val totalCount = onlineImageRepository.getCachedCount()
        val available = maxCount - totalCount
        if (available <= 0) return

        val tags = pickNextTags()
        Log.d(TAG, "Refill: unseen=$unseenCount/$refillThreshold avail=$available tags=$tags")

        val fetchCount = available.coerceAtMost(20)
        val posts = onlineImageRepository.fetchPosts(tags, limit = fetchCount, randomize = true)
        var downloaded = 0
        for (post in posts) {
            if (onlineImageRepository.getCachedCount() >= maxCount) break
            val result = onlineImageRepository.downloadAndSave(post)
            if (result != null) downloaded++
        }
        Log.d(TAG, "Refill: downloaded $downloaded images")
    }

    private suspend fun pickNextTags(): List<String> {
        val queries = settingsRepository.getSearchQueries()
        if (queries.isEmpty()) {
            return settingsRepository.getActiveTags()
        }
        val order = settingsRepository.getSelectionOrder()
        val query = if (order == SelectionOrder.RANDOM) {
            queries.random()
        } else {
            selectionMutex.withLock {
                val idx = tagPresetIndex % queries.size
                tagPresetIndex++
                queries[idx]
            }
        }
        Log.d(TAG, "Tag rotation: query='$query'")
        return query.split(" ").map { it.trim() }.filter { it.isNotBlank() }
    }

    // ---------------------------------------------------------------
    // 画像の選択
    // ---------------------------------------------------------------

    private data class ImageCandidate(
        val type: ImageType,
        val id: Long,
        val path: String?,
        val cropMode: CropMode = CropMode.FULL,
        val cropRect: String? = null,
        val isFavorite: Boolean = false,
        val displayCount: Int = 0
    )

    private suspend fun getNextCandidate(): ImageCandidate? = selectionMutex.withLock {
        // 強制画像が指定されていればそれを優先(1回限り)
        forcedNextType?.let { type ->
            val path = forcedNextPath
            val id = forcedNextId
            forcedNextType = null
            forcedNextPath = null
            forcedNextId = -1
            if (path != null && java.io.File(path).exists()) {
                return@withLock ImageCandidate(type, id, path)
            }
        }

        val sourceMode = settingsRepository.getSourceMode()
        val order = settingsRepository.getSelectionOrder()
        val onlineRatio = settingsRepository.getOnlineRatio()

        val localPool = mutableListOf<ImageCandidate>()
        val onlinePool = mutableListOf<ImageCandidate>()

        if (sourceMode == SourceMode.LOCAL_ONLY || sourceMode == SourceMode.BOTH) {
            val localImages = albumRepository.getAllActiveImages().first()
            localPool.addAll(localImages.filter {
                java.io.File(it.filePath).exists()
            }.map {
                ImageCandidate(
                    type = ImageType.LOCAL,
                    id = it.id,
                    path = it.filePath,
                    cropMode = it.cropMode,
                    cropRect = it.cropRect,
                    isFavorite = it.isFavorite
                )
            })
        }

        if (sourceMode == SourceMode.ONLINE_ONLY || sourceMode == SourceMode.BOTH) {
            val onlineImages = onlineImageRepository.getAllActiveImages().first()
            onlinePool.addAll(onlineImages.mapNotNull { img ->
                img.localCachePath?.let { path ->
                    if (java.io.File(path).exists()) {
                        ImageCandidate(
                            type = ImageType.ONLINE,
                            id = img.id,
                            path = path,
                            isFavorite = img.isFavorite,
                            displayCount = img.displayCount
                        )
                    } else null
                }
            })
        }

        // オンラインは未表示(displayCount=0)を優先。なければ全体から選ぶ。
        val unseenOnline = onlinePool.filter { it.displayCount == 0 }
        val effectiveOnlinePool = if (unseenOnline.isNotEmpty()) unseenOnline else onlinePool

        // BOTH モードで両方のプールがある場合、設定された比率に従ってどちらから選ぶか決定
        val pool: List<ImageCandidate> = when (sourceMode) {
            SourceMode.LOCAL_ONLY -> localPool
            SourceMode.ONLINE_ONLY -> effectiveOnlinePool
            SourceMode.BOTH -> when {
                localPool.isEmpty() -> effectiveOnlinePool
                effectiveOnlinePool.isEmpty() -> localPool
                else -> {
                    val pickOnline = kotlin.random.Random.nextFloat() < onlineRatio
                    if (pickOnline) effectiveOnlinePool else localPool
                }
            }
        }

        if (pool.isEmpty()) {
            Log.w(TAG, "No candidates found (source=$sourceMode)")
            return@withLock null
        }

        when (order) {
            SelectionOrder.RANDOM -> pool.random()
            SelectionOrder.SEQUENTIAL -> {
                val idx = sequentialIndex % pool.size
                sequentialIndex++
                pool[idx]
            }
            SelectionOrder.FAVORITES_FIRST -> {
                val favorites = pool.filter { it.isFavorite }
                if (favorites.isEmpty()) {
                    pool.random()
                } else {
                    val boostPercent = settingsRepository.getFavoriteBoostPercent()
                    if (boostPercent >= 100 || kotlin.random.Random.nextInt(100) < boostPercent) {
                        favorites.random()
                    } else {
                        pool.random()
                    }
                }
            }
        }
    }

    // ---------------------------------------------------------------
    // Bitmap のデコードとクロップ適用
    // ---------------------------------------------------------------

    private fun loadAndProcessBitmap(
        candidate: ImageCandidate, screenW: Int, screenH: Int
    ): Bitmap? {
        val path = candidate.path ?: return null
        var bitmap = BitmapUtils.decodeSampledBitmap(path, screenW, screenH) ?: return null

        when (candidate.cropMode) {
            CropMode.FULL -> { /* そのまま使う */ }

            CropMode.SPLIT_LR -> {
                val splitRatio = candidate.cropRect?.toFloatOrNull() ?: 0.5f
                val (left, right) = BitmapUtils.splitLeftRight(bitmap, splitRatio)
                val keep: Bitmap
                val discard: Bitmap
                if (splitShowLeft) {
                    keep = left; discard = right
                } else {
                    keep = right; discard = left
                }
                splitShowLeft = !splitShowLeft
                bitmap.recycle()
                discard.recycle()
                bitmap = keep
            }

            CropMode.CUSTOM -> {
                candidate.cropRect?.let { rectStr ->
                    try {
                        val parts = rectStr.split(",").map { it.toFloat() }
                        if (parts.size == 4) {
                            val cropped = BitmapUtils.cropBitmapToRect(
                                bitmap, parts[0], parts[1], parts[2], parts[3]
                            )
                            bitmap.recycle()
                            bitmap = cropped
                        }
                    } catch (_: Exception) {}
                }
            }
        }
        return bitmap
    }

    companion object {
        private const val TAG = "ImagePreloader"
        private const val MAX_THUMBNAILS = 20
    }
}
