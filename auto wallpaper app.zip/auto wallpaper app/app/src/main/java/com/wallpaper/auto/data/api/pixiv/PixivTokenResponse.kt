package com.wallpaper.auto.data.api.pixiv

import com.google.gson.annotations.SerializedName

data class PixivTokenResponse(
    @SerializedName("access_token") val accessToken: String,
    @SerializedName("refresh_token") val refreshToken: String,
    @SerializedName("expires_in") val expiresIn: Int = 3600,
    @SerializedName("user") val user: PixivUser?
)

data class PixivUser(
    @SerializedName("id") val id: String,
    @SerializedName("name") val name: String,
    @SerializedName("account") val account: String
)
