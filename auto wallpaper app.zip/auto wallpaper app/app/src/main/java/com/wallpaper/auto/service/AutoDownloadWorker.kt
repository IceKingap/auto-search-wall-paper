package com.wallpaper.auto.service

import android.content.Context
import android.util.Log
import androidx.hilt.work.HiltWorker
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.wallpaper.auto.data.repository.OnlineImageRepository
import com.wallpaper.auto.data.repository.SettingsRepository
import com.wallpaper.auto.data.repository.SourceMode
import dagger.assisted.Assisted
import dagger.assisted.AssistedInject

@HiltWorker
class AutoDownloadWorker @AssistedInject constructor(
    @Assisted appContext: Context,
    @Assisted workerParams: WorkerParameters,
    private val settingsRepository: SettingsRepository,
    private val onlineImageRepository: OnlineImageRepository
) : CoroutineWorker(appContext, workerParams) {

    companion object {
        const val TAG = "AutoDownloadWorker"
        const val WORK_NAME = "auto_download_safebooru"
    }

    override suspend fun doWork(): Result {
        return try {
            if (!settingsRepository.isAutoDownloadEnabled()) {
                Log.d(TAG, "Auto-download disabled, skipping")
                return Result.success()
            }

            val sourceMode = settingsRepository.getSourceMode()
            if (sourceMode == SourceMode.LOCAL_ONLY) {
                Log.d(TAG, "Source mode is LOCAL_ONLY, skipping")
                return Result.success()
            }

            val maxCount = settingsRepository.getMaxCacheCount()
            val currentCount = onlineImageRepository.getCachedCount()

            Log.d(TAG, "Current cached: $currentCount, max: $maxCount")

            // Evict excess images first
            if (currentCount > maxCount) {
                onlineImageRepository.evictToCount(maxCount)
            }

            // Download more if below target
            val needed = maxCount - onlineImageRepository.getCachedCount()
            if (needed <= 0) {
                Log.d(TAG, "Cache full, no download needed")
                return Result.success()
            }

            val tags = settingsRepository.getActiveTags()
            val fetchCount = needed.coerceAtMost(20)
            Log.d(TAG, "Fetching $fetchCount posts with tags: $tags")

            val posts = onlineImageRepository.fetchPosts(tags, limit = fetchCount, randomize = true)
            if (posts.isEmpty()) {
                // 一時的なネットワーク不調や API レート制限の可能性。
                Log.w(TAG, "fetchPosts returned empty; scheduling retry")
                return Result.retry()
            }

            var downloaded = 0
            for (post in posts) {
                if (onlineImageRepository.getCachedCount() >= maxCount) break
                val result = onlineImageRepository.downloadAndSave(post)
                if (result != null) downloaded++
            }

            Log.d(TAG, "Downloaded $downloaded new images")
            if (downloaded == 0 && posts.isNotEmpty()) Result.retry() else Result.success()
        } catch (e: Exception) {
            Log.e(TAG, "doWork failed, will retry", e)
            Result.retry()
        }
    }
}
