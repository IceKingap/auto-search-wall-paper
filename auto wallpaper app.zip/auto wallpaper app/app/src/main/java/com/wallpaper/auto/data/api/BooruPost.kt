package com.wallpaper.auto.data.api

/**
 * Safebooru / Danbooru 共通の投稿モデル。
 * 各 API レスポンスからこの型に変換して使う。
 */
data class BooruPost(
    val id: Long,
    val imageUrl: String,
    val previewUrl: String,
    val tags: String,
    val score: Int = 0
)

fun SafebooruPost.toBooruPost() = BooruPost(
    id = id,
    imageUrl = imageUrl,
    previewUrl = imageUrl,
    tags = tags,
    score = score
)

fun DanbooruPost.toBooruPost() = BooruPost(
    id = id,
    imageUrl = fileUrl ?: largeFileUrl ?: "",
    previewUrl = previewFileUrl ?: largeFileUrl ?: fileUrl ?: "",
    tags = tagString,
    score = score
)
