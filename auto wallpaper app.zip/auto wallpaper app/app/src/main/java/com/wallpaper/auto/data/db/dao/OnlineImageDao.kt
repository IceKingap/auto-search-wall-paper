package com.wallpaper.auto.data.db.dao

import androidx.room.*
import com.wallpaper.auto.data.db.entity.OnlineImage
import kotlinx.coroutines.flow.Flow

@Dao
interface OnlineImageDao {
    @Query("SELECT * FROM online_images WHERE isBlacklisted = 0 ORDER BY downloadedAt ASC")
    fun getAllActiveImages(): Flow<List<OnlineImage>>

    @Query("SELECT * FROM online_images WHERE isFavorite = 1 AND isBlacklisted = 0")
    fun getFavoriteImages(): Flow<List<OnlineImage>>

    @Query("SELECT COUNT(*) FROM online_images WHERE isBlacklisted = 0 AND localCachePath IS NOT NULL")
    suspend fun getCachedCount(): Int

    @Query("SELECT COUNT(*) FROM online_images WHERE isBlacklisted = 0 AND localCachePath IS NOT NULL")
    fun observeCachedCount(): Flow<Int>

    @Query("SELECT COUNT(*) FROM online_images WHERE isBlacklisted = 0 AND localCachePath IS NOT NULL AND displayCount = 0")
    suspend fun getUnseenCount(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(image: OnlineImage): Long

    @Update
    suspend fun update(image: OnlineImage)

    @Delete
    suspend fun delete(image: OnlineImage)

    @Query("SELECT * FROM online_images WHERE safebooruId = :safebooruId LIMIT 1")
    suspend fun getBySafebooruId(safebooruId: Long): OnlineImage?

    @Query("SELECT * FROM online_images WHERE sourceUrl = :url LIMIT 1")
    suspend fun getBySourceUrl(url: String): OnlineImage?

    @Query("UPDATE online_images SET isFavorite = :isFavorite WHERE id = :id")
    suspend fun setFavorite(id: Long, isFavorite: Boolean)

    @Query("UPDATE online_images SET isBlacklisted = :isBlacklisted WHERE id = :id")
    suspend fun setBlacklisted(id: Long, isBlacklisted: Boolean)

    @Query("""
        SELECT * FROM online_images
        WHERE isFavorite = 0 AND isBlacklisted = 0
        ORDER BY displayCount DESC, downloadedAt ASC
        LIMIT :limit
    """)
    suspend fun getOldestNonFavorite(limit: Int): List<OnlineImage>

    @Query("UPDATE online_images SET displayCount = displayCount + 1, lastDisplayedAt = :now WHERE id = :id")
    suspend fun incrementDisplayCount(id: Long, now: Long = System.currentTimeMillis())

    @Query("SELECT * FROM online_images WHERE isBlacklisted = 1")
    fun getBlacklistedImages(): Flow<List<OnlineImage>>

    @Query("DELETE FROM online_images WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("DELETE FROM online_images")
    suspend fun deleteAll()

    @Query("SELECT * FROM online_images WHERE id = :id LIMIT 1")
    suspend fun getById(id: Long): OnlineImage?
}
