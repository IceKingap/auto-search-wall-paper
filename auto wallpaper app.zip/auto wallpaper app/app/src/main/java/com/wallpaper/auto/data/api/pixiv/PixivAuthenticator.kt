package com.wallpaper.auto.data.api.pixiv

import kotlinx.coroutines.runBlocking
import okhttp3.Authenticator
import okhttp3.Request
import okhttp3.Response
import okhttp3.Route
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class PixivAuthenticator @Inject constructor(
    private val pixivAuthManager: PixivAuthManager
) : Authenticator {
    override fun authenticate(route: Route?, response: Response): Request? {
        // Avoid infinite retry loops
        if (response.request.header("X-Pixiv-Retry") != null) return null

        val refreshed = runBlocking { pixivAuthManager.refreshToken() }
        if (!refreshed) return null

        val newToken = runBlocking { pixivAuthManager.getAccessToken() } ?: return null
        return response.request.newBuilder()
            .header("Authorization", "Bearer $newToken")
            .header("X-Pixiv-Retry", "1")
            .build()
    }
}
