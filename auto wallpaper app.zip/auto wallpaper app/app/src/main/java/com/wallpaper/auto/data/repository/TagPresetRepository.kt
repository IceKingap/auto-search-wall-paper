package com.wallpaper.auto.data.repository

import com.wallpaper.auto.data.db.dao.TagPresetDao
import com.wallpaper.auto.data.db.entity.TagPreset
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class TagPresetRepository @Inject constructor(
    private val tagPresetDao: TagPresetDao
) {
    fun getAllPresets(): Flow<List<TagPreset>> = tagPresetDao.getAllPresets()

    suspend fun savePreset(name: String, tags: List<String>): Long {
        return tagPresetDao.insert(TagPreset(name = name, tags = tags.joinToString(",")))
    }

    suspend fun deletePreset(preset: TagPreset) = tagPresetDao.delete(preset)
}
