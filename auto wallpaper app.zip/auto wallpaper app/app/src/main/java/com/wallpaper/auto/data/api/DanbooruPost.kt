package com.wallpaper.auto.data.api

import com.google.gson.annotations.SerializedName

data class DanbooruPost(
    @SerializedName("id") val id: Long,
    @SerializedName("file_url") val fileUrl: String?,
    @SerializedName("large_file_url") val largeFileUrl: String?,
    @SerializedName("preview_file_url") val previewFileUrl: String?,
    @SerializedName("tag_string") val tagString: String = "",
    @SerializedName("score") val score: Int = 0,
    @SerializedName("file_ext") val fileExt: String = "jpg"
)

data class DanbooruCountResponse(
    @SerializedName("counts") val counts: DanbooruCounts
)

data class DanbooruCounts(
    @SerializedName("posts") val posts: Int = 0
)
