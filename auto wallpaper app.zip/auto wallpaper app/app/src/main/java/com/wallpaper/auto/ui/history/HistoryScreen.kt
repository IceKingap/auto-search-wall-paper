package com.wallpaper.auto.ui.history

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import coil.compose.AsyncImage
import com.wallpaper.auto.data.db.entity.ImageType
import com.wallpaper.auto.data.db.entity.WallpaperHistory
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HistoryScreen(viewModel: HistoryViewModel = hiltViewModel()) {
    val history by viewModel.history.collectAsState(initial = emptyList())
    val imagePathMap by viewModel.imagePathMap.collectAsState(initial = emptyMap())
    val favoritedIds by viewModel.favoritedIds.collectAsState()
    val blacklistedIds by viewModel.blacklistedIds.collectAsState()
    val message by viewModel.message.collectAsState()

    val snackbarHostState = remember { SnackbarHostState() }
    LaunchedEffect(message) {
        message?.let {
            snackbarHostState.showSnackbar(it)
            viewModel.clearMessage()
        }
    }

    // 二重確認用のダイアログ対象
    var pendingBlacklist by remember { mutableStateOf<WallpaperHistory?>(null) }
    pendingBlacklist?.let { target ->
        AlertDialog(
            onDismissRequest = { pendingBlacklist = null },
            title = { Text("もう表示しない") },
            text = { Text("この画像を二度と壁紙に使用しないようにします。よろしいですか?") },
            confirmButton = {
                TextButton(onClick = {
                    viewModel.blacklistWallpaper(target)
                    pendingBlacklist = null
                }) { Text("はい") }
            },
            dismissButton = {
                TextButton(onClick = { pendingBlacklist = null }) { Text("キャンセル") }
            }
        )
    }

    Scaffold(
        topBar = { TopAppBar(title = { Text("壁紙履歴") }) },
        snackbarHost = { SnackbarHost(snackbarHostState) }
    ) { padding ->
        LazyColumn(modifier = Modifier.padding(padding)) {
            items(history) { item ->
                HistoryItem(
                    history = item,
                    imagePath = imagePathMap[item.id],
                    isFavorited = favoritedIds.contains(item.id),
                    isBlacklisted = blacklistedIds.contains(item.id),
                    onRestore = { viewModel.restoreWallpaper(item) },
                    onFavorite = { viewModel.addToFavorites(item) },
                    onBlacklist = {
                        if (blacklistedIds.contains(item.id)) {
                            viewModel.unblacklistWallpaper(item)
                        } else {
                            pendingBlacklist = item
                        }
                    }
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HistoryItem(
    history: WallpaperHistory,
    imagePath: String?,
    isFavorited: Boolean,
    isBlacklisted: Boolean,
    onRestore: () -> Unit,
    onFavorite: () -> Unit,
    onBlacklist: () -> Unit
) {
    val dateFormat = remember { SimpleDateFormat("MM/dd HH:mm", Locale.JAPAN) }

    ListItem(
        headlineContent = {
            Text(
                dateFormat.format(Date(history.displayedAt)),
                color = if (isBlacklisted) MaterialTheme.colorScheme.onSurfaceVariant
                        else MaterialTheme.colorScheme.onSurface
            )
        },
        supportingContent = {
            val typeLabel = if (history.imageType == ImageType.LOCAL) "ローカル" else "オンライン"
            Text(if (isBlacklisted) "$typeLabel ・ ブラックリスト" else typeLabel)
        },
        leadingContent = {
            if (imagePath != null) {
                AsyncImage(
                    model = imagePath,
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.size(56.dp),
                    alpha = if (isBlacklisted) 0.35f else 1f
                )
            }
        },
        trailingContent = {
            Row {
                IconButton(onClick = onFavorite, enabled = !isFavorited && !isBlacklisted) {
                    Icon(
                        if (isFavorited) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                        "お気に入り追加",
                        tint = if (isFavorited) MaterialTheme.colorScheme.error
                               else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                IconButton(onClick = onBlacklist) {
                    Icon(
                        Icons.Default.Block,
                        if (isBlacklisted) "ブラックリスト解除" else "もう表示しない",
                        tint = if (isBlacklisted) MaterialTheme.colorScheme.error
                               else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                IconButton(onClick = onRestore, enabled = !isBlacklisted) {
                    Icon(Icons.Default.Restore, "壁紙に設定")
                }
            }
        }
    )
    Divider()
}
