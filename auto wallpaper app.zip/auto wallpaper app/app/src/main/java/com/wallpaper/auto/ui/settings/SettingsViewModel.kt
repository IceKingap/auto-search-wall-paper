package com.wallpaper.auto.ui.settings

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.work.Constraints
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import com.wallpaper.auto.data.repository.OnlineImageRepository
import com.wallpaper.auto.data.repository.OverlayRect
import com.wallpaper.auto.data.repository.SelectionOrder
import com.wallpaper.auto.data.repository.SettingsRepository
import com.wallpaper.auto.data.repository.EdgeColorMode
import com.wallpaper.auto.data.repository.SourceMode
import com.wallpaper.auto.service.AutoDownloadWorker
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import java.util.concurrent.TimeUnit
import javax.inject.Inject

@HiltViewModel
class SettingsViewModel @Inject constructor(
    @ApplicationContext private val context: Context,
    private val settingsRepository: SettingsRepository,
    private val onlineImageRepository: OnlineImageRepository
) : ViewModel() {

    // Init 完了まで各 setter をブロックするための gate。
    // これが無いと init 中にユーザーがスイッチを切り替えた場合、
    // init の後続書き込みがユーザー操作を巻き戻してしまう。
    private val initDone = CompletableDeferred<Unit>()

    /** setter 共通: init が終わってから値更新・DB 書き込みを行う。 */
    private fun launchSetting(block: suspend () -> Unit): Job = viewModelScope.launch {
        initDone.await()
        block()
    }

    private val _sourceMode = MutableStateFlow(SourceMode.BOTH)
    val sourceMode: StateFlow<SourceMode> = _sourceMode

    private val _selectionOrder = MutableStateFlow(SelectionOrder.RANDOM)
    val selectionOrder: StateFlow<SelectionOrder> = _selectionOrder

    private val _wifiOnly = MutableStateFlow(true)
    val wifiOnly: StateFlow<Boolean> = _wifiOnly

    private val _cacheLimitMb = MutableStateFlow(200)
    val cacheLimitMb: StateFlow<Int> = _cacheLimitMb

    private val _displayMode = MutableStateFlow("COVER")
    val displayMode: StateFlow<String> = _displayMode

    private val _autoDownload = MutableStateFlow(true)
    val autoDownload: StateFlow<Boolean> = _autoDownload

    private val _maxCacheCount = MutableStateFlow(50)
    val maxCacheCount: StateFlow<Int> = _maxCacheCount

    private val _changeOnHome = MutableStateFlow(false)
    val changeOnHome: StateFlow<Boolean> = _changeOnHome

    private val _cachedCount = MutableStateFlow(0)
    val cachedCount: StateFlow<Int> = _cachedCount

    private val _zoomOutEnabled = MutableStateFlow(false)
    val zoomOutEnabled: StateFlow<Boolean> = _zoomOutEnabled

    private val _zoomOutDuration = MutableStateFlow(10)
    val zoomOutDuration: StateFlow<Int> = _zoomOutDuration

    private val _statusBarOverlayHeight = MutableStateFlow(0)
    val statusBarOverlayHeight: StateFlow<Int> = _statusBarOverlayHeight

    private val _lockOverlayRects = MutableStateFlow<List<OverlayRect>>(emptyList())
    val lockOverlayRects: StateFlow<List<OverlayRect>> = _lockOverlayRects

    private val _edgeFillEnabled = MutableStateFlow(false)
    val edgeFillEnabled: StateFlow<Boolean> = _edgeFillEnabled

    private val _edgeFadeWidth = MutableStateFlow(40)
    val edgeFadeWidth: StateFlow<Int> = _edgeFadeWidth

    private val _panEnabled = MutableStateFlow(false)
    val panEnabled: StateFlow<Boolean> = _panEnabled

    private val _panInverted = MutableStateFlow(false)
    val panInverted: StateFlow<Boolean> = _panInverted

    private val _panSpeed = MutableStateFlow(1.0f)
    val panSpeed: StateFlow<Float> = _panSpeed

    private val _onlineRatio = MutableStateFlow(0.5f)
    val onlineRatio: StateFlow<Float> = _onlineRatio

    private val _changeOnScreenOff = MutableStateFlow(true)
    val changeOnScreenOff: StateFlow<Boolean> = _changeOnScreenOff

    private val _animationFps = MutableStateFlow(30)
    val animationFps: StateFlow<Int> = _animationFps

    private val _gpuRendering = MutableStateFlow(true)
    val gpuRendering: StateFlow<Boolean> = _gpuRendering

    private val _edgeColorMode = MutableStateFlow(EdgeColorMode.EDGE_AVERAGE)
    val edgeColorMode: StateFlow<EdgeColorMode> = _edgeColorMode

    private val _pixivPagingEnabled = MutableStateFlow(false)
    val pixivPagingEnabled: StateFlow<Boolean> = _pixivPagingEnabled

    private val _pixivPagingMaxPages = MutableStateFlow(5)
    val pixivPagingMaxPages: StateFlow<Int> = _pixivPagingMaxPages

    private val _favoriteBoostPercent = MutableStateFlow(50)
    val favoriteBoostPercent: StateFlow<Int> = _favoriteBoostPercent

    init {
        viewModelScope.launch {
            _sourceMode.value = settingsRepository.getSourceMode()
            _selectionOrder.value = settingsRepository.getSelectionOrder()
            _wifiOnly.value = settingsRepository.isWifiOnly()
            _cacheLimitMb.value = settingsRepository.getCacheLimitMb()
            _displayMode.value = settingsRepository.getGlobalDisplayMode()
            _autoDownload.value = settingsRepository.isAutoDownloadEnabled()
            _maxCacheCount.value = settingsRepository.getMaxCacheCount()
            _changeOnHome.value = settingsRepository.isChangeOnHomeEnabled()
            _cachedCount.value = onlineImageRepository.getCachedCount()
            _zoomOutEnabled.value = settingsRepository.isZoomOutEnabled()
            _zoomOutDuration.value = settingsRepository.getZoomOutDuration()
            _statusBarOverlayHeight.value = settingsRepository.getStatusBarOverlayHeight()
            _lockOverlayRects.value = settingsRepository.getLockOverlayRects()
            _edgeFillEnabled.value = settingsRepository.isEdgeFillEnabled()
            _edgeFadeWidth.value = settingsRepository.getEdgeFadeWidth()
            _panEnabled.value = settingsRepository.isPanEnabled()
            _panInverted.value = settingsRepository.isPanInverted()
            _panSpeed.value = settingsRepository.getPanSpeed()
            _onlineRatio.value = settingsRepository.getOnlineRatio()
            _changeOnScreenOff.value = settingsRepository.isChangeOnScreenOffEnabled()
            _animationFps.value = settingsRepository.getAnimationFps()
            _gpuRendering.value = settingsRepository.isGpuRenderingEnabled()
            _edgeColorMode.value = settingsRepository.getEdgeColorMode()
            _pixivPagingEnabled.value = settingsRepository.isPixivPagingEnabled()
            _pixivPagingMaxPages.value = settingsRepository.getPixivPagingMaxPages()
            _favoriteBoostPercent.value = settingsRepository.getFavoriteBoostPercent()
            initDone.complete(Unit)
        }
    }

    fun setOnlineRatio(ratio: Float) = launchSetting {
        _onlineRatio.value = ratio
        settingsRepository.setOnlineRatio(ratio)
    }

    fun setSourceMode(mode: SourceMode) = launchSetting {
        _sourceMode.value = mode
        settingsRepository.setSourceMode(mode)
    }

    fun setSelectionOrder(order: SelectionOrder) = launchSetting {
        _selectionOrder.value = order
        settingsRepository.setSelectionOrder(order)
    }

    fun setWifiOnly(enabled: Boolean) = launchSetting {
        _wifiOnly.value = enabled
        settingsRepository.setWifiOnly(enabled)
        // Wi-Fi のみ設定変更は、登録済みの AutoDownloadWorker の制約も更新しないと反映されない。
        rescheduleAutoDownloadWorker(enabled)
    }

    private fun rescheduleAutoDownloadWorker(wifiOnly: Boolean) {
        val constraints = Constraints.Builder()
            .setRequiredNetworkType(if (wifiOnly) NetworkType.UNMETERED else NetworkType.CONNECTED)
            .build()
        val request = PeriodicWorkRequestBuilder<AutoDownloadWorker>(6, TimeUnit.HOURS)
            .setConstraints(constraints)
            .build()
        WorkManager.getInstance(context).enqueueUniquePeriodicWork(
            AutoDownloadWorker.WORK_NAME,
            ExistingPeriodicWorkPolicy.UPDATE,
            request
        )
    }

    fun setCacheLimitMb(limitMb: Int) = launchSetting {
        _cacheLimitMb.value = limitMb
        settingsRepository.setCacheLimitMb(limitMb)
    }

    fun setDisplayMode(mode: String) = launchSetting {
        _displayMode.value = mode
        settingsRepository.setGlobalDisplayMode(mode)
    }

    fun setAutoDownload(enabled: Boolean) = launchSetting {
        _autoDownload.value = enabled
        settingsRepository.setAutoDownloadEnabled(enabled)
    }

    fun setMaxCacheCount(count: Int) = launchSetting {
        _maxCacheCount.value = count
        settingsRepository.setMaxCacheCount(count)
    }

    fun setChangeOnHome(enabled: Boolean) = launchSetting {
        _changeOnHome.value = enabled
        settingsRepository.setChangeOnHomeEnabled(enabled)
    }

    fun clearOnlineCache() = launchSetting {
        onlineImageRepository.clearAllCache()
        _cachedCount.value = 0
    }

    fun setZoomOutEnabled(enabled: Boolean) = launchSetting {
        _zoomOutEnabled.value = enabled
        settingsRepository.setZoomOutEnabled(enabled)
    }

    fun setZoomOutDuration(seconds: Int) = launchSetting {
        _zoomOutDuration.value = seconds
        settingsRepository.setZoomOutDuration(seconds)
    }

    fun setStatusBarOverlayHeight(heightDp: Int) = launchSetting {
        _statusBarOverlayHeight.value = heightDp
        settingsRepository.setStatusBarOverlayHeight(heightDp)
    }

    fun setLockOverlayRects(rects: List<OverlayRect>) = launchSetting {
        _lockOverlayRects.value = rects
        settingsRepository.setLockOverlayRects(rects)
    }

    fun addLockOverlayRect() = launchSetting {
        val current = _lockOverlayRects.value.toMutableList()
        current.add(OverlayRect(0.1f, 0.1f, 0.8f, 0.1f))
        _lockOverlayRects.value = current
        settingsRepository.setLockOverlayRects(current)
    }

    fun removeLockOverlayRect(index: Int) = launchSetting {
        val current = _lockOverlayRects.value.toMutableList()
        if (index in current.indices) {
            current.removeAt(index)
            _lockOverlayRects.value = current
            settingsRepository.setLockOverlayRects(current)
        }
    }

    fun updateLockOverlayRect(index: Int, rect: OverlayRect) = launchSetting {
        val current = _lockOverlayRects.value.toMutableList()
        if (index in current.indices) {
            current[index] = rect
            _lockOverlayRects.value = current
            settingsRepository.setLockOverlayRects(current)
        }
    }

    fun setEdgeFillEnabled(enabled: Boolean) = launchSetting {
        _edgeFillEnabled.value = enabled
        settingsRepository.setEdgeFillEnabled(enabled)
    }

    fun setEdgeFadeWidth(widthDp: Int) = launchSetting {
        _edgeFadeWidth.value = widthDp
        settingsRepository.setEdgeFadeWidth(widthDp)
    }

    fun setPanEnabled(enabled: Boolean) = launchSetting {
        _panEnabled.value = enabled
        settingsRepository.setPanEnabled(enabled)
    }

    fun setPanInverted(inverted: Boolean) = launchSetting {
        _panInverted.value = inverted
        settingsRepository.setPanInverted(inverted)
    }

    fun setPanSpeed(speed: Float) = launchSetting {
        _panSpeed.value = speed
        settingsRepository.setPanSpeed(speed)
    }

    fun setChangeOnScreenOff(enabled: Boolean) = launchSetting {
        _changeOnScreenOff.value = enabled
        settingsRepository.setChangeOnScreenOffEnabled(enabled)
    }

    fun setAnimationFps(fps: Int) = launchSetting {
        _animationFps.value = fps
        settingsRepository.setAnimationFps(fps)
    }

    fun setGpuRendering(enabled: Boolean) = launchSetting {
        _gpuRendering.value = enabled
        settingsRepository.setGpuRenderingEnabled(enabled)
    }

    fun setEdgeColorMode(mode: EdgeColorMode) = launchSetting {
        _edgeColorMode.value = mode
        settingsRepository.setEdgeColorMode(mode)
    }

    fun setPixivPagingEnabled(enabled: Boolean) = launchSetting {
        _pixivPagingEnabled.value = enabled
        settingsRepository.setPixivPagingEnabled(enabled)
    }

    fun setPixivPagingMaxPages(pages: Int) = launchSetting {
        _pixivPagingMaxPages.value = pages
        settingsRepository.setPixivPagingMaxPages(pages)
    }

    fun setFavoriteBoostPercent(percent: Int) = launchSetting {
        _favoriteBoostPercent.value = percent
        settingsRepository.setFavoriteBoostPercent(percent)
    }
}
