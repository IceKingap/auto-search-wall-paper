package com.wallpaper.auto.data.api.pixiv

import retrofit2.http.GET
import retrofit2.http.Query

interface PixivApiService {
    // filter=for_android が無いと meta_single_page.original_image_url や
    // meta_pages[i].image_urls.original が欠落するレスポンスが返るため必須。
    @GET("/v1/illust/ranking")
    suspend fun illustRanking(
        @Query("mode") mode: String = "day",
        @Query("filter") filter: String = "for_android",
        @Query("offset") offset: Int? = null
    ): PixivIllustListResponse

    @GET("/v1/search/illust")
    suspend fun searchIllust(
        @Query("word") word: String,
        // exact_match_for_tags: タグ完全一致（#タグ検索に相当）
        // partial_match_for_tags だと「猫」で「猫耳」等もヒットしてノイズになるため
        @Query("search_target") searchTarget: String = "exact_match_for_tags",
        @Query("sort") sort: String = "date_desc",
        @Query("filter") filter: String = "for_android",
        @Query("offset") offset: Int? = null
    ): PixivIllustListResponse

    // content_type=illust だとマンガ(type="manga")が除外される。
    // null を渡すと illust+manga 両方が返るので壁紙用途では未指定にする。
    @GET("/v1/illust/recommended")
    suspend fun illustRecommended(
        @Query("content_type") contentType: String? = null,
        @Query("filter") filter: String = "for_android",
        @Query("offset") offset: Int? = null
    ): PixivIllustListResponse
}
