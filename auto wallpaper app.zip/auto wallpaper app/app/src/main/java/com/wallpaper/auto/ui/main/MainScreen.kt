package com.wallpaper.auto.ui.main

import android.app.WallpaperManager
import android.content.ComponentName
import android.content.Intent
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.navigation.compose.*
import com.wallpaper.auto.service.AutoWallpaperService
import com.wallpaper.auto.ui.album.AlbumScreen
import com.wallpaper.auto.ui.favorites.FavoritesScreen
import com.wallpaper.auto.ui.history.HistoryScreen
import com.wallpaper.auto.ui.safebooru.SafebooruScreen
import com.wallpaper.auto.ui.settings.SettingsScreen

sealed class Screen(val route: String, val label: String, val icon: androidx.compose.ui.graphics.vector.ImageVector) {
    object Albums : Screen("albums", "アルバム", Icons.Default.PhotoAlbum)
    object Safebooru : Screen("safebooru", "検索", Icons.Default.Search)
    object Favorites : Screen("favorites", "お気に入り・除外", Icons.Default.Favorite)
    object History : Screen("history", "履歴", Icons.Default.History)
    object Settings : Screen("settings", "設定", Icons.Default.Settings)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen() {
    val navController = rememberNavController()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route
    val context = LocalContext.current

    val screens = listOf(
        Screen.Albums, Screen.Safebooru, Screen.Favorites, Screen.History, Screen.Settings
    )

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Auto Wallpaper") },
                actions = {
                    Button(
                        onClick = {
                            val intent = Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER).apply {
                                putExtra(
                                    WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT,
                                    ComponentName(context, AutoWallpaperService::class.java)
                                )
                            }
                            context.startActivity(intent)
                        },
                        modifier = Modifier.padding(end = 8.dp),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp)
                    ) {
                        Icon(Icons.Default.Wallpaper, null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("壁紙に設定", style = MaterialTheme.typography.labelMedium)
                    }
                }
            )
        },
        bottomBar = {
            NavigationBar {
                screens.forEach { screen ->
                    NavigationBarItem(
                        icon = { Icon(screen.icon, contentDescription = screen.label) },
                        label = { Text(screen.label) },
                        selected = currentRoute == screen.route,
                        onClick = {
                            navController.navigate(screen.route) {
                                popUpTo(navController.graph.startDestinationId) { saveState = true }
                                launchSingleTop = true
                                restoreState = true
                            }
                        }
                    )
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = Screen.Albums.route,
            modifier = Modifier.padding(innerPadding)
        ) {
            composable(Screen.Albums.route) { AlbumScreen() }
            composable(Screen.Safebooru.route) { SafebooruScreen() }
            composable(Screen.Favorites.route) { FavoritesScreen() }
            composable(Screen.History.route) { HistoryScreen() }
            composable(Screen.Settings.route) { SettingsScreen() }
        }
    }
}
