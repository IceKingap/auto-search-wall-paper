package com.wallpaper.auto.ui.settings

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.wallpaper.auto.data.repository.OverlayRect
import com.wallpaper.auto.data.repository.SelectionOrder
import com.wallpaper.auto.data.repository.EdgeColorMode
import com.wallpaper.auto.data.repository.SourceMode

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(viewModel: SettingsViewModel = hiltViewModel()) {
    val sourceMode by viewModel.sourceMode.collectAsState()
    val selectionOrder by viewModel.selectionOrder.collectAsState()
    val wifiOnly by viewModel.wifiOnly.collectAsState()
    val cacheLimitMb by viewModel.cacheLimitMb.collectAsState()
    val displayMode by viewModel.displayMode.collectAsState()
    val autoDownload by viewModel.autoDownload.collectAsState()
    val maxCacheCount by viewModel.maxCacheCount.collectAsState()
    val changeOnHome by viewModel.changeOnHome.collectAsState()
    val cachedCount by viewModel.cachedCount.collectAsState()
    val zoomOutEnabled by viewModel.zoomOutEnabled.collectAsState()
    val zoomOutDuration by viewModel.zoomOutDuration.collectAsState()
    val statusBarOverlayHeight by viewModel.statusBarOverlayHeight.collectAsState()
    val lockOverlayRects by viewModel.lockOverlayRects.collectAsState()
    val edgeFillEnabled by viewModel.edgeFillEnabled.collectAsState()
    val edgeFadeWidth by viewModel.edgeFadeWidth.collectAsState()
    val panEnabled by viewModel.panEnabled.collectAsState()
    val panInverted by viewModel.panInverted.collectAsState()
    val panSpeed by viewModel.panSpeed.collectAsState()
    val onlineRatio by viewModel.onlineRatio.collectAsState()
    val changeOnScreenOff by viewModel.changeOnScreenOff.collectAsState()
    val animationFps by viewModel.animationFps.collectAsState()
    val gpuRendering by viewModel.gpuRendering.collectAsState()
    val edgeColorMode by viewModel.edgeColorMode.collectAsState()

    Scaffold(
        topBar = { TopAppBar(title = { Text("設定") }) }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .padding(padding)
                .padding(16.dp)
        ) {
            // ── 表示モード ──
            item {
                Text("表示モード", style = MaterialTheme.typography.titleMedium)
                Text(
                    "壁紙の表示方法を選択します",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.height(4.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    RadioButton(
                        selected = displayMode == "COVER",
                        onClick = { viewModel.setDisplayMode("COVER") }
                    )
                    Column(modifier = Modifier.padding(start = 4.dp)) {
                        Text("画面にフィット")
                        Text(
                            "画面全体を覆う（はみ出し部分は切り捨て）",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    RadioButton(
                        selected = displayMode == "FIT",
                        onClick = { viewModel.setDisplayMode("FIT") }
                    )
                    Column(modifier = Modifier.padding(start = 4.dp)) {
                        Text("画像全体表示を優先")
                        Text(
                            "画像全体を表示（余白は黒、アスペクト比維持）",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                Spacer(Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("ズームアウトアニメーション")
                        Text(
                            "壁紙表示時に引いていくアニメーション（どちらの表示モードでも動作）",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Switch(checked = zoomOutEnabled, onCheckedChange = { viewModel.setZoomOutEnabled(it) })
                }
                if (zoomOutEnabled) {
                    Text(
                        "速度: ${zoomOutDuration}秒",
                        style = MaterialTheme.typography.bodySmall
                    )
                    Slider(
                        value = zoomOutDuration.toFloat(),
                        onValueChange = { viewModel.setZoomOutDuration(it.toInt()) },
                        valueRange = 3f..60f,
                        steps = 18
                    )
                }
                Spacer(Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("余白を画像の色で補完")
                        Text(
                            "全体表示やズーム中の黒い余白を画像の色合いで埋める",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Switch(checked = edgeFillEnabled, onCheckedChange = { viewModel.setEdgeFillEnabled(it) })
                }
                if (edgeFillEnabled) {
                    Spacer(Modifier.height(4.dp))
                    Text("色の算出方法", style = MaterialTheme.typography.labelLarge)
                    EdgeColorMode.values().forEach { mode ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(
                                selected = edgeColorMode == mode,
                                onClick = { viewModel.setEdgeColorMode(mode) }
                            )
                            Text(
                                text = when (mode) {
                                    EdgeColorMode.EDGE_AVERAGE -> "辺の平均色"
                                    EdgeColorMode.CORNER_AVERAGE -> "角の平均色"
                                    EdgeColorMode.DOMINANT -> "最頻色"
                                    EdgeColorMode.BLACK -> "黒"
                                    EdgeColorMode.WHITE -> "白"
                                },
                                modifier = Modifier.padding(start = 4.dp)
                            )
                        }
                    }
                    Spacer(Modifier.height(4.dp))
                    Text(
                        "ぼかし幅: ${edgeFadeWidth}dp",
                        style = MaterialTheme.typography.bodySmall
                    )
                    Slider(
                        value = edgeFadeWidth.toFloat(),
                        onValueChange = { viewModel.setEdgeFadeWidth(it.toInt()) },
                        valueRange = 0f..120f,
                        steps = 23
                    )
                }
                Spacer(Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("スティックパン", style = MaterialTheme.typography.labelLarge)
                        Text(
                            "ホーム画面で指を引っ張ると画像がその方向に動き続ける",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Switch(checked = panEnabled, onCheckedChange = { viewModel.setPanEnabled(it) })
                }
                if (panEnabled) {
                    Spacer(Modifier.height(4.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("方向を反転")
                        Switch(checked = panInverted, onCheckedChange = { viewModel.setPanInverted(it) })
                    }
                    Text(
                        "速さ: ${"%.1f".format(panSpeed)}x",
                        style = MaterialTheme.typography.bodySmall
                    )
                    Slider(
                        value = panSpeed,
                        onValueChange = { viewModel.setPanSpeed(it) },
                        valueRange = 0.5f..3.0f
                    )
                }
                Divider(modifier = Modifier.padding(vertical = 8.dp))
            }

            // ── 画像ソース ──
            item {
                Text("画像ソース", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(8.dp))
                SourceMode.values().forEach { mode ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(
                            selected = sourceMode == mode,
                            onClick = { viewModel.setSourceMode(mode) }
                        )
                        Text(
                            text = when (mode) {
                                SourceMode.LOCAL_ONLY -> "ローカルのみ"
                                SourceMode.ONLINE_ONLY -> "オンラインのみ"
                                SourceMode.BOTH -> "両方"
                            },
                            modifier = Modifier.padding(start = 4.dp)
                        )
                    }
                }
                if (sourceMode == SourceMode.BOTH) {
                    Spacer(Modifier.height(8.dp))
                    val pct = (onlineRatio * 100).toInt()
                    Text(
                        "オンライン画像の割合: ${pct}% (ローカル ${100 - pct}%)",
                        style = MaterialTheme.typography.bodySmall
                    )
                    Slider(
                        value = onlineRatio,
                        onValueChange = { viewModel.setOnlineRatio(it) },
                        valueRange = 0f..1f
                    )
                }
                Divider(modifier = Modifier.padding(vertical = 8.dp))
            }

            // ── 選択順序 ──
            item {
                Text("選択順序", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(8.dp))
                SelectionOrder.values().forEach { order ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(
                            selected = selectionOrder == order,
                            onClick = { viewModel.setSelectionOrder(order) }
                        )
                        Text(
                            text = when (order) {
                                SelectionOrder.RANDOM -> "ランダム"
                                SelectionOrder.SEQUENTIAL -> "順番"
                                SelectionOrder.FAVORITES_FIRST -> "お気に入り優先"
                            },
                            modifier = Modifier.padding(start = 4.dp)
                        )
                    }
                }
                if (selectionOrder == SelectionOrder.FAVORITES_FIRST) {
                    val favoriteBoostPercent by viewModel.favoriteBoostPercent.collectAsState()
                    Spacer(Modifier.height(4.dp))
                    Text(
                        "お気に入り優先度: ${favoriteBoostPercent}%",
                        style = MaterialTheme.typography.labelLarge
                    )
                    Text(
                        "壁紙切り替え時にお気に入り画像が選ばれる確率",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Slider(
                        value = favoriteBoostPercent.toFloat(),
                        onValueChange = { viewModel.setFavoriteBoostPercent(it.toInt()) },
                        valueRange = 0f..100f,
                        steps = 19
                    )
                    Text(
                        when {
                            favoriteBoostPercent == 0 -> "0%: お気に入りを特別別扱いしない（ランダムと同じ）"
                            favoriteBoostPercent == 100 -> "100%: お気に入りのみ表示（お気に入りがない場合は全画像）"
                            else -> "${favoriteBoostPercent}%: ${favoriteBoostPercent}%の確率でお気に入りから選択"
                        },
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Divider(modifier = Modifier.padding(vertical = 8.dp))
            }

            // ── ネットワーク ──
            item {
                Text("ネットワーク", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Wi-Fiのみダウンロード")
                    Switch(checked = wifiOnly, onCheckedChange = { viewModel.setWifiOnly(it) })
                }
                Divider(modifier = Modifier.padding(vertical = 8.dp))
            }

            // ── 壁紙切り替え ──
            item {
                Text("壁紙切り替え", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("ホームに戻ったとき切り替え")
                        Text(
                            "ホーム画面に戻るたびに壁紙を変更",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Switch(checked = changeOnHome, onCheckedChange = { viewModel.setChangeOnHome(it) })
                }
                Spacer(Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("画面オフ時に切り替え")
                        Text(
                            "画面が消えるたびに次の壁紙を準備",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Switch(checked = changeOnScreenOff, onCheckedChange = { viewModel.setChangeOnScreenOff(it) })
                }
                Divider(modifier = Modifier.padding(vertical = 8.dp))
            }

            // ── 自動ダウンロード ──
            item {
                Text("オンライン画像", style = MaterialTheme.typography.titleMedium)
                Text(
                    "キャッシュ済み: ${cachedCount}枚",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("自動ダウンロード")
                        Text(
                            "壁紙表示ごとに自動補充（プリセットをローテーション）",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Switch(checked = autoDownload, onCheckedChange = { viewModel.setAutoDownload(it) })
                }
                Spacer(Modifier.height(8.dp))
                Text(
                    "保存枚数上限: ${maxCacheCount}枚",
                    style = MaterialTheme.typography.bodyMedium
                )
                Slider(
                    value = maxCacheCount.toFloat(),
                    onValueChange = { viewModel.setMaxCacheCount(it.toInt()) },
                    valueRange = 10f..200f,
                    steps = 18
                )
                Spacer(Modifier.height(4.dp))
                OutlinedButton(
                    onClick = { viewModel.clearOnlineCache() },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("オンラインキャッシュを全削除")
                }
                Divider(modifier = Modifier.padding(vertical = 8.dp))
            }

            // ── オーバーレイ ──
            item {
                Text("オーバーレイ", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(8.dp))

                // ステータスバーオーバーレイ
                Text(
                    "ステータスバーオーバーレイ",
                    style = MaterialTheme.typography.labelLarge
                )
                Text(
                    "白い画像で時刻や通知が見えにくいとき用の半透明バー",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    "高さ: ${if (statusBarOverlayHeight == 0) "OFF" else "${statusBarOverlayHeight}dp"}",
                    style = MaterialTheme.typography.bodySmall
                )
                Slider(
                    value = statusBarOverlayHeight.toFloat(),
                    onValueChange = { viewModel.setStatusBarOverlayHeight(it.toInt()) },
                    valueRange = 0f..100f,
                    steps = 19
                )
                Spacer(Modifier.height(12.dp))

                // ロック画面オーバーレイ
                Text(
                    "ロック画面オーバーレイ",
                    style = MaterialTheme.typography.labelLarge
                )
                Text(
                    "ロック画面でのみ表示される半透明の四角形（時計等を隠す用）",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.height(4.dp))
            }

            // Lock overlay preview
            if (lockOverlayRects.isNotEmpty()) {
                item {
                    Text("プレビュー（画面に対する位置と大きさ）", style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(Modifier.height(4.dp))
                    val rects = lockOverlayRects
                    Canvas(
                        modifier = Modifier
                            .fillMaxWidth()
                            .aspectRatio(9f / 16f)
                            .background(Color.DarkGray)
                            .border(1.dp, MaterialTheme.colorScheme.outline)
                    ) {
                        for (r in rects) {
                            drawRoundRect(
                                color = Color(0f, 0f, 0f, r.alpha),
                                topLeft = Offset(r.left * size.width, r.top * size.height),
                                size = Size(r.width * size.width, r.height * size.height),
                                cornerRadius = CornerRadius(12f, 12f)
                            )
                        }
                    }
                    Spacer(Modifier.height(4.dp))
                }
            }

            // Lock overlay rect editors
            lockOverlayRects.forEachIndexed { index, rect ->
                item(key = "lock_rect_$index") {
                    LockOverlayRectEditor(
                        index = index,
                        rect = rect,
                        onUpdate = { viewModel.updateLockOverlayRect(index, it) },
                        onDelete = { viewModel.removeLockOverlayRect(index) }
                    )
                }
            }

            item {
                OutlinedButton(
                    onClick = { viewModel.addLockOverlayRect() },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("+ オーバーレイ追加")
                }
                Divider(modifier = Modifier.padding(vertical = 8.dp))
            }

            // ── キャッシュ ──
            item {
                Text(
                    "キャッシュ容量上限: ${cacheLimitMb}MB",
                    style = MaterialTheme.typography.titleMedium
                )
                Slider(
                    value = cacheLimitMb.toFloat(),
                    onValueChange = { viewModel.setCacheLimitMb(it.toInt()) },
                    valueRange = 50f..1000f,
                    steps = 18
                )
                Divider(modifier = Modifier.padding(vertical = 8.dp))
            }

            // ── 省電力 ──
            item {
                Text("省電力", style = MaterialTheme.typography.titleMedium)
                Text(
                    "アニメーションの描画負荷を調整します",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.height(8.dp))
                Text(
                    "アニメーション FPS: ${animationFps}fps",
                    style = MaterialTheme.typography.bodyMedium
                )
                Text(
                    "低いほど省電力。壁紙のフェードやズームの滑らかさに影響します",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Slider(
                    value = animationFps.toFloat(),
                    onValueChange = { viewModel.setAnimationFps(it.toInt()) },
                    valueRange = 1f..120f
                )
                Spacer(Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("GPU描画")
                        Text(
                            if (gpuRendering) "ハードウェアアクセラレーション（高速・省電力）"
                            else "ソフトウェアレンダリング（CPU描画）",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            "変更は壁紙の再設定後に反映されます",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.error
                        )
                    }
                    Switch(checked = gpuRendering, onCheckedChange = { viewModel.setGpuRendering(it) })
                }
            }
        }
    }
}

@Composable
private fun LockOverlayRectEditor(
    index: Int,
    rect: OverlayRect,
    onUpdate: (OverlayRect) -> Unit,
    onDelete: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("オーバーレイ ${index + 1}", style = MaterialTheme.typography.labelLarge)
                IconButton(onClick = onDelete) {
                    Icon(Icons.Default.Delete, contentDescription = "削除")
                }
            }
            Text("X位置: ${(rect.left * 100).toInt()}%", style = MaterialTheme.typography.bodySmall)
            Slider(
                value = rect.left,
                onValueChange = { onUpdate(rect.copy(left = it)) },
                valueRange = 0f..0.9f
            )
            Text("Y位置: ${(rect.top * 100).toInt()}%", style = MaterialTheme.typography.bodySmall)
            Slider(
                value = rect.top,
                onValueChange = { onUpdate(rect.copy(top = it)) },
                valueRange = 0f..0.9f
            )
            Text("幅: ${(rect.width * 100).toInt()}%", style = MaterialTheme.typography.bodySmall)
            Slider(
                value = rect.width,
                onValueChange = { onUpdate(rect.copy(width = it)) },
                valueRange = 0.05f..1f
            )
            Text("高さ: ${(rect.height * 100).toInt()}%", style = MaterialTheme.typography.bodySmall)
            Slider(
                value = rect.height,
                onValueChange = { onUpdate(rect.copy(height = it)) },
                valueRange = 0.05f..1f
            )
            Text("不透明度: ${(rect.alpha * 100).toInt()}%", style = MaterialTheme.typography.bodySmall)
            Slider(
                value = rect.alpha,
                onValueChange = { onUpdate(rect.copy(alpha = it)) },
                valueRange = 0.1f..1f
            )
        }
    }
}
