package com.wallpaper.auto.ui.album

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import coil.compose.AsyncImage
import com.wallpaper.auto.data.db.entity.Album
import com.wallpaper.auto.data.db.entity.CropMode
import com.wallpaper.auto.data.db.entity.LocalImage

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AlbumScreen(viewModel: AlbumViewModel = hiltViewModel()) {
    val albums by viewModel.albums.collectAsState(initial = emptyList())
    var selectedAlbum by remember { mutableStateOf<Album?>(null) }
    var showCreateDialog by remember { mutableStateOf(false) }
    var newAlbumName by remember { mutableStateOf("") }

    val imagePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetMultipleContents()
    ) { uris: List<Uri> ->
        selectedAlbum?.let { album ->
            uris.forEach { viewModel.importImage(album.id, it) }
        }
    }

    if (selectedAlbum == null) {
        Scaffold(
            topBar = { TopAppBar(title = { Text("アルバム") }) },
            floatingActionButton = {
                FloatingActionButton(onClick = { showCreateDialog = true }) {
                    Icon(Icons.Default.Add, "アルバム追加")
                }
            }
        ) { padding ->
            if (albums.isEmpty()) {
                Box(
                    modifier = Modifier.fillMaxSize().padding(padding),
                    contentAlignment = Alignment.Center
                ) {
                    Text("+ ボタンでアルバムを作成してください", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            } else {
                LazyColumn(modifier = Modifier.padding(padding)) {
                    items(albums) { album ->
                        AlbumItem(
                            album = album,
                            onClick = { selectedAlbum = album },
                            onToggle = { viewModel.toggleAlbum(album) },
                            onDelete = { viewModel.deleteAlbum(album) }
                        )
                    }
                }
            }
        }
    } else {
        val images by viewModel.getImagesForAlbum(selectedAlbum!!.id).collectAsState(initial = emptyList())
        AlbumDetailScreen(
            album = selectedAlbum!!,
            images = images,
            onBack = { selectedAlbum = null },
            onAddImages = { imagePickerLauncher.launch("image/*") },
            onDeleteImage = { viewModel.deleteImage(it) },
            onToggleFavorite = { viewModel.toggleFavorite(it) },
            onSaveCrop = { image, mode, rect -> viewModel.saveCrop(image, mode, rect) }
        )
    }

    if (showCreateDialog) {
        AlertDialog(
            onDismissRequest = { showCreateDialog = false },
            title = { Text("新しいアルバム") },
            text = {
                OutlinedTextField(
                    value = newAlbumName,
                    onValueChange = { newAlbumName = it },
                    label = { Text("アルバム名") }
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    if (newAlbumName.isNotBlank()) {
                        viewModel.createAlbum(newAlbumName)
                        newAlbumName = ""
                        showCreateDialog = false
                    }
                }) { Text("作成") }
            },
            dismissButton = {
                TextButton(onClick = { showCreateDialog = false }) { Text("キャンセル") }
            }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AlbumItem(album: Album, onClick: () -> Unit, onToggle: () -> Unit, onDelete: () -> Unit) {
    ListItem(
        headlineContent = { Text(album.name) },
        supportingContent = { Text(if (album.isEnabled) "有効" else "無効") },
        trailingContent = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Switch(checked = album.isEnabled, onCheckedChange = { onToggle() })
                Spacer(Modifier.width(4.dp))
                IconButton(onClick = onDelete) {
                    Icon(Icons.Default.Delete, "削除", tint = MaterialTheme.colorScheme.error)
                }
            }
        },
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
    )
    Divider()
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AlbumDetailScreen(
    album: Album,
    images: List<LocalImage>,
    onBack: () -> Unit,
    onAddImages: () -> Unit,
    onDeleteImage: (LocalImage) -> Unit,
    onToggleFavorite: (LocalImage) -> Unit,
    onSaveCrop: (LocalImage, CropMode, String?) -> Unit
) {
    var cropTargetImage by remember { mutableStateOf<LocalImage?>(null) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(album.name) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, "戻る")
                    }
                }
            )
        },
        floatingActionButton = {
            FloatingActionButton(onClick = onAddImages) {
                Icon(Icons.Default.Add, "画像追加")
            }
        }
    ) { padding ->
        if (images.isEmpty()) {
            Box(
                modifier = Modifier.fillMaxSize().padding(padding),
                contentAlignment = Alignment.Center
            ) {
                Text("+ ボタンで画像を追加してください", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        } else {
            LazyVerticalGrid(
                columns = GridCells.Fixed(3),
                modifier = Modifier.padding(padding),
                contentPadding = PaddingValues(4.dp)
            ) {
                items(images) { image ->
                    ImageGridItem(
                        image = image,
                        onToggleFavorite = { onToggleFavorite(image) },
                        onDelete = { onDeleteImage(image) },
                        onCropSettings = { cropTargetImage = image }
                    )
                }
            }
        }
    }

    // Crop settings dialog
    cropTargetImage?.let { image ->
        CropSettingsDialog(
            image = image,
            onDismiss = { cropTargetImage = null },
            onSave = { mode, rect ->
                onSaveCrop(image, mode, rect)
                cropTargetImage = null
            }
        )
    }
}

@Composable
private fun ImageGridItem(
    image: LocalImage,
    onToggleFavorite: () -> Unit,
    onDelete: () -> Unit,
    onCropSettings: () -> Unit
) {
    var showMenu by remember { mutableStateOf(false) }

    Box(
        modifier = Modifier
            .padding(2.dp)
            .aspectRatio(1f)
    ) {
        AsyncImage(
            model = image.filePath,
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
        )

        // Crop mode badge
        if (image.cropMode != CropMode.FULL) {
            Surface(
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .padding(2.dp),
                color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.85f),
                shape = MaterialTheme.shapes.extraSmall
            ) {
                Text(
                    text = when (image.cropMode) {
                        CropMode.SPLIT_LR -> "LR"
                        CropMode.CUSTOM -> "CU"
                        else -> ""
                    },
                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onPrimaryContainer
                )
            }
        }

        // Action buttons overlay
        Column(modifier = Modifier.align(Alignment.TopEnd)) {
            IconButton(
                onClick = { showMenu = true },
                modifier = Modifier.size(32.dp)
            ) {
                Icon(
                    Icons.Default.MoreVert, "メニュー",
                    tint = Color.White,
                    modifier = Modifier.size(18.dp)
                )
            }
        }

        // Favorite icon at bottom
        IconButton(
            onClick = onToggleFavorite,
            modifier = Modifier
                .align(Alignment.BottomStart)
                .size(32.dp)
        ) {
            Icon(
                if (image.isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                "お気に入り",
                tint = if (image.isFavorite) MaterialTheme.colorScheme.primary else Color.White,
                modifier = Modifier.size(18.dp)
            )
        }

        DropdownMenu(
            expanded = showMenu,
            onDismissRequest = { showMenu = false }
        ) {
            DropdownMenuItem(
                text = { Text("クロップ設定") },
                leadingIcon = { Icon(Icons.Default.Crop, null) },
                onClick = {
                    showMenu = false
                    onCropSettings()
                }
            )
            DropdownMenuItem(
                text = { Text("削除") },
                leadingIcon = { Icon(Icons.Default.Delete, null, tint = MaterialTheme.colorScheme.error) },
                onClick = {
                    showMenu = false
                    onDelete()
                }
            )
        }
    }
}

