package com.wallpaper.auto.service

import android.app.*
import android.content.Context
import android.content.Intent
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.wallpaper.auto.MainActivity
import com.wallpaper.auto.R
import com.wallpaper.auto.data.db.entity.ImageType
import com.wallpaper.auto.data.repository.AlbumRepository
import com.wallpaper.auto.data.repository.HistoryRepository
import com.wallpaper.auto.data.repository.OnlineImageRepository
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.*
import javax.inject.Inject

@AndroidEntryPoint
class WallpaperControlService : Service() {

    @Inject lateinit var imagePreloader: ImagePreloader
    @Inject lateinit var albumRepository: AlbumRepository
    @Inject lateinit var onlineImageRepository: OnlineImageRepository
    @Inject lateinit var historyRepository: HistoryRepository

    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    companion object {
        const val ACTION_SKIP = "com.wallpaper.auto.NOTIFY_SKIP"
        const val ACTION_FAVORITE = "com.wallpaper.auto.NOTIFY_FAVORITE"
        const val ACTION_PREVIOUS = "com.wallpaper.auto.NOTIFY_PREVIOUS"
        const val CHANNEL_ID = "wallpaper_control"
        const val NOTIFICATION_ID = 1

        fun start(context: Context) {
            context.startForegroundService(Intent(context, WallpaperControlService::class.java))
        }
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        startForeground(NOTIFICATION_ID, buildNotification())
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_SKIP -> handleSkip()
            ACTION_FAVORITE -> handleFavorite()
            ACTION_PREVIOUS -> handlePrevious()
        }
        return START_STICKY
    }

    private fun handleSkip() {
        // SharedFlow 経由で Engine にスキップを通知
        imagePreloader.requestSkip()
    }

    private fun handleFavorite() {
        scope.launch {
            val (type, id) = imagePreloader.getCurrentImageInfo()
            if (id < 0) return@launch
            when (type) {
                ImageType.LOCAL -> albumRepository.setFavorite(id, true)
                ImageType.ONLINE -> onlineImageRepository.setFavorite(id, true)
            }
        }
    }

    private fun handlePrevious() {
        scope.launch {
            // 履歴から1つ前(現在表示中の前)を取得して強制的に次の画像にする
            val previous = historyRepository.getPrevious() ?: return@launch
            // historyRepository.imagePath はサムネイルなので、復元には元画像のパスを使う
            val path: String? = when (previous.imageType) {
                ImageType.LOCAL -> albumRepository.getLocalImageById(previous.imageRefId)?.filePath
                ImageType.ONLINE -> onlineImageRepository.getById(previous.imageRefId)?.localCachePath
            }
            if (path == null || !java.io.File(path).exists()) return@launch
            imagePreloader.setForcedNextImage(previous.imageType, previous.imageRefId, path)
            imagePreloader.requestSkip()
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }

    private fun createNotificationChannel() {
        val channel = NotificationChannel(
            CHANNEL_ID,
            "壁紙コントロール",
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = "Auto Wallpaper 壁紙切替コントロール"
        }
        getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
    }

    private fun buildNotification(): Notification {
        val openAppIntent = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )

        val skipIntent = PendingIntent.getService(
            this, 1,
            Intent(this, WallpaperControlService::class.java).apply { action = ACTION_SKIP },
            PendingIntent.FLAG_IMMUTABLE
        )

        val favoriteIntent = PendingIntent.getService(
            this, 2,
            Intent(this, WallpaperControlService::class.java).apply { action = ACTION_FAVORITE },
            PendingIntent.FLAG_IMMUTABLE
        )

        val previousIntent = PendingIntent.getService(
            this, 3,
            Intent(this, WallpaperControlService::class.java).apply { action = ACTION_PREVIOUS },
            PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_menu_gallery)
            .setContentTitle(getString(R.string.app_name))
            .setContentText("壁紙自動変更 動作中")
            .setContentIntent(openAppIntent)
            .addAction(android.R.drawable.ic_media_next, "スキップ", skipIntent)
            .addAction(android.R.drawable.btn_star_big_off, "お気に入り", favoriteIntent)
            .addAction(android.R.drawable.ic_media_previous, "戻る", previousIntent)
            .setOngoing(true)
            .build()
    }
}
