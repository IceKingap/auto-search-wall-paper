package com.wallpaper.auto.ui.pixiv

import android.annotation.SuppressLint
import android.net.Uri
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.viewinterop.AndroidView
import com.wallpaper.auto.data.api.pixiv.PixivConstants
import com.wallpaper.auto.data.api.pixiv.PkceUtil

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun PixivLoginDialog(
    onCodeReceived: (code: String, codeVerifier: String) -> Unit,
    onDismiss: () -> Unit
) {
    val codeVerifier = remember { PkceUtil.generateCodeVerifier() }
    val codeChallenge = remember { PkceUtil.generateCodeChallenge(codeVerifier) }
    val loginUrl = remember {
        "${PixivConstants.LOGIN_URL}?code_challenge=$codeChallenge" +
                "&code_challenge_method=S256&client=pixiv-android"
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = {},
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("キャンセル") }
        },
        title = { Text("Pixivにログイン") },
        text = {
            AndroidView(
                factory = { ctx ->
                    WebView(ctx).apply {
                        settings.javaScriptEnabled = true
                        settings.domStorageEnabled = true
                        // Google blocks OAuth from embedded WebViews (detects "wv" in UA).
                        // Use a standard Chrome UA to bypass this restriction.
                        settings.userAgentString =
                            "Mozilla/5.0 (Linux; Android 14; Pixel 8) " +
                            "AppleWebKit/537.36 (KHTML, like Gecko) " +
                            "Chrome/124.0.6367.82 Mobile Safari/537.36"
                        webViewClient = object : WebViewClient() {
                            override fun shouldOverrideUrlLoading(
                                view: WebView?, request: WebResourceRequest?
                            ): Boolean {
                                val url = request?.url?.toString() ?: return false
                                if (url.startsWith(PixivConstants.REDIRECT_URI)) {
                                    val code = Uri.parse(url).getQueryParameter("code")
                                    if (code != null) {
                                        onCodeReceived(code, codeVerifier)
                                    }
                                    return true
                                }
                                return false
                            }
                        }
                        loadUrl(loginUrl)
                    }
                },
                modifier = Modifier.fillMaxSize()
            )
        }
    )
}
