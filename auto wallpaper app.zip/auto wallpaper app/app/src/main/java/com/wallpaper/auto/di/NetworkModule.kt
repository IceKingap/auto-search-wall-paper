package com.wallpaper.auto.di

import com.wallpaper.auto.data.api.DanbooruApi
import com.wallpaper.auto.data.api.SafebooruApi
import com.wallpaper.auto.data.api.pixiv.PixivApiService
import com.wallpaper.auto.data.api.pixiv.PixivAuthenticator
import com.wallpaper.auto.data.api.pixiv.PixivConstants
import com.wallpaper.auto.data.api.pixiv.PixivInterceptor
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.util.concurrent.TimeUnit
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object NetworkModule {

    @Provides
    @Singleton
    fun provideOkHttpClient(): OkHttpClient {
        return OkHttpClient.Builder()
            .addInterceptor(HttpLoggingInterceptor().apply {
                level = HttpLoggingInterceptor.Level.BASIC
            })
            .connectTimeout(30, TimeUnit.SECONDS)
            .readTimeout(30, TimeUnit.SECONDS)
            .build()
    }

    @Provides
    @Singleton
    fun provideSafebooruApi(okHttpClient: OkHttpClient): SafebooruApi {
        return Retrofit.Builder()
            .baseUrl("https://safebooru.org/")
            .client(okHttpClient)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(SafebooruApi::class.java)
    }

    @Provides
    @Singleton
    fun provideDanbooruApi(okHttpClient: OkHttpClient): DanbooruApi {
        return Retrofit.Builder()
            .baseUrl("https://danbooru.donmai.us/")
            .client(okHttpClient)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(DanbooruApi::class.java)
    }

    @Provides
    @Singleton
    @PixivClient
    fun providePixivOkHttpClient(
        pixivInterceptor: PixivInterceptor,
        pixivAuthenticator: PixivAuthenticator
    ): OkHttpClient {
        return OkHttpClient.Builder()
            .addInterceptor(pixivInterceptor)
            .addInterceptor(HttpLoggingInterceptor().apply {
                level = HttpLoggingInterceptor.Level.BASIC
            })
            .authenticator(pixivAuthenticator)
            .connectTimeout(30, TimeUnit.SECONDS)
            .readTimeout(30, TimeUnit.SECONDS)
            .build()
    }

    @Provides
    @Singleton
    fun providePixivApiService(@PixivClient okHttpClient: OkHttpClient): PixivApiService {
        return Retrofit.Builder()
            .baseUrl(PixivConstants.API_BASE_URL)
            .client(okHttpClient)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(PixivApiService::class.java)
    }
}
