package com.wallpaper.auto.service

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/**
 * 旧 ScreenStateReceiver。
 * API 26+ では ACTION_SCREEN_ON/OFF はマニフェスト登録では受信不可のため、
 * AutoWallpaperService.WallpaperEngine 内で動的登録に移行済み。
 * このクラスは互換性のために残してある。
 */
class ScreenStateReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        // No-op: Engine 側で処理
    }
}
