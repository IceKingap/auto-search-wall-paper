package com.wallpaper.auto

import android.app.Application
import androidx.hilt.work.HiltWorkerFactory
import androidx.work.Configuration
import androidx.work.Constraints
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import com.wallpaper.auto.data.repository.SettingsRepository
import com.wallpaper.auto.service.AutoDownloadWorker
import dagger.hilt.android.HiltAndroidApp
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import java.util.concurrent.TimeUnit
import javax.inject.Inject

@HiltAndroidApp
class AutoWallpaperApp : Application(), Configuration.Provider {

    @Inject lateinit var workerFactory: HiltWorkerFactory
    @Inject lateinit var settingsRepository: SettingsRepository

    override val workManagerConfiguration: Configuration
        get() = Configuration.Builder()
            .setWorkerFactory(workerFactory)
            .build()

    override fun onCreate() {
        super.onCreate()
        scheduleAutoDownloadWorker()
    }

    private fun scheduleAutoDownloadWorker() {
        // 設定値に応じて Wi-Fi のみ制約を適用しつつ、定期実行を登録する
        CoroutineScope(Dispatchers.IO + SupervisorJob()).launch {
            val wifiOnly = try {
                settingsRepository.isWifiOnly()
            } catch (_: Exception) {
                true
            }
            val constraints = Constraints.Builder()
                .setRequiredNetworkType(
                    if (wifiOnly) NetworkType.UNMETERED else NetworkType.CONNECTED
                )
                .build()
            val request = PeriodicWorkRequestBuilder<AutoDownloadWorker>(
                6, TimeUnit.HOURS
            )
                .setConstraints(constraints)
                .build()
            WorkManager.getInstance(this@AutoWallpaperApp).enqueueUniquePeriodicWork(
                AutoDownloadWorker.WORK_NAME,
                ExistingPeriodicWorkPolicy.UPDATE,
                request
            )
        }
    }
}
