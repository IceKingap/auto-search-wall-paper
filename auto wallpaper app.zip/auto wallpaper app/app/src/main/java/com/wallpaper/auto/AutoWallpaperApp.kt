package com.wallpaper.auto

import android.app.Application
import android.content.Context
import androidx.hilt.work.HiltWorkerFactory
import androidx.work.Configuration
import androidx.work.Constraints
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import com.wallpaper.auto.data.repository.SettingsRepository
import com.wallpaper.auto.service.AutoDownloadWorker
import dagger.hilt.android.HiltAndroidApp
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import java.util.concurrent.TimeUnit
import javax.inject.Inject

@HiltAndroidApp
class AutoWallpaperApp : Application(), Configuration.Provider {

    @Inject lateinit var workerFactory: HiltWorkerFactory
    @Inject lateinit var settingsRepository: SettingsRepository

    // アプリ寿命と一緒に cancel される Scope。毎回 new する代わりに使い回す。
    private val applicationScope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    override val workManagerConfiguration: Configuration
        get() = Configuration.Builder()
            .setWorkerFactory(workerFactory)
            .build()

    override fun onCreate() {
        super.onCreate()
        applicationScope.launch { scheduleAutoDownloadWorker(this@AutoWallpaperApp) }
    }

    /**
     * 設定に応じた制約で AutoDownloadWorker を登録する。
     * Wi-Fi のみ設定が変更された場合にも呼び出されうる(UI 側から)。
     */
    suspend fun scheduleAutoDownloadWorker(context: Context) {
        val wifiOnly = try {
            settingsRepository.isWifiOnly()
        } catch (_: Exception) {
            true
        }
        val constraints = Constraints.Builder()
            .setRequiredNetworkType(
                if (wifiOnly) NetworkType.UNMETERED else NetworkType.CONNECTED
            )
            .build()
        val request = PeriodicWorkRequestBuilder<AutoDownloadWorker>(
            6, TimeUnit.HOURS
        )
            .setConstraints(constraints)
            .build()
        WorkManager.getInstance(context).enqueueUniquePeriodicWork(
            AutoDownloadWorker.WORK_NAME,
            ExistingPeriodicWorkPolicy.UPDATE,
            request
        )
    }
}
