package com.wallpaper.auto.util

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import java.io.File
import java.io.FileOutputStream
import kotlin.math.roundToInt

object BitmapUtils {

    fun decodeSampledBitmap(filePath: String, reqWidth: Int, reqHeight: Int): Bitmap? {
        return try {
            val options = BitmapFactory.Options().apply {
                inJustDecodeBounds = true
            }
            BitmapFactory.decodeFile(filePath, options)
            options.inSampleSize = calculateInSampleSize(options, reqWidth, reqHeight)
            options.inJustDecodeBounds = false
            BitmapFactory.decodeFile(filePath, options)
        } catch (e: Exception) {
            null
        }
    }

    fun calculateInSampleSize(options: BitmapFactory.Options, reqWidth: Int, reqHeight: Int): Int {
        if (reqWidth <= 0 || reqHeight <= 0) return 1
        val (height, width) = options.outHeight to options.outWidth
        var inSampleSize = 1
        if (height > reqHeight || width > reqWidth) {
            val halfHeight = height / 2
            val halfWidth = width / 2
            while ((halfHeight / inSampleSize) >= reqHeight && (halfWidth / inSampleSize) >= reqWidth) {
                inSampleSize *= 2
            }
        }
        return inSampleSize
    }

    fun cropBitmapToRect(bitmap: Bitmap, left: Float, top: Float, right: Float, bottom: Float): Bitmap {
        val x = (left * bitmap.width).roundToInt().coerceIn(0, bitmap.width - 1)
        val y = (top * bitmap.height).roundToInt().coerceIn(0, bitmap.height - 1)
        val w = ((right - left) * bitmap.width).roundToInt().coerceIn(1, bitmap.width - x)
        val h = ((bottom - top) * bitmap.height).roundToInt().coerceIn(1, bitmap.height - y)
        return Bitmap.createBitmap(bitmap, x, y, w, h)
    }

    fun splitLeftRight(bitmap: Bitmap, splitRatio: Float = 0.5f): Pair<Bitmap, Bitmap> {
        val mid = (bitmap.width * splitRatio.coerceIn(0.1f, 0.9f)).roundToInt()
        val left = Bitmap.createBitmap(bitmap, 0, 0, mid, bitmap.height)
        val right = Bitmap.createBitmap(bitmap, mid, 0, bitmap.width - mid, bitmap.height)
        return left to right
    }

    /**
     * 画像ファイルから小さなサムネイルを作成して保存する。
     * inSampleSize だけで縮小して再スケールは省略する(品質/メモリ共に実用上十分)。
     * @return 保存先のファイルパス。失敗時は null。
     */
    fun saveThumbnail(sourcePath: String, destFile: File, maxSize: Int = 200): String? {
        return try {
            val options = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(sourcePath, options)
            options.inSampleSize = calculateInSampleSize(options, maxSize, maxSize)
            options.inJustDecodeBounds = false
            val bitmap = BitmapFactory.decodeFile(sourcePath, options) ?: return null
            FileOutputStream(destFile).use { out ->
                bitmap.compress(Bitmap.CompressFormat.JPEG, 80, out)
            }
            bitmap.recycle()
            destFile.absolutePath
        } catch (_: Exception) {
            null
        }
    }
}
