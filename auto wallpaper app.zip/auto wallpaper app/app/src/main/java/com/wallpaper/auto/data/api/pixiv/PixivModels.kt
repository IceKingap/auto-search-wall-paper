package com.wallpaper.auto.data.api.pixiv

import com.google.gson.annotations.SerializedName
import com.wallpaper.auto.data.api.BooruPost
import kotlin.random.Random

enum class PixivMultiPageMode {
    /** 最初のページのみ（1枚目） */
    FIRST_PAGE_ONLY,
    /** 複数ページからランダムで1つ選択 */
    RANDOM_PAGE
}

data class PixivIllustListResponse(
    @SerializedName("illusts") val illusts: List<PixivIllust> = emptyList(),
    @SerializedName("next_url") val nextUrl: String? = null
)

data class PixivIllust(
    @SerializedName("id") val id: Long,
    @SerializedName("title") val title: String = "",
    @SerializedName("type") val type: String = "illust",
    @SerializedName("image_urls") val imageUrls: PixivImageUrls,
    @SerializedName("tags") val tags: List<PixivTag> = emptyList(),
    @SerializedName("width") val width: Int = 0,
    @SerializedName("height") val height: Int = 0,
    @SerializedName("total_bookmarks") val totalBookmarks: Int = 0,
    @SerializedName("x_restrict") val xRestrict: Int = 0,
    @SerializedName("meta_single_page") val metaSinglePage: PixivMetaSinglePage? = null,
    @SerializedName("meta_pages") val metaPages: List<PixivMetaPage> = emptyList()
)

data class PixivImageUrls(
    @SerializedName("square_medium") val squareMedium: String? = null,
    @SerializedName("medium") val medium: String? = null,
    @SerializedName("large") val large: String? = null,
    @SerializedName("original") val original: String? = null
)

data class PixivMetaSinglePage(
    @SerializedName("original_image_url") val originalImageUrl: String? = null
)

data class PixivMetaPage(
    @SerializedName("image_urls") val imageUrls: PixivImageUrls
)

data class PixivTag(
    @SerializedName("name") val name: String = "",
    @SerializedName("translated_name") val translatedName: String? = null
)

fun PixivIllust.toBooruPost(): BooruPost {
    val imageUrl = metaSinglePage?.originalImageUrl
        ?: imageUrls.large
        ?: imageUrls.medium
        ?: ""
    val previewUrl = imageUrls.squareMedium
        ?: imageUrls.medium
        ?: imageUrl
    val tagString = tags.joinToString(", ") { it.name }

    return BooruPost(
        id = id,
        imageUrl = imageUrl,
        previewUrl = previewUrl,
        tags = tagString,
        score = totalBookmarks
    )
}

/**
 * 複数ページモードに応じた BooruPost に変換する。
 * - FIRST_PAGE_ONLY: 1ページ目のみ
 * - RANDOM_PAGE: 全ページからランダムで1つ (ID は illustId*1000+pageIdx で一意化)
 *
 * いずれのモードでも返すのは 1 件のみ。
 */
fun PixivIllust.toBooruPosts(mode: PixivMultiPageMode): List<BooruPost> {
    val tagString = tags.joinToString(", ") { it.name }
    val pageCount = metaPages.size

    // 単一ページイラストの場合、モードに関わらず1件だけ返す
    if (pageCount <= 1) {
        val imageUrl = metaSinglePage?.originalImageUrl
            ?: imageUrls.large
            ?: imageUrls.medium
            ?: ""
        val previewUrl = imageUrls.squareMedium
            ?: imageUrls.medium
            ?: imageUrl
        return listOf(BooruPost(
            id = id,
            imageUrl = imageUrl,
            previewUrl = previewUrl,
            tags = tagString,
            score = totalBookmarks
        ))
    }

    return when (mode) {
        PixivMultiPageMode.FIRST_PAGE_ONLY -> {
            val page = metaPages[0]
            val imageUrl = page.imageUrls.original
                ?: page.imageUrls.large
                ?: page.imageUrls.medium
                ?: ""
            val previewUrl = imageUrls.squareMedium
                ?: imageUrls.medium
                ?: imageUrl
            listOf(BooruPost(
                id = id,
                imageUrl = imageUrl,
                previewUrl = previewUrl,
                tags = tagString,
                score = totalBookmarks
            ))
        }

        PixivMultiPageMode.RANDOM_PAGE -> {
            val pageIdx = Random.nextInt(pageCount)
            val page = metaPages[pageIdx]
            val imageUrl = page.imageUrls.original
                ?: page.imageUrls.large
                ?: page.imageUrls.medium
                ?: ""
            val previewUrl = page.imageUrls.squareMedium
                ?: page.imageUrls.medium
                ?: imageUrls.squareMedium
                ?: imageUrl
            // 毎回異なるページがダウンロードされるよう、タイムスタンプで一意化。
            // id だけだと getBySafebooruId で過去のDLと重複判定されてスキップされる。
            val uniqueId = id * 1_000_000L + pageIdx * 1000L + (System.currentTimeMillis() % 1000)
            listOf(BooruPost(
                id = uniqueId,
                imageUrl = imageUrl,
                previewUrl = previewUrl,
                tags = tagString,
                score = totalBookmarks
            ))
        }
    }
}
