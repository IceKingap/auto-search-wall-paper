package com.wallpaper.auto.data.repository

import android.content.Context
import android.net.Uri
import com.wallpaper.auto.data.db.dao.AlbumDao
import com.wallpaper.auto.data.db.dao.LocalImageDao
import com.wallpaper.auto.data.db.entity.Album
import com.wallpaper.auto.data.db.entity.CropMode
import com.wallpaper.auto.data.db.entity.LocalImage
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.util.UUID
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class AlbumRepository @Inject constructor(
    @ApplicationContext private val context: Context,
    private val albumDao: AlbumDao,
    private val localImageDao: LocalImageDao
) {
    fun getAllAlbums(): Flow<List<Album>> = albumDao.getAllAlbums()
    fun getEnabledAlbums(): Flow<List<Album>> = albumDao.getEnabledAlbums()
    fun getImagesForAlbum(albumId: Long): Flow<List<LocalImage>> = localImageDao.getImagesByAlbum(albumId)
    fun getAllActiveImages(): Flow<List<LocalImage>> = localImageDao.getAllActiveImages()
    fun getFavoriteLocalImages(): Flow<List<LocalImage>> = localImageDao.getFavoriteImages()
    fun getBlacklistedImages(): Flow<List<LocalImage>> = localImageDao.getBlacklistedImages()

    suspend fun createAlbum(name: String): Long = albumDao.insert(Album(name = name))

    suspend fun updateAlbum(album: Album) = albumDao.update(album)

    suspend fun deleteAlbum(album: Album) = withContext(Dispatchers.IO) {
        // アルバム専用ディレクトリ(画像コピー先)を丸ごと削除してから DB エントリを消す。
        // CASCADE で local_images も消えるが、ファイル本体は明示的に消さないと残り続ける。
        val albumDir = File(context.filesDir, "albums/${album.id}")
        if (albumDir.exists()) albumDir.deleteRecursively()
        albumDao.delete(album)
    }

    suspend fun importImage(albumId: Long, uri: Uri): Long = withContext(Dispatchers.IO) {
        val destDir = File(context.filesDir, "albums/$albumId")
        destDir.mkdirs()
        val destFile = File(destDir, "${UUID.randomUUID()}.jpg")
        context.contentResolver.openInputStream(uri)?.use { input ->
            FileOutputStream(destFile).use { output ->
                input.copyTo(output)
            }
        }
        localImageDao.insert(LocalImage(albumId = albumId, filePath = destFile.absolutePath))
    }

    suspend fun deleteImage(image: LocalImage) {
        File(image.filePath).delete()
        localImageDao.delete(image)
    }

    suspend fun updateImage(image: LocalImage) = localImageDao.update(image)

    suspend fun setFavorite(id: Long, isFavorite: Boolean) = localImageDao.setFavorite(id, isFavorite)

    suspend fun setBlacklisted(id: Long, isBlacklisted: Boolean) = localImageDao.setBlacklisted(id, isBlacklisted)

    suspend fun getLocalImageById(id: Long): LocalImage? = localImageDao.getById(id)
}
