package com.wallpaper.auto.data.db.dao

import androidx.room.*
import com.wallpaper.auto.data.db.entity.LocalImage
import kotlinx.coroutines.flow.Flow

@Dao
interface LocalImageDao {
    @Query("SELECT * FROM local_images WHERE albumId = :albumId AND isBlacklisted = 0 ORDER BY createdAt ASC")
    fun getImagesByAlbum(albumId: Long): Flow<List<LocalImage>>

    /** 有効なアルバムに属する非ブラックリスト画像のみを返す。 */
    @Query("""
        SELECT li.* FROM local_images li
        INNER JOIN albums a ON li.albumId = a.id
        WHERE li.isBlacklisted = 0 AND a.isEnabled = 1
        ORDER BY li.createdAt ASC
    """)
    fun getAllActiveImages(): Flow<List<LocalImage>>

    @Query("SELECT * FROM local_images WHERE isFavorite = 1 AND isBlacklisted = 0")
    fun getFavoriteImages(): Flow<List<LocalImage>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(image: LocalImage): Long

    @Update
    suspend fun update(image: LocalImage)

    @Delete
    suspend fun delete(image: LocalImage)

    @Query("SELECT * FROM local_images WHERE id = :id")
    suspend fun getById(id: Long): LocalImage?

    @Query("UPDATE local_images SET isFavorite = :isFavorite WHERE id = :id")
    suspend fun setFavorite(id: Long, isFavorite: Boolean)

    @Query("UPDATE local_images SET isBlacklisted = :isBlacklisted WHERE id = :id")
    suspend fun setBlacklisted(id: Long, isBlacklisted: Boolean)

    @Query("SELECT * FROM local_images WHERE isBlacklisted = 1")
    fun getBlacklistedImages(): Flow<List<LocalImage>>
}
