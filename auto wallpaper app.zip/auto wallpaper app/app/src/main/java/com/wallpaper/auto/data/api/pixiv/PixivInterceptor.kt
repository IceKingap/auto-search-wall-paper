package com.wallpaper.auto.data.api.pixiv

import kotlinx.coroutines.runBlocking
import okhttp3.Interceptor
import okhttp3.Response
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class PixivInterceptor @Inject constructor(
    private val pixivAuthManager: PixivAuthManager
) : Interceptor {
    override fun intercept(chain: Interceptor.Chain): Response {
        val builder = chain.request().newBuilder()
            .header("Referer", PixivConstants.IMAGE_REFERER)
            .header("User-Agent", PixivConstants.USER_AGENT)
            .header("App-OS", "android")
            .header("App-OS-Version", "11")
            .header("Accept-Language", "ja_JP")

        val token = runBlocking { pixivAuthManager.getAccessToken() }
        if (token != null) {
            // header() で置換。addHeader だと複数の Authorization が並び、
            // Authenticator 経由のリトライ時に二重付与される危険がある。
            builder.header("Authorization", "Bearer $token")
        }

        return chain.proceed(builder.build())
    }
}
