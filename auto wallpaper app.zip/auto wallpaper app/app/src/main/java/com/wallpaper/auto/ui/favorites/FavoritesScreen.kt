package com.wallpaper.auto.ui.favorites

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.wallpaper.auto.data.api.pixiv.PixivConstants
import com.wallpaper.auto.data.db.entity.LocalImage
import com.wallpaper.auto.data.db.entity.OnlineImage

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FavoritesScreen(viewModel: FavoritesViewModel = hiltViewModel()) {
    val localFavorites by viewModel.localFavorites.collectAsState(initial = emptyList())
    val onlineFavorites by viewModel.onlineFavorites.collectAsState(initial = emptyList())
    val localBlacklist by viewModel.localBlacklist.collectAsState(initial = emptyList())
    val onlineBlacklist by viewModel.onlineBlacklist.collectAsState(initial = emptyList())

    var selectedTab by rememberSaveable { mutableStateOf(0) }

    Scaffold(
        topBar = { TopAppBar(title = { Text("お気に入り・除外") }) }
    ) { padding ->
        Column(modifier = Modifier.padding(padding)) {
            TabRow(selectedTabIndex = selectedTab) {
                Tab(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    text = {
                        val count = localFavorites.size + onlineFavorites.size
                        Text(if (count > 0) "お気に入り ($count)" else "お気に入り")
                    }
                )
                Tab(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    text = {
                        val count = localBlacklist.size + onlineBlacklist.size
                        Text(if (count > 0) "ブラックリスト ($count)" else "ブラックリスト")
                    }
                )
            }

            when (selectedTab) {
                0 -> FavoritesGrid(
                    localImages = localFavorites,
                    onlineImages = onlineFavorites,
                    emptyText = "お気に入りがありません",
                    iconType = IconType.FAVORITE,
                    onLocalAction = { viewModel.removeLocalFavorite(it) },
                    onOnlineAction = { viewModel.removeOnlineFavorite(it) }
                )
                1 -> FavoritesGrid(
                    localImages = localBlacklist,
                    onlineImages = onlineBlacklist,
                    emptyText = "ブラックリストは空です",
                    iconType = IconType.BLOCK,
                    onLocalAction = { viewModel.unblacklistLocal(it) },
                    onOnlineAction = { viewModel.unblacklistOnline(it) }
                )
            }
        }
    }
}

private enum class IconType { FAVORITE, BLOCK }

@Composable
private fun FavoritesGrid(
    localImages: List<LocalImage>,
    onlineImages: List<OnlineImage>,
    emptyText: String,
    iconType: IconType,
    onLocalAction: (LocalImage) -> Unit,
    onOnlineAction: (OnlineImage) -> Unit
) {
    if (localImages.isEmpty() && onlineImages.isEmpty()) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text(emptyText)
        }
        return
    }

    LazyVerticalGrid(
        columns = GridCells.Fixed(3),
        contentPadding = PaddingValues(4.dp)
    ) {
        items(localImages) { image ->
            Box(modifier = Modifier
                .padding(2.dp)
                .aspectRatio(1f)) {
                AsyncImage(
                    model = image.filePath,
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
                ActionIcon(iconType, Modifier.align(Alignment.TopEnd)) { onLocalAction(image) }
            }
        }
        items(onlineImages) { image ->
            Box(modifier = Modifier
                .padding(2.dp)
                .aspectRatio(1f)) {
                val context = LocalContext.current
                val data = image.localCachePath ?: image.sourceUrl
                val isPixiv = data.contains("pximg.net")
                AsyncImage(
                    model = if (isPixiv) {
                        ImageRequest.Builder(context)
                            .data(data)
                            .addHeader("Referer", PixivConstants.IMAGE_REFERER)
                            .crossfade(true)
                            .build()
                    } else data,
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
                ActionIcon(iconType, Modifier.align(Alignment.TopEnd)) { onOnlineAction(image) }
            }
        }
    }
}

@Composable
private fun ActionIcon(
    iconType: IconType,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    IconButton(onClick = onClick, modifier = modifier) {
        when (iconType) {
            IconType.FAVORITE -> Icon(
                Icons.Default.Favorite,
                "お気に入り解除",
                tint = MaterialTheme.colorScheme.primary
            )
            IconType.BLOCK -> Icon(
                Icons.Default.Block,
                "ブラックリスト解除",
                tint = MaterialTheme.colorScheme.error
            )
        }
    }
}
