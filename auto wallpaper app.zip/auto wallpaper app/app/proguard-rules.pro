# Add project specific ProGuard rules here.
-keep class com.wallpaper.auto.data.db.entity.** { *; }
-keep class com.wallpaper.auto.data.api.** { *; }
